import java.util.ArrayList;

public class Course {
    private int code;
    private String title;
    private String instructor;
    private ArrayList<Student> students;

    public Course(int code, String title, String instructor){
        this.code=code;
        this.title=title;
        this.instructor=instructor;
        this.students=new ArrayList<>();

    }

    public void addStudents(Student s1) {
        students.add(s1);
    }
    public void removeStudents(Student s1){
        students.remove(s1);
    }

    public ArrayList<Student> getStudents() {
        return students;
    }

    @Override
    public String toString() {
        return "Course{" +
                "code=" + code +
                ", title='" + title + '\'' +
                ", instructor='" + instructor + '\'' +
                ", students=" + students +
                '}';
    }
}
