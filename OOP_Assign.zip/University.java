import java.util.ArrayList;
import java.util.Scanner;

public class University {
    public static void main(String[] args) {
        Scanner input= new Scanner(System.in);

        Student s1= new Student(1,"Basil", "1234");
        Student s2= new Student(2, "Penny", "4567");

        Course c1= new Course(10, "Maths", "Robert");
        Course c2= new Course(11, "Science", "Bellum");
        c1.addStudents(s1);
        c2.addStudents(s1);
        c1.addStudents(s2);

        ArrayList<Student> list=c1.getStudents();
        ArrayList<Student> list2= c2.getStudents();
        int[] grades= new int[2];

        for (Student student: list) {

            int total=0;
            student.setGrade(input.nextInt());
           student.getGrade();
            System.out.println("average of ");
        }



        /*for(Course course: courses ){
            for(int i=0; i<students.size();i++){
                course.getStudents().get(i).setGrade(input.nextInt());
                int grade= course.getStudents().get(i).getGrade();
                course.getStudents().get(i).getGPA(grade);
            }
        }
        for(int i=0; i< students.size();i++){
            System.out.println(students.get(i).getGrade());
        }

        for(Course course: courses){
            System.out.println(course.getStudents().toString());
        }

    }*/
}}
