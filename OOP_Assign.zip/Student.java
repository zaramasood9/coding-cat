import java.util.ArrayList;

public class Student {
    private int id;
    private String name;
    private String contact;
    private int grade;
    private ArrayList<Course> courses= new ArrayList<>();
    public Student(int id, String name, String contact){
        this.id=id;
        this.name=name;
        this.contact=contact;
    }
    public void setGrade( int grade){
        this.grade=grade;
    }

    public int getGrade() {
        return grade;
    }

    public void getGPA(int grade) {
        if(grade>90){
            System.out.println("A");
        }
        else if((grade>80) &&(grade<90)){
            System.out.println("B");
        }
        else if((grade>70) &&(grade<80)){
            System.out.println("C");
        }
    }
    public void avgGPA(){


    }
    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", contact='" + contact + '\'' +
                '}';
    }
}
