    public class Ferry {
        private Node frontNode, rearNode;
        private int queueSize; // queue size
        public Ferry() {
            frontNode = null;
            rearNode = null;
            queueSize = 0;
        }

        //check if the queue is empty
        public boolean isEmpty() {
            return (queueSize == 0);
        }

        //Remove the item from the front of the queue.
        public Object remove()  {
            if (isEmpty()) {
                System.out.println("Queue is Empty");
                return null;
            }
            else{
                Object data = frontNode.value;
                frontNode = frontNode.next;
                if (isEmpty()) {
                    rearNode = null;
                }
                queueSize--;
                return data;
            }
        }
        public String first()  {
            if (isEmpty()) {
                System.out.println("Queue is Empty");
                return null;
            }
            else return frontNode.value.toString();
        }
        public int size() {
            return queueSize;
        }

        //Add data at the rear of the queue.
        public void add(Object value) {
            Node oldRear = rearNode;
            rearNode = new Node(value);
            rearNode.next = null;
            if (isEmpty()) {
                frontNode = rearNode;
            } else {
                oldRear.next = rearNode;
            }
            queueSize++;
        }
        public void removeAll(){
            if (isEmpty()) {
                System.out.println("Queue is Empty");
            }
            else{
                while(!isEmpty()){
                remove();
                }
            }
        }
        public String display(int i){
           // Node current= frontNode;
            //while(current!=null){
                return "truck "+ i;
                //current=current.next;
            }
        }




