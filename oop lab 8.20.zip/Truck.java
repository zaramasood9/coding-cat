    public class Truck  {
        private Node headNode; // the first node
        private int stackSize;
        private int counter;

        public Truck() {
            headNode = null;
            stackSize = 0;
        }
        public String pop() {
            if (headNode == null) {
                System.out.println("Empty List");
            }
            Object value = headNode.value;
            headNode = headNode.next;
            stackSize--;
            return value.toString();
        }
        public void push(Object value) {
            Node oldHead = headNode;
            headNode = new Node(value);
            headNode.next = oldHead;
            stackSize++;
        }
        public String peek()  {
            if (headNode == null) {
                System.out.println("Empty List");
                return null;
            }
            else return headNode.value.toString();
        }

        public int size() {
            return stackSize;
        }

        public boolean empty() {
            return stackSize == 0;
        }

        public void removeAll(){
            if (headNode == null) {
                System.out.println("Empty List");}
                else{
                    while (!empty()) {
                    pop();
                }
            }
        }
        public String toString(){
            return "truck";
        }
}
