    import java.io.File;
import java.io.FileNotFoundException;
    import java.sql.SQLOutput;
    import java.util.Random;
    import java.util.Scanner;

    public class Main {
        public static void main(String[] args) throws FileNotFoundException {
            File file = new File("C:\\Users\\zaram\\IdeaProjects\\oop lab 8.1\\src\\cars_13422_.txt");
            Scanner sc = new Scanner(file);
            Car[] carArray = new Car[4];
            int count = 0;
            Random random = new Random();
            while (sc.hasNext()) {
                String carname = sc.nextLine();
                sc.skip("Price:\t\t\t€ ");
                double price = sc.nextDouble();
                sc.nextLine();
                sc.skip("New Price Roadworthy:\t€ ");
                double newPrice = sc.nextDouble();
                sc.nextLine();
                sc.skip("Road Tax / 3 Months:\t€ ");
                int minRoadTax = sc.nextInt();
                sc.skip(" - € ");
                int maxRoadTax = sc.nextInt();
                sc.nextLine();
                sc.skip("Body Type:\t\t");
                String bodyType = sc.nextLine();
                sc.skip("Transmission:\t\t");
                String transmission = sc.nextLine();
                sc.skip("Number Of Seats:\t");
                int noOfseats = sc.nextInt();
                sc.nextLine();
                sc.skip("Segment:\t\t");
                String segment = sc.nextLine();
                sc.skip("Introduction:\t\t");
                String intro = sc.nextLine();
                sc.skip("End:\t\t\t");
                String end = sc.nextLine();
                sc.nextLine();

                carArray[count] = new Car(carname, price, newPrice, minRoadTax, maxRoadTax, bodyType, transmission, noOfseats, segment, intro, end);
                count++;
            }
            sc.close();
            for (int i = 0; i < carArray.length; i++) {
                System.out.println(carArray[i].toString());
            }

            int cars = (int) (200 + (Math.random() * 1001));
            int truckstoload = cars / 20;
            int ferriestoload= truckstoload/50;
            Truck stack = new Truck();
            Ferry queue = new Ferry();
            System.out.println("cars to load " + cars);
            System.out.println("trucks needed " + cars / 20);
            System.out.println("ferries will be 1");

            //loading
            System.out.println();
            System.out.println("LOADING");
            System.out.println();
            System.out.println("Truck contents");
            for (int i = 0; i < truckstoload; i++) {
                System.out.println("truck number" + (i+1));
                for (int j = 0; j < 20; j++) {
                    System.out.println("car num: "+ (j+1));
                    int k = random.nextInt(4);
                    stack.push(carArray[k]);
                    System.out.println(carArray[k].getCarName());
                }
                System.out.println("this truck reached its capacity");
                queue.add(stack);
            }
            System.out.println();
            System.out.println("Ferry contents");
            for (int i = 0; i < truckstoload; i++){
                System.out.println("truck number" + (i+1));
                queue.display(i+1);
            }

            System.out.println("numbers of cars now : "+ stack.size());
            System.out.println("numbers of trucks  now: "+ queue.size());


            // unloading
            System.out.println();
            System.out.println("UNLOADING");
            System.out.println();
            System.out.println("Truck contents now");
            for (int i = 0; i < truckstoload; i++) {
                System.out.println("truck number" + (i+1));
                for (int j = 0; j < 20; j++) {
                    stack.pop();
                    System.out.println("--------");
                }
                queue.remove();
            }
            System.out.println();
            System.out.println("Ferry contents");
            for (int i = 0; i < truckstoload; i++){
                //System.out.println("truck number" + (i+1));
                queue.display(i+1);
                System.out.println((i+1)+ " ---------");
            }
           // stack.removeAll();
           // queue.removeAll();
            System.out.println("numbers of cars now : "+ stack.size());
            System.out.println("numbers of trucks now: "+ queue.size());
        }
    }

