public class Main {
    public static void main(String[] args) {
        MyArrayList<Student> obj= new MyArrayList<Student>();
        Student a= new Student("Bob", 19, 2.9);
        Student b= new Student("Sarrah", 20, 4.0);
        Student c= new Student("Ken", 22,3.5 );
        obj.add(a);
        obj.add(b);
        obj.add(c);

        System.out.println("The object is found at: " +obj.Find(c));
        System.out.println("The length of the array: " + obj.Length());
        System.out.println("The object acquired is: " + obj.get(0));
        System.out.println("The student max cgpa is: " +obj.findmax());

        obj.Remove(a);
        //obj.Update(2,45);
        obj.PrintList();


    }
}
