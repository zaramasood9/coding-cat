public class MyArrayList<T extends Comparable<T>>
{
        T[] arr;
        int currIndex;

        MyArrayList() { // default constructor to create an array
            arr = (T[])new Comparable[5];
            currIndex = -1;
        }

        MyArrayList(int size) { // constructor to create an array
            arr = (T[])new Comparable[size];
            currIndex = -1;
        }

        public void PrintList() {
            for (int i = 0; i < arr.length; i++)
                System.out.print("{"+ arr[i] + ",");
        }

        public void add(T v) {
            MyArrayList newarr = null;
            if (currIndex == arr.length - 1) {
                newarr = new MyArrayList((arr.length) * 2);
                for (int i = 0; i < arr.length; i++) {
                    newarr.arr[i] = arr[i];
                }
                arr = (T[]) newarr.arr;
            }
            if (currIndex == -1) {
                currIndex++;
                arr[currIndex] = v;
            } else {
                currIndex++;
                arr[currIndex] = v;
            }

            /*for (int j = 0; j < arr.length - 1; j++) {
                for (int i = 0; i < arr.length - 1; i++) {
                    if ((arr[i] > arr[i + 1]) && (arr[i + 1] != 0)) {
                        int temp = arr[i + 1];
                        arr[i + 1] = arr[i];
                        arr[i] = temp;
                    }
                }

            }*/
        }


        public int Length() {
// return length of occupied list
            return currIndex+1;
        }
    public void clear(T value) {
        // make array empty (keep the size same).
        this.arr = (T[])new Comparable[10];
        this.currIndex = -1;}


    public T get(int index) {
// get element at given index location
            return arr[index];
        }
        public void Update (int index, T value) {
// update element at given location
            MyArrayList newarr = null;
            if (index > arr.length) {
                for (int i = 0; i < newarr.arr.length; i++)
                    newarr.arr[i] = arr[i];
                arr =  (T[]) newarr.arr;
            }
            if(index<= arr.length) {
                arr[index] =value;
            }
        }
        public int Find (T value) {
// if the value found in array then return its index
            int serIndex=-1;
            for (int i = 0; i < arr.length; i++)
                if(arr[i]==value){
                    serIndex=i;}
            return serIndex;
        }
        public void Remove (T value) {
// first find the value in an array then delete the value through
// backward movement in an array.
            int index= Find(value);
            int forIndex;
            if(index==-1){
                System.out.println("Element does not exist");
            }
            if(index!=-1) {
                for (int i = index; i < arr.length-1; i++) {
                    arr[index] = arr[index+1];
                    index++;
                }
                currIndex--;
            }
        }
        public T findmax(){
            T max= arr[0];
            for (int i = 0; i < currIndex; i++){
                if((max.compareTo(arr[i+1])== -1)){
                    max=arr[i+1];
                }
            }
            return max;
            }


        }


