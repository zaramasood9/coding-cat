
public class Main {
    public static void main(String[] args) {
        DynamicArray<Student> obj= new DynamicArray<>();
        Student a= new Student("Bob", 19, 2.9);
        Student b= new Student("Sarrah", 20, 4.0);
        Student c= new Student("Ken", 22,3.5 );
        Student e= new Student("Haris", 19, 2.9);

//Objects added at the front
        obj.addAtFront(a);
        obj.addAtFront(a);
        obj.addAtFront(b);
        obj.addAtFront(c);
        obj.addAtFront(e);
//Objects added at the end
        obj.addAtEnd(a);
        System.out.println("The Initial list looks like: ");
        obj.PrintList();
        System.out.println("\n");
//Reverses the list
        System.out.println("the Reversed list looks like: ");
        obj.reverse();
        System.out.println("\n");
//All entries removed
        obj.removeAll(a);
//Single occurence removed
        obj.removeFirst(b);
        System.out.println("The Final list looks like: ");
        obj.PrintList();
        System.out.println("\n");
//Checks if the list is empty
        System.out.println("The dynamic array list empty?: " + obj.isEmpty());
//Returns the index of the search value given
        System.out.println("The index of [" + e.toString()+ "] is "+ obj.find(e));
//Checks the length of the list
        System.out.println("The length of the list is: "+obj.Length());

    }
}


