public class Student implements Comparable<Student>{
    String name;
    int age;
    double cgpa;

    public Student(String name, int age, double cgpa){
        this.name= name;
        this.age=age;
        this.cgpa=cgpa;
    }
    @Override
    public int compareTo(Student s) {
        if(cgpa==s.cgpa)
            return 0;
        else if(cgpa> s.cgpa)
            return 1;
        else return -1;
    }
    public String toString(){
        return name + " "+ age+ " "+ cgpa;
    }

}
