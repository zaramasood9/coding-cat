import java.util.Arrays;

public class DynamicArray<T extends Comparable<T>> {

    T[] arr;
    int currIndex;
    int front=0;
    int tail;
    public DynamicArray() { // default constructor to create an array
        arr =(T[])new Comparable[2];
        currIndex = -1;
    }

    public DynamicArray(int size) { // constructor to create an array
        arr = (T[])new Comparable[size];
        currIndex = -1;
    }
    public boolean isEmpty(){
        if (currIndex==-1){
            return true;
        }
        else return false;
    }
    public int Length(){
        if (currIndex!=-1){
            return currIndex + 1;
        }
        else return 0;
    }
    public void PrintList() {
        for (int i = 0; i < arr.length; i++)
            System.out.print(arr[i] + " , " );
    }
    public void addAtFront(T v) {
        DynamicArray newarr = null;
       if (currIndex == arr.length - 1) {
            newarr = new DynamicArray((arr.length) * 2);
            for (int i = 0; i < arr.length; i++) {
                newarr.arr[i] = arr[i];
            }
            arr = (T[]) newarr.arr;
       }
        if (currIndex == -1) {
            currIndex++;
            arr[currIndex] = v;
        } else {
            currIndex++;

            for (int i = currIndex; i >0; i--) {
                arr[i] =arr[i-1];
            }
            arr[0]=v;
        }

        }
    public void addAtEnd(T v) {
        DynamicArray newarr = null;
        if (currIndex == arr.length - 1) {
            newarr = new DynamicArray((arr.length) * 2);
            for (int i = 0; i < arr.length; i++) {
                newarr.arr[i] = arr[i];
            }
            arr = (T[]) newarr.arr;
        }
        if (currIndex == -1) {
            currIndex++;
            arr[currIndex] = v;
        } else {
            currIndex++;
            arr[currIndex]=v;
        }
    }
    public int find (T value) {
        int serIndex = -1;
        for (int i = 0; i <= currIndex; i++) {
            if (arr[i] == value) {
                serIndex = i;
                break;
            }
        }
        return serIndex;
    }
    public void reverse(){
        DynamicArray newarr  = new DynamicArray((arr.length));
            int j = arr.length;
            for (int i = 0; i < arr.length; i++) {
                newarr.arr[j - 1] = arr[i];
                j = j - 1;
            }
        for (int i = 0; i < newarr.arr.length; i++)
            System.out.print(newarr.arr[i] + ",");
    }
    public void removeFirst(T value){
        int index= find(value); // shows the last index
        if(index==-1){
            System.out.println("Element does not exist");
        }
        else{
            for (int i = index; i < arr.length-1; i++) {
                arr[i] = arr[i+1];
            }
            currIndex--;
        }
    }
    public void removeAll(T value) {
        int index = find(value); // shows the last index
        if (index == -1) {
            System.out.println("Element does not exist");
        } else {
            while (index != -1) {
                removeFirst(value);
                index = find(value);
            }
        }
    }}















