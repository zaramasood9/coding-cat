public abstract class LivingThings {
    public abstract void eat();
    public abstract void die();

}
