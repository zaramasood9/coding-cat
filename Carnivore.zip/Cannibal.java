public class Cannibal extends Carnivore{
    @Override
    public void eat() {
        System.out.print("eats carnivore and ");
        super.eat();
    }
}
