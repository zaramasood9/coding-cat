public class Carnivore extends LivingThings {

    @Override
    public void eat() {
        System.out.println("carnivore eats herbivores");
    }

    @Override
    public void die() {
        System.out.println("carnivore dies");
    }
}
