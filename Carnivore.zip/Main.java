public class Main {
    public static void main(String[] args) {
        int csize=10;
        int hsize=10;
        int psize=10;
        int cbsize=10;
        boolean go=true;
        do{
        Carnivore[] carnivore= new Carnivore[csize];
        Herbivore[] herbivore= new Herbivore[hsize];
        Plant[] plant= new Plant[psize];
        Cannibal[] cannibal= new Cannibal[cbsize];

       for(int i=0; i<csize;i++){
           carnivore[i]= new Carnivore();
       }

       for(int i=0; i<hsize;i++){
           herbivore[i]=new Herbivore();
            }

       for(int i=0; i<cbsize;i++){
           cannibal[i]= new Cannibal();
            }

       int rand= (int)(Math.random()*6);
        for(int i=0; i<=rand;i++){
            plant[i]= new Plant();
        }
        //account for speeds
        int rand2= (int) ((Math.random()*10));
        int rand3=(int) ((Math.random()*9));
        int rand4= (int) ((Math.random()*8));

       //maintain eating supply
            if(rand2<=rand3){
        for(int i=0; i<=rand2;i++){
            carnivore[i].eat();
        }}
            if(rand3<=rand){
        for(int i=0; i<=rand3;i++){
            herbivore[i].eat();
        }}
            if((rand4<=rand3) && (rand4<=rand2)){
        for(int i=0; i<=rand4;i++){
            cannibal[i].eat();
        }}
        //offspring generation
        if(rand2>0){
            csize=4;
        }
        else{
            go=false;
            System.out.println("less food supply for cannibals");
        }
        if(rand3>0){
            hsize=8;
        }
        else{
            go=false;
            System.out.println("less food supply for carnivores");
        }
        if(rand4>0){
            cbsize=2;
        }
        else{
            go=false;
            System.out.println("cannibals dead");

        }
        psize=(int) (Math.random()*6);


        }while(go);

    }
}
