public class Herbivore extends LivingThings {
    @Override
    public void eat() {
        System.out.println("herbivore eats plants");
    }

    @Override
    public void die() {
        System.out.println("herbivore dies");
    }
}
