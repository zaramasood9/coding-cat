
public class DoublyLinkedList<T extends Comparable<T>> {
    Node head;

    //implement the following Methods
    public DoublyLinkedList() {
        this.head = null;
    }

    public void insertInOrder(T n) {
        Node N = new Node(n);
        Node tempPrev = null;
        Node tempCurr = head;
        if (head == null) { // condition 1: list is empty
            head = N;
            return;
        }
        while (tempCurr != null) {  // traversing through the whole list
            if (((T) tempCurr.data).compareTo(n) >= 1) { // breaks the loop in case acquired data > dataToInsert
                break;
            }
            tempPrev = tempCurr;             //current element becomes previous, and current becomes equal to current.next
            tempCurr = tempCurr.next;
        }
        if (tempPrev == null) { // condition 2: list is NOT empty, head.data > dataToInsert
            N.next = head;
            N.next.prev = N;
            head = N;
            return;
        }
        tempPrev.next = N;  //condition 3: we have acquired a position which is NOT head but acquired data > dataToInsert
        N.prev = tempPrev;
        N.next = tempCurr;
        if(tempCurr!=null){
            tempCurr.prev=N; //updating temporary variable
        }
    }


    public Node Find(T value) {
        if (head == null) { //head contains the search value and list is not empty
            System.out.println("List is empty");
            return null;
        }
        Node temp = head;
        while (temp != null) {
            if (temp.data == value) {
                return temp;
            }
            temp = temp.next;
        }
        return null;
    }

    public void Delete(T value) {
        Node temp = Find(value);
        if (temp != null) {
            if (temp == head) {
                head.next.prev = null;
                head = head.next;
            } else if (temp.next == null) {
                temp.prev.next = null;
            } else {
                temp.prev.next = temp.next;
                temp.next.prev = temp.prev;
            }
            System.out.println("element deleted");
        } else System.out.println("element not present in the list");
    }

    public String toString() {
        if (head == null) {
            return "List is empty";
        }
        Node temp = head;
        String s = "{";
        while (temp != null) {
            s = s + temp.data + ",";
            temp = temp.next;
        }
        s = s + "}";
        return s;
    }

    public void clearList() {
        head = null;
        return;
    }

    public boolean isEmpty() {
        if (head == null) {
            return true;
        }
        return false;
    }

    public int Length() {
        int count = 0;
        Node current = head;
        while (current != null) {
            current = current.next;
            count++;
        }
        return count;
    }

    public void Reverselist() {
        Node current = head;
        Node temp = null;
        while (current != null) {
            temp = current.prev;     //assigns a temporary variable to current.prev
            current.prev = current.next; // }  swaps the prev of current with the next of current
            current.next = temp;         // }
            current = current.prev;//backward traversing, assigns current the next node but, now it is behind the first node
        }
        if (temp != null) {
                head = temp.prev;  //last element in the original list now becomes the head
            }
        }

    }




