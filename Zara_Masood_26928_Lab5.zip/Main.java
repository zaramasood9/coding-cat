public class Main {
    public static void main(String[] args) {
        DoublyLinkedList<Student> list= new DoublyLinkedList<Student>();
        Student s1= new Student ("Ben", 32, 4.5);
        Student s2 =new Student("Jenna", 23,3.0);
        Student s3 =new Student("Ruth", 23,5.0);
        Student s4 =new Student("Jamie", 23,4.8);
        Student s5 =new Student("Gordon", 43,2.8);
        list.insertInOrder(s1);
        list.insertInOrder(s5);
        list.insertInOrder(s4);
        list.insertInOrder(s2);
        list.insertInOrder(s3);
        System.out.println(list);
        System.out.println("initial length: "+ list.Length());
        list.Reverselist();
        System.out.println(list);
        System.out.println("element found: "+ list.Find(s1).data);
        list.Delete(s1);
        System.out.println(list);
        list.clearList();
        System.out.println(list);
        System.out.println(list.isEmpty());
        System.out.println("final length: "+list.Length());
        System.out.println("\n");
        DoublyLinkedList<Integer> list2 =new DoublyLinkedList<Integer>();
        list2.insertInOrder(1);
        //list2.insertInOrder(4);
        list2.insertInOrder(3);
        list2.insertInOrder(2);
        System.out.println(list2);
        System.out.println("initial length: "+ list2.Length());
        list2.Reverselist();
        System.out.println(list2);
        System.out.println("element found: "+ list2.Find(3));
        list2.Delete(5);
        System.out.println(list2);
        list2.clearList();
        System.out.println(list2);
        System.out.println(list2.isEmpty());
        System.out.println("final length: "+list2.Length());
        System.out.println("\n");
        DoublyLinkedList<String> list3= new DoublyLinkedList<>();
        list3.insertInOrder("A");
        list3.insertInOrder("E");
        list3.insertInOrder("B");
        list3.insertInOrder("C");
        list3.insertInOrder("D");

        System.out.println(list3);
        System.out.println("initial length: "+ list3.Length());
        list3.Reverselist();
        System.out.println(list3);
        System.out.println("element found at : "+ list3.Find("D"));
        list3.Delete("B");
        System.out.println(list3);
        list3.clearList();
        System.out.println(list3);
        System.out.println(list3.isEmpty());
        System.out.println("final length: "+list3.Length());



    }
}
