public class MyArrayList {
    int[] arr;
    int currIndex;

    MyArrayList() { // default constructor to create an array
        arr = new int[10];
        currIndex = -1;
    }

    MyArrayList(int size) { // constructor to create an array
        arr = new int[size];
        currIndex = -1;
    }

    public void PrintList() {
        for (int i = 0; i < arr.length; i++)
            System.out.print(arr[i] + ",");
    }

    public void InsertInOrder(int v) {
        MyArrayList newarr = null;
        if (currIndex == arr.length - 1) {
            newarr = new MyArrayList((arr.length) * 2);
            for (int i = 0; i < arr.length; i++)
                newarr.arr[i] = arr[i];
            arr = newarr.arr;
        }

        if (currIndex == -1) {
            currIndex++;
            arr[currIndex] = v;
        } else {
            currIndex++;
            arr[currIndex] = v;
        }

        for (int j = 0; j < arr.length - 1; j++) {
            for (int i = 0; i < arr.length - 1; i++) {
                if ((arr[i] > arr[i + 1]) && (arr[i + 1] != 0)) {
                    int temp = arr[i + 1];
                    arr[i + 1] = arr[i];
                    arr[i] = temp;
                }
            }

        }
    }


    public int Length() {
// return length of occupied list
        return currIndex + 1;
    }

    public int get(int index) {
// get element at given index location
        return arr[index];
    }

    public void Update(int index, int value) {
// update element at given location
        MyArrayList newarr = null;
        if (index > arr.length) {
            for (int i = 0; i < newarr.arr.length; i++)
                newarr.arr[i] = arr[i];
            arr = newarr.arr;
        }
        if (index <= arr.length) {
            arr[index] = value;
        }
    }

    public int Find(int value) {
// if the value found in array then return its index
        int serIndex = -1;
        for (int i = 0; i < arr.length; i++)
            if (arr[i] == value) {
                serIndex = i;
            }
        return serIndex;
    }

    public void Remove(int value) {
// first find the value in an array then delete the value through
// backward movement in an array.
        int index = Find(value);
        if (index == arr.length - 1) {
            arr[arr.length - 1] = 0;
        }
        if (index == -1) {
            System.out.println("Element does not exist");
        }
        if (index != -1) {
            for (int i = index; i < arr.length - 1; i++) {
                arr[index] = arr[index + 1];
            }
            currIndex--;
        }
    }

    public void RemoveDuplicates(int size) {
        int[] sortedArray = new int[size];
        int index=0;
        for (int i = 0; i < size; i++) {
            if (arr[i] != arr[i+1]){
                   sortedArray[index]=arr[i];
                   index++;}
               }
        for (int i = 0; i < size; i++) {
            System.out.print(sortedArray[i] +",");

            }
        }
            }


