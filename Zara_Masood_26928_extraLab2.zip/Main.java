public class Main {
    public static void main(String[] args) {
        MyArrayList obj= new MyArrayList();
        obj.InsertInOrder(1);
        obj.InsertInOrder(2);
        obj.InsertInOrder(4);
        obj.InsertInOrder(3);
        obj.InsertInOrder(5);
        obj.InsertInOrder(4);
        obj.InsertInOrder(4);
        obj.InsertInOrder(2);
        obj.InsertInOrder(5);
        int n= obj.Length();
        
        System.out.println("list before removal: ");
        obj.PrintList();
        System.out.println();
        System.out.println("list after removal: ");
        obj.RemoveDuplicates(n);
        //obj.PrintList();


    }
}


