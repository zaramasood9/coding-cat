import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

public class DrawingFrame extends JPanel implements WindowListener {
    DrawingPanel panel;
    public static void main(String[] args)
    {

        new DrawingFrame().running();

    }
    public void running(){
        JFrame frame = new JFrame( "Drawing Program" );
        frame.setDefaultCloseOperation(3);
       Stack stack= FileIO.Stack();
       Queue queue=FileIO.Queue();
       panel= new DrawingPanel(stack,queue);
        frame.add( panel );
        frame.pack();
        frame.setVisible( true );
        frame.addWindowListener(this);
    }

    @Override
    public void windowOpened(WindowEvent e) {

    }

    @Override
    public void windowClosing(WindowEvent e) {
        FileIO.saveStack(panel.getShapestack());
        FileIO.saveQueue(panel.getRedoqueue());

    }

    @Override
    public void windowClosed(WindowEvent e) {

    }

    @Override
    public void windowIconified(WindowEvent e) {

    }

    @Override
    public void windowDeiconified(WindowEvent e) {

    }

    @Override
    public void windowActivated(WindowEvent e) {

    }

    @Override
    public void windowDeactivated(WindowEvent e) {

    }
}

