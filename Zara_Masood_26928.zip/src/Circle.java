import java.awt.*;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
public class Circle extends Shape {
    private int		size;
    private Point center;
    private Color 	color;
    public Circle(){}
    public Circle(int iSize, Point location, Color C)
    {
        setSize(iSize);
        setLocation(location);
        setColor(C);
    }

    public void setSize(int iSize) {
        if (iSize > 1) {
            size = iSize;
        } else {
            size = 1;
        }
    }

    public void setLocation(Point Pcenter) {
        center = Pcenter;
    }

    public void  setColor(Color Ccolor) {
        color = Ccolor;
    }

    public int getSize()
    {
        return size;
    }

    Point getCenter()
    {
        return center;
    }
    public String toString(){
        return center.x + " "+ center.y;
    }
    Color getColor()
    {
        return color;
    }

    @Override
    public void draw(Graphics g) {
        g.setColor(getColor());
        g.fillOval(getCenter().x - getSize()/2 ,getCenter().y - getSize()/2,getSize(),getSize());
    }
}
