import javax.swing.*;
import java.awt.*;
import java.awt.Rectangle;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Random;
import java.awt.Color;

public class DrawingPanel extends JPanel implements MouseListener, MouseMotionListener, KeyListener {
    private int[] pointX = new int[3];
    private int[] pointY = new int[3];
    int count=0;
    private static final long serialVersionUID = 1L;
    // PROPERTIES
    private final int DEFAULT_WIDTH  = 800;
    private final int DEFAULT_HEIGHT = 600;
    private int c=0;
    private int x1, y1, x2, y2;
    protected Shape shape;
    private Graphics g;
    protected int shapetype;
    String shapeName;
    Stack shapestack = new Stack();
    Queue redoqueue= new Queue();
    Random random = new Random();
    // CONSTRUCTOR
    public DrawingPanel(Stack stack, Queue queue)
    {
        if(stack!=null) shapestack=stack;
        if(queue!=null) redoqueue=queue;
        setBackground( Color.WHITE );
        setPreferredSize( new Dimension( DEFAULT_WIDTH, DEFAULT_HEIGHT ) );
        this.addMouseListener( this );
        this.addMouseMotionListener(this  );
        this.addKeyListener(this);
        setFocusable(true);
    }

    // METHOD
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);

    }
    public void text(Graphics g) {

        if(shapetype == 1)
            shapeName = "Circle";
        else if (shapetype == 2)
            shapeName = "Rectangle";
        else if (shapetype == 3)
            shapeName = "Triangle";
        else shapeName = "";

        g.setColor(Color.BLACK);
        g.setFont(new Font(Font.MONOSPACED, Font.BOLD, 25));
        g.drawString(shapeName, 20, 570);

    }

    private void setUpDrawingGraphics()
    {
        g = getGraphics();
        text(g);
       /*if(shape!=null){
           shape.draw(g);
       }*/

        Node current= shapestack.head;
        while (current != null) {
            current.shape.draw(g);
            current=current.next;
        }

        /*if(circle!=null)
            circle.draw(g);

        for( Circle circle: circles)
        {
            circle.draw(g);
        }

        if(tri!=null)
            tri.draw(g);

        for(Triangle tri: triangles)
        {
            tri.draw(g);
        }

        if(rectangle!=null)
            rectangle.draw(g);

        for(Cell rectangle: rectangles)
        {
            rectangle.draw(g);
        }*/
  //text(g);
    }
    public Stack getShapestack(){
        return shapestack;
    }

    public Queue getRedoqueue() {
        return redoqueue;
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if (shapetype == 3) {
            if (c < 3) {
                pointX[c] = e.getX();
                pointY[c] = e.getY();
                c++;
                if (c == 3) {
                    shape = new Triangle(pointX, pointY, new Color((int)(Math.random()*256), (int) (Math.random()*256), (int) (Math.random()*256)));

                        redoqueue.purge();
                        System.out.println("items in queue are: ");
                        redoqueue.show();


                    shapestack.push(shape);
                    shapestack.display();
                   // System.out.println(shapestack.size()-1);

                    setUpDrawingGraphics();
                    shape.draw(g);
                    pointY = new int[3];
                    pointX = new int[3];
                    c = 0;

                }
                if (c > 3) {
                    pointX = new int[3];
                    pointY = new int[3];
                    c = 0;
            }
        }

    }}

    @Override
    public void mousePressed(MouseEvent e) {
        // TODO Auto-generated method stub
        if (SwingUtilities.isLeftMouseButton(e)) {
            x1 = e.getX();
            y1 = e.getY();
            if (shapetype == 1 || shapetype == 2) {

                if (shapetype == 1) {
                    shape = new Circle(50, new Point(x1, y1), new Color((int) (Math.random() * 256), (int) (Math.random() * 256), (int) (Math.random() * 256)));
                        redoqueue.purge();
                        System.out.println("items in queue are: ");
                        redoqueue.show();

                    shapestack.push(shape);
                    shapestack.display();
                   // System.out.println(shapestack.size());


                } else {
                    int xVal = (Math.min(x1, x2));
                    int yVal = (Math.min(y1, y2));
                    int width = x1 - x2;
                    int height = y1 - y2;
                    shape = new Cell(xVal, yVal, width, height, new Color(random.nextInt(256), random.nextInt(256), random.nextInt(256)));
                         redoqueue.purge();
                         System.out.println("items in queue are: ");
                         redoqueue.show();

                    shapestack.push(shape);
                    shapestack.display();
                    //System.out.println(shapestack.size() - 1);

                }

            }

           /* if(shapetype==1) {
                x1 = e.getX();
                y1 = e.getY();
                circle = new Circle(50, new Point(x1, y1), new Color(random.nextInt(256), random.nextInt(256), random.nextInt(256)));
                circles.add(circle);
            }

            if (shapetype==2) {
                x1 = e.getX();
                y1 = e.getY();
                int xVal = (Math.min(x1, x2));
                int yVal = (Math.min(y1, y2));
                int width = x1 - x2;
                int height = y1 - y2;
                rectangle = new Cell(xVal, yVal, width, height, new Color(random.nextInt(256), random.nextInt(256), random.nextInt(256)));
                rectangles.add(rectangle);
            }


            if (shapetype == 3) {
                x1 = e.getX();
                y1 = e.getY();
                int[] xPoints = {x1, x2, (x1 + x2) / 2};
                int[] yPoints = {y2, y2, y1};
                tri = new Triangle(xPoints, yPoints, new Color(random.nextInt(256), random.nextInt(256), random.nextInt(256)));
                triangles.add(tri);
            }*/

        } else if (SwingUtilities.isRightMouseButton(e)) {
            System.out.println("right pressed");
            Shape popped = shapestack.pop();
            if (popped != null) {
                redoqueue.add(popped);
                System.out.println("we just popped an item");
                redoqueue.show();


                g.clearRect(0,0, DEFAULT_WIDTH, DEFAULT_HEIGHT);
                setUpDrawingGraphics();

            } else if (SwingUtilities.isMiddleMouseButton(e)) {
                //my laptop does not have a middle button, i've still written the code but haven't tried and tested it
                System.out.println("middle pressed");
                Shape dequeued = redoqueue.remove();
                if (dequeued != null) {
                    shapestack.push(dequeued);
                    shapestack.display();
                }
            }
        }
    }
    @Override
    public void mouseReleased(MouseEvent e) {
        x2= e.getX();
        y2=e.getY();

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mouseDragged(MouseEvent e) {
        int xVal = (Math.min(x1, x2));
        int yVal = (Math.min(y1, y2));
        int width = x1 - x2;
        int height = y1 - y2;
        int n = (int) (Math.sqrt((width * width) + (height * height)));
        if (shapetype == 1) {
            shape.setSize(n);
        }
        else if(shapetype==2){
            shape.setWidth(x1,x2);
            shape.setHeight(y1,y2);
        }
        setUpDrawingGraphics();
        shape.draw(g);
    }



    @Override
    public void mouseMoved(MouseEvent e) {
        setUpDrawingGraphics();
    }

    @Override
    public void keyTyped(KeyEvent e) {
        // TODO Auto-generated method stub

    }

    @Override
    public void keyPressed(KeyEvent e) {
        // TODO Auto-generated method stub
        if (e.getKeyChar() == '1'){
            shapetype =1;
        }

        if (e.getKeyChar() == '2'){
            shapetype =2;
        }
        if (e.getKeyChar() == '3'){
            shapetype =3;
        }
        System.out.println("Key Pressed");
        setUpDrawingGraphics();
    }

    @Override
    public void keyReleased(KeyEvent e) {
        // TODO Auto-generated method stub

    }


}
