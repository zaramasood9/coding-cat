import java.awt.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
public class FileIO {
    public static void saveQueue(Queue queue){
        try{
            Node current=queue.front;
            File file1=new File("C:\\Users\\zaram\\OneDrive\\Documents\\queues.txt");
            FileWriter writer1= new FileWriter(file1);
            while(current!=null){
                Color c= current.shape.getShapeColor();
                int red= c.getRed();
                int blue= c.getBlue();
                int green= c.getGreen();

                if(current.shape instanceof Triangle){
                    writer1.write("Triangle");
                    writer1.write(red +" "+blue+" "+green);

                }
                else if (current.shape instanceof Circle){
                    writer1.write("Circle");
                    writer1.write(red +" "+blue+" "+green);
                    writer1.write(((Circle) current.shape).getCenter(). toString());
                    writer1.write(current.shape.getSize());

                }
                else if(current.shape instanceof Cell){
                    writer1.write("Rectangle");
                    writer1.write(red +" "+blue+" "+green);
                    writer1.write(current.shape.getx());
                    writer1.write( current.shape.gety());
                    writer1.write(current.shape.getWidth());
                    writer1.write((current.shape.getHeight()));
                }
                current=current.next;
            }
            writer1.close();
        }catch(IOException e){
            e.printStackTrace();
        }

    }

    public static void saveStack(Stack stack){
        try{
            Node current=stack.head;
            File file=new File("C:\\Users\\zaram\\OneDrive\\Documents\\stacks.txt");
            FileWriter writer= new FileWriter(file);
            while(current!=null){
                Color c= current.shape.getShapeColor();
                int red= c.getRed();
                int blue= c.getBlue();
                int green= c.getGreen();

                if(current.shape instanceof Triangle){
                    writer.write("Triangle");
                    writer.write(red +" "+blue+" "+green);

                }
                else if (current.shape instanceof Circle){
                    writer.write("Circle");
                    writer.write(red +" "+blue+" "+green);
                    writer.write(((Circle) current.shape).getCenter(). toString());
                    writer.write( current.shape.getSize());
                }
                else if(current.shape instanceof Cell){
                    writer.write("Rectanglle");
                    writer.write(red +" "+blue+" "+green);
                    writer.write(current.shape.getx());
                    writer.write( current.shape.gety());
                    writer.write(current.shape.getWidth());
                    writer.write((current.shape.getHeight()));
                }
                current=current.next;
            }
            writer.close();
        }catch(IOException e){
            e.printStackTrace();
        }
        }
        public static Stack Stack(){
        Stack stack=null;
        try{
            File file =new File("C:\\Users\\zaram\\OneDrive\\Documents\\stacks.txt");
            Scanner s= new Scanner(file);
            stack= new Stack();
            while (s.hasNext()) {
                String type=s.next();
                Shape shape;
                if(type.equals("Triangle")){
                    shape=new Triangle();
                    shape.setShapeColor(new Color(s.nextInt(), s.nextInt(), s.nextInt()));
                    stack.push(shape);
                }
               if(type.equals("Circle")){
                //shape.setShapeColor(new Color(s.nextInt(),s.nextInt(), s.nextInt()));
                Point center= new Point(s.nextInt(), s.nextInt());
                int size=s.nextInt();
                shape=new Circle(size,center, new Color(s.nextInt(),s.nextInt(), s.nextInt()));

                   stack.push(shape);
               }
               if(type.equals("Rectangle")){
                   //shape.setShapeColor(new Color(s.nextInt(),s.nextInt(), s.nextInt()));
                   int x=s.nextInt();
                   int y=s.nextInt();
                   int width= s.nextInt();
                   int height= s.nextInt();
                   shape=new Cell(x,y,width,height,new Color(s.nextInt(),s.nextInt(), s.nextInt()));

                   stack.push(shape);
               }

        }
        }catch(IOException e){
            e.printStackTrace();
        }
        return stack;
        }
        public static Queue Queue(){
        Queue queue=null;
            try{
                File file =new File("C:\\Users\\zaram\\OneDrive\\Documents\\queues.txt");
                Scanner s= new Scanner(file);
                queue= new Queue();
                while (s.hasNext()) {
                    String type=s.next();
                    Shape shape;
                    if(type.equals("Triangle")){
                        shape=new Triangle();
                        shape.setShapeColor(new Color(s.nextInt(),s.nextInt(), s.nextInt()));
                        queue.add(shape);
                    }
                    if(type.equals("Circle")){
                       // shape.setShapeColor(new Color(s.nextInt(),s.nextInt(), s.nextInt()));
                        Point center= new Point(s.nextInt(), s.nextInt());
                        int size=s.nextInt();

                        shape=new Circle(size,center, new Color(s.nextInt(),s.nextInt(), s.nextInt()));
                        queue.add(shape);
                    }
                    if(type.equals("Rectangle")){
                        int x=s.nextInt();
                        int y=s.nextInt();
                        int width= s.nextInt();
                        int height= s.nextInt();
                        //shape.setShapeColor(new Color(s.nextInt(),s.nextInt(), s.nextInt()));
                        shape=new Cell(x,y,width,height,new Color(s.nextInt(),s.nextInt(), s.nextInt()));

                        queue.add(shape);
                    }

                }
            }catch(IOException e){
                e.printStackTrace();
            }
            return queue;
        }
    }

