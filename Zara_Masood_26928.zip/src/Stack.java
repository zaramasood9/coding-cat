public class Stack {
    public Node head;
 public int size;
 public Shape data;
    public void push(Shape shape){
        Node oldHead = head;
        head = new Node(shape);
        head.next = oldHead;
        size++;
        /* if (head == null) {
            head = new Node(data);
        } else {
            Node temp = new Node(data);
            temp.next = head;
            head = temp;
            size++;
        }*/
}
    public Shape pop(){
        if (head == null) System.out.printf("Empty");
        Shape data = head.shape;
        head = head.next;
        size--;
        return data;
    }
    public int size(){
        return size;
    }
    public boolean empty() {
        return size == 0;
    }
    public void display(){
        Node current= head;
        while(current!= null){
            System.out.println(current.shape);
            current= current.next;
        }
    }
}
