import java.awt.*;
import java.util.Random;

public abstract class Shape {
    int size;
    Color color= RandomColor();
    int x;
    int y;
    int width;
    int height;
    public void setSize(int size) {
        this.size = size;
    }
    public int getSize(){
        return size;
    }
    public void setWidth(int x1, int x2){
      width= x1-x2;
    }
    public void setHeight(int y1, int y2){
        height= y1-y2;
    }
    public int getWidth(){
        return width;
    }
    public int getHeight(){
        return height;
    }
    public void setShapeColor(Color color){
        this.color=color;
    }
    public Color getShapeColor() {

        return color;}
    public Color RandomColor(){;
        Random random = new Random();
        int red = random.nextInt(256);
        int green = random.nextInt(256);
        int blue = random.nextInt(256);
        return new Color(red, green, blue);
    }
    public void setx(int x1, int x2){
        int x= Math.min(x1,x2);
    }
    public void sety(int y1, int y2){
        int y= Math.min(y1,y2);
    }
    public int getx(){
        return x;
    }
    public int gety(){
        return y;
    }
    public abstract void draw(Graphics g);
    }


