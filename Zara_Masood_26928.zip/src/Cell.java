import java.awt.Color;
import java.awt.Graphics;
public class Cell extends Shape{
    private int x;
    private int y;
   private int width;
   private int height;
    Color color;
    public Cell(){}
    public Cell(int x,int y,int width, int height, Color color){
        this.x=x;
        this.y=y;
        this.width=width;
        this.height=height;
        this.color=color;
    }

    public int getX(){
        return x;
    }
    public int getY(){
        return y;
    }

    public int getHeight() {
        return height;
    }

    public int getWidth() {
        return width;
    }

    @Override
    public void draw(Graphics g) {
        g.setColor(color);
        g.fillRect(getX(), getY(), getWidth(), getHeight());
    }
}
