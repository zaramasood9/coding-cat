public class Node {
     Shape shape;
     Node next;
    public Node(Shape shape){
        this.shape=shape;
        this.next=null;
    }
}
