public class Queue {
    public Node front;
    public Node last;
    public int size;
  public Shape move;
    public Queue(){
        this.front=null;
        this.last=null;
        this.size=0;
    }
    public boolean isEmpty() {
        return size == 0;
    }
    public void add(Shape data){
        Node temp= last;
        last= new Node(data);
        last.next=null;
        if(isEmpty()){
            front=last;
        }
        else {
            temp.next=last;
        }
        size++;
    }
    public int size() {
        return size;
    }
    public Shape remove(){
        if (isEmpty()){
            System.out.println("queue is empty");
            return null;
        }
        else{
            move= front.shape;
            front= front.next;
            if (isEmpty()) {
                last = null;
            }
            size--;
            return move;
        }
    }
    public void purge(){
        if (isEmpty()){
            System.out.println("queue is empty");
        }
        while (!isEmpty()) {
            remove();
        }
        }


    public void show() {
        if (isEmpty()) {
            System.out.println("Queue is empty");
            return;
        }
        Node temp = front;
        while(temp!=null)
        {
            System.out.println(temp.shape);
            temp = temp.next;
        }
    }
}
