import java.awt.*;

public class Triangle extends Shape{
    Color color;
    private int[] PointsX;
    private int[] PointsY;
    public Triangle(){}

    public Triangle(int[] xPoints, int[] yPoints, Color color) {
        this.PointsX = xPoints;
        this.PointsY = yPoints;
        this.color = color;
    }

    @Override
    public void draw(Graphics g) {
        g.setColor(color);
        g.fillPolygon(PointsX, PointsY, 3);
    }
}
