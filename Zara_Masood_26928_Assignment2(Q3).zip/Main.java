public class Main{
        public static void main(String[] args) {
            VideoRentalSystem rentalSystem = new VideoRentalSystem();
            Video video1 = new Video(1, "Interstellar", "Sci Fi");
            Video video2 = new Video(2, "Mr Church", "HeartFelt");
            Video video3 = new Video(3, "Joker", "Drama movie");

            rentalSystem.addVideo(video1);
            rentalSystem.addVideo(video2);
            rentalSystem.addVideo(video3);
            rentalSystem.printAllVideos();
            rentalSystem.showVideoDetails(2);
            Customer customer1 = new Customer(100, "Fred");
            Customer customer2 = new Customer(200, "Bob");
            rentalSystem.addCustomer(customer1);
            rentalSystem.addCustomer(customer2);
            System.out.println("Is video 1 available? " + rentalSystem.checkVideoAvailability(1));
            customer1.rentVideo(video1);
            customer1.rentVideo(video2);
            customer2.rentVideo(video3);
            rentalSystem.printCustomerRentedVideos(customer1);
            rentalSystem.printCustomerRentedVideos(customer2);
            System.out.println("Is video 1 available? " + rentalSystem.checkVideoAvailability(1));
            rentalSystem.showVideoDetails(2);
            customer1.returnVideo(video1);
            rentalSystem.showVideoDetails(1);



        }
}
