
public class Customer {
    private int id;
    private String name;
    private LinkedList<Video> rentedVideos;

    public Customer(int id, String name) {
        this.id = id;
        this.name = name;
        rentedVideos = new LinkedList<>();
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public LinkedList<Video> getRentedVideos() {
        return rentedVideos;
    }

    public void rentVideo(Video video) {
        if (!video.isRented()) {
            video.rentVideo();// status becomes true
            rentedVideos.add(video);
        } else {
            System.out.println("video rented");
        }
    }

    public void returnVideo(Video video) {
        if (rentedVideos.contains(video)) {
            video.returnVideo();  //status becomes false
            rentedVideos.removeFirst(video);
        } else {
            System.out.println("video returned");
        }
    }
}

