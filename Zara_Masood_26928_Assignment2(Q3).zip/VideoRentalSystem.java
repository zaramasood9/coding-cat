
public class VideoRentalSystem {
    private LinkedList<Video> allVideos;
    private LinkedList<Customer> customers;

    public VideoRentalSystem() {
        allVideos = new LinkedList<>();
        customers = new LinkedList<>();
    }

    public void addVideo(Video video) {
        allVideos.add(video);
    }

    public void addCustomer(Customer customer) {
        customers.add(customer);
    }

    public void showVideoDetails(int videoId) {
        Node<Video> current = allVideos.head;
           while (current != null) {
            Video video= current.data;
            if (video.getId() == videoId) {
                System.out.println("Title: " + video.getTitle());
                System.out.println("Description: " + video.getDescription());
                if(video.isRented()){
                    System.out.println("Rental Status: Rented");
                }
                else{
                System.out.println("Rental Status: Available");
                }
            }
            current=current.next;
        }
    }

    public void printAllVideos() {
        System.out.println("List of All Videos in the Store:");
        Node<Video> current = allVideos.head;
        String s;
        while (current != null) {
            Video video = current.data;
            if(video.isRented()){
                s="Rented";
            }
            else{
                s="Available";
            }
            System.out.println("Title: " + video.getTitle() + ", Availability: " + s);
            current = current.next;
        }
    }

    public boolean checkVideoAvailability(int videoId) {
        for(int i=0; i<allVideos.Length();i++){
            Video video= allVideos.get(i);
            if (video.getId() == videoId && !(video.isRented())) {
                return true;
            }
        }
        return false;
    }

    public void printCustomerRentedVideos(Customer customer) {
        System.out.println("Videos rented by " + customer.getName() + ":");
        Node<Video> current = customer.getRentedVideos().head;
        while (current != null) {
            Video v = current.data;
                System.out.println("Title: " + v.getTitle());
            current = current.next;

        }
        }
    }



