public class LinkedList<T> {
    Node head;


    public LinkedList() {
        this.head = null;
    }

    public void addAsHead(T i){
        Node N=new Node(i);
        if(head==null){
            head=N;
        }
        else{
            N.next=head;
            N.next.prev=N;
            head=N;
        }
    }
    public void add(T i) {
        Node newNode = new Node(i);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
            newNode.prev = current;
        }}
    public Node Find(T value) {
        if (head == null) { //head contains the search value and list is not empty
            System.out.println("List is empty");
            return null;
        }
        Node temp = head;
        while (temp != null) {
            if (temp.data == value) {
                return temp;
            }
            temp = temp.next;
        }
        return null;
    }
    public void  removeFirst(T value) {
        Node temp = Find(value);
        if (head == null || temp == null) {
            return;
        }
        if (head == temp) {
            head.next.prev=null;
            head=head.next;
            return;
        }
        if (temp.next != null) {
            temp.prev.next=temp.next;
            temp.next.prev=temp.prev;
        }
        else{
            temp.prev.next=null;
            }
        }

    public void removeAll(T i){
        Node index = Find(i); // shows the last index
        if (index == null) {
            System.out.println("Element does not exist");
        } else {
            while (index != null) {
                removeFirst(i);
                index = Find(i);
            }
        }
    }
    public String toString() {
        if (head == null) {
            return "List is empty";
        }
        Node temp = head;
        String s = "{";
        while (temp != null) {
            s = s + temp.data + ",";
            temp = temp.next;
        }
        s = s + "}";
        return s;
    }

    public boolean isEmpty() {
        if (head == null) {
            return true;
        }
        return false;
    }
    public boolean contains(T i){
        Node current=  head;
        while (current != null) {
            if(current.data==i){
                return true;
            }
            current=current.next;
        }
       return false;
        }
        public T get(int i){
            Node current=  head;
            int count=0;
            while (current != null) {
             if(i==count){
                 return (T)current.data;
             }
             count++;
            }
           return null;
        }

    public int Length() {
        int count = 0;
        Node current = head;
        while (current != null) {
            current = current.next;
            count++;
        }
        return count;
    }

}







