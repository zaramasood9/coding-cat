import java.awt.*;

public class Hexagon extends Polygon {
    public void paint(Graphics g){
        int[] x1={550,600,650,625,600,575};
        int[] y1={50,50,100,150,150,200};
        g.setColor(Color.black);
        g.drawPolygon(x1,y1,6);
    }
}
