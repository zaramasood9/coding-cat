import java.awt.*;

public class Triangle extends Polygon {
    private int[] x;
    private int[] y;
    public void paint(Graphics g){
        int[] x = {400, 420, 450};
        int[] y = {320, 320, 200};
        g.setColor(Color.blue);
        g.drawPolygon(x, y, 3);

    }}

