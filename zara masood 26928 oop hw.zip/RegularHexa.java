import java.awt.*;

public class RegularHexa extends Hexagon{
    @Override
    public void paint(Graphics g) {

     int x = 100; // x-coordinate of center of pentagon
    int y = 100; // y-coordinate of center of pentagon
    int r = 80; // radius of circumscribed circle
    int[] xPoints = new int[6];
    int[] yPoints = new int[6];

        for (int i = 0; i < 6; i++) {
        xPoints[i] = (int) (x + r * Math.cos(i * 2 * Math.PI / 6));
        yPoints[i] = (int) (y + r * Math.sin(i * 2 * Math.PI / 6));
    }
        g.drawPolygon(xPoints, yPoints, 6);

        g.setColor(Color.blue);
}
}
