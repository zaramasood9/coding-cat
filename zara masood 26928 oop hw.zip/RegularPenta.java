import java.awt.*;

public class RegularPenta extends Pentagon{
    @Override
    public void paint(Graphics g) {

        int x = 300; // x-coordinate of center of pentagon
        int y =300; // y-coordinate of center of pentagon
        int r = 100; // radius of circumscribed circle
        int[] xPoints = new int[5];
        int[] yPoints = new int[5];

        for (int i = 0; i < 5; i++) {
            xPoints[i] = (int) (x + r * Math.cos(i * 2 * Math.PI / 5));
            yPoints[i] = (int) (y + r * Math.sin(i * 2 * Math.PI / 5));
        }

        g.drawPolygon(xPoints, yPoints, 5);

        g.setColor(Color.black);
    }
}
