import java.awt.*;

public class Pentagon extends Polygon {
    public void paint(Graphics g){
        int[] z= {675, 625, 525, 500, 600};
        int[] zy= {300, 250, 250, 275, 275};
        g.setColor(Color.black);
        g.drawPolygon(z,zy,5);
    }}

