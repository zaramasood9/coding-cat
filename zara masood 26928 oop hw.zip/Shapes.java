import javax.swing.*;
import java.awt.*;
    public class Shapes extends Polygon {

    public static void main(String[] args) {
        Drawingcanvas canvas= new Drawingcanvas();
        JFrame frame = new JFrame("Draw Shapes");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBackground(Color.black);
        frame.setSize(200, 200);
        frame.setVisible(true);
        frame.add(canvas);
    }
    }