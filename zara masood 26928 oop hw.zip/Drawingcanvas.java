import java.awt.*;
import java.io.*;
import java.util.Scanner;

public class Drawingcanvas extends Canvas {

    public void paint(Graphics g)   {
        Hexagon h1 = new Hexagon();
        h1.paint(g);
        RegularHexa h2 = new RegularHexa();
        h2.paint(g);
        try {
            File file= new File("C:\\Users\\zaram\\OneDrive\\Documents\\shapes.txt");
            Scanner in = new Scanner(file);

            while (in.hasNextLine()) {
                String data = in.nextLine();
                // create a new object and populate its fields using the data array
                if (data.equalsIgnoreCase("triangle")) {
                    Triangle t1 = new Triangle();
                    t1.paint(g);
                }
                else if(data.equalsIgnoreCase("quadrilateral")){
                    Quadrilateral q1 = new Quadrilateral();
                    q1.paint(g);
                }
                else if(data.equalsIgnoreCase("pentagon")){
                    Pentagon p1 = new Pentagon();
                    p1.paint(g);
                }
                else if(data.equalsIgnoreCase("regular pentagon")){
                    RegularPenta p2 = new RegularPenta();
                    p2.paint(g);
                }
                else if(data.equalsIgnoreCase("pentagram")){
                    Pentagram p3 = new Pentagram();
                    p3.paint(g);
                }
            }
            in.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found");
        }

    }}

