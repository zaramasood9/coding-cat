import java.awt.*;

public class Pentagram extends Pentagon {
    @Override
    public void paint(Graphics g) {
        int x = 550; // x-coordinate of center of pentagon
        int y = 550; // y-coordinate of center of pentagon
        int r = 80; // radius of circumscribed circle
        int[] xPoints = new int[5];
        int[] yPoints = new int[5];

        for (int i = 0; i < 5; i++) {
            xPoints[i] = (int) (x + r * Math.cos(i * 2 * Math.PI / 5));
            yPoints[i] = (int) (y + r * Math.sin(i * 2 * Math.PI / 5));
        }

        g.drawPolygon(xPoints, yPoints, 5);

        for(int i=0; i<3; i++) {
            g.drawLine(xPoints[i], yPoints[i], xPoints[i + 2], yPoints[i + 2]);
            g.drawLine(xPoints[i], yPoints[i], xPoints[i + 3], yPoints[i + 3]);
            g.setColor(Color.black);
        }

    }
}



