import javax.swing.*;
import java.awt.*;

public class Rectangle extends JFrame {

    public Rectangle() {
        setTitle("Rectangle");
        setSize(900, 900);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    public void paint(Graphics g) {
        int width = 300;
        int height = 150;
        g.drawRect(100, 175, width, height);
        Font myfont = new Font("Times Roman", Font.BOLD, 15);
        g.setFont(myfont);
        g.setColor(Color.BLACK);
        String s = "Text Inside the Rectangle";
        g.drawString(s, height-10, width - 10);
    }

    public static void main(String[] args) {
        Rectangle R = new Rectangle();
        R.paint(null);
    }

}

