import java.awt.*;

public class Quadrilateral extends Polygon {
    public void paint(Graphics g){
        int[] x = {500, 420, 300, 550};
        int[] y = {50, 60, 100, 150};
        g.setColor(Color.blue);
        g.drawPolygon(x, y, 4);
    }
}
