public class Car {
    private String carName;
    private double price;
    private double newPrice;
    private int minRoadTax;
    private int maxRoadTax;
    private String bodyType;
    private String transmission;
    private int noOfseats;
    private String segment;
    private String intro;
    private String end;



    public Car(String carName, double price, double newPrice, int minRoadTax, int maxRoadTax, String bodyType, String transmission, int noOfseats, String segment, String intro, String end){
        this.carName=carName;
        this.price=price;
        this.newPrice=newPrice;
        this.minRoadTax=minRoadTax;
        this.maxRoadTax=maxRoadTax;
        this.bodyType=bodyType;
        this.transmission=transmission;
        this.noOfseats=noOfseats;
        this.segment=segment;
        this.intro=intro;
        this.end=end;

    }
    public String getCarName(){
        return carName;
    }

    public String toString(){
        String val= "car name: " + carName + " "+
                "|price: "+ price+ " "+
                "|new price: " +newPrice+ " "+
                "|road tax/3: "+minRoadTax+ "-"
                + maxRoadTax+ " "+
                "|body type: " +bodyType+ " "+
                "|transmission: "+transmission+" "+
                "|no of seats: " + noOfseats+ " "+
                "|segment: " +segment+ " "+
                "|intro: "  +intro+ " "+
                "|end: "+ end;

        return val;
    }
}
