import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
        File file = new File("C:\\Users\\zaram\\IdeaProjects\\oop lab 8.1\\src\\cars_13422_.txt");
        FileWriter writer=new FileWriter("src\\writeCars.txt");
        Scanner sc = new Scanner(file);
        Car[] carArray = new Car[4];
        int count = 0;

        while (sc.hasNext()) {
            String carname = sc.nextLine();
            sc.skip("Price:\t\t\t€ ");
            double price = sc.nextDouble();
            sc.nextLine();
            sc.skip("New Price Roadworthy:\t€ ");
            double newPrice = sc.nextDouble();
            sc.nextLine();
            sc.skip("Road Tax / 3 Months:\t€ ");
            int minRoadTax = sc.nextInt();
            sc.skip(" - € ");
            int maxRoadTax = sc.nextInt();
            sc.nextLine();
            sc.skip("Body Type:\t\t");
            String bodyType = sc.nextLine();
            sc.skip("Transmission:\t\t");
            String transmission = sc.nextLine();
            sc.skip("Number Of Seats:\t");
            int noOfseats = sc.nextInt();
            sc.nextLine();
            sc.skip("Segment:\t\t");
            String segment = sc.nextLine();
            sc.skip("Introduction:\t\t");
            String intro = sc.nextLine();
            sc.skip("End:\t\t\t");
            String end = sc.nextLine();
            sc.nextLine();

            carArray[count] = new Car(carname, price, newPrice, minRoadTax, maxRoadTax, bodyType, transmission, noOfseats, segment, intro, end);
            count++;
        }
        sc.close();
        for (int i = 0; i < carArray.length; i++) {
            System.out.println(carArray[i].toString());
        }
        Scanner input=new Scanner(System.in);
        System.out.println("input how many cars you want to store in the other file");
        int user= input.nextInt();
        for (int i = 0; i < user; i++){
            writer.write(carArray[i].toString()+ "\n");
        }
        writer.close();
    }
}