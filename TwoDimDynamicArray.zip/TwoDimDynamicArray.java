public class TwoDimDynamicArray {
    int currRowIn;
    int currColumnIn;
    int[][] arr;

    public TwoDimDynamicArray(int rows, int cols) {
        int i;
        int j;

        if (rows > 0 && cols > 0) {
            arr = new int[rows][cols];
            currRowIn = rows - 1;
            currColumnIn = cols - 1;

            for (i = 0; i < arr.length; i++) {
                for (j = 0; j < arr[i].length; j++) {
                    this.arr[i][j] = (int) (Math.random() * 9) + 1;
                }
            }
        }
    }

    public void appendRow(int[] rowArray) {
        System.out.println("current column index value: " + currColumnIn);
        if (rowArray.length >= currColumnIn + 1) {
            int prevColInd = currColumnIn + 1;
            if (arr[0].length != prevColInd) {
                prevColInd = prevColInd + 2;
            }
            int[][] temp;
            if (arr.length == currRowIn + 1) {
                temp = new int[(currRowIn + 1) * 2][prevColInd];

                for (int i = 0; i < arr.length; i++) {
                    for (int j = 0; j < arr[0].length; j++) {
                        temp[i][j] = 0;
                    }
                }
                for (int i = 0; i <= this.currRowIn; i++) {
                    for (int j = 0; j <= this.currColumnIn; j++) {
                        temp[i][j] = this.arr[i][j];
                    }
                }
                this.arr = temp;
            }
            currRowIn = currRowIn + 1;
            for (int j = 0; j < rowArray.length; j++) {
                    arr[currRowIn + 1][j] = rowArray[j];
                }
             /*else if (currRowIn < arr.length) {
                System.arraycopy(rowArray, 0, arr[currRowIn + 1], 0, rowArray.length);
                currRowIn = currRowIn + 1;*/
            }
         else {
            System.out.println("Row cannot be appended");
        }
    }

    public void appendColumn(int[] newColumn) {
        System.out.println("current row index value: " + this.currRowIn);

        if (newColumn.length >= this.currRowIn + 1) {
            int prevRowInd = this.currRowIn + 1;
            if (this.arr.length != prevRowInd) {
                prevRowInd = prevRowInd + 2;
            }
            int[][] temp = new int[0][];
            if (arr[0].length == this.currColumnIn + 1) {
                 temp = new int[prevRowInd][(this.currColumnIn + 1) * 2];

                for (int i = 0; i < this.arr.length; i++) {
                    for (int j = 0; j < this.arr[0].length; j++) {
                        temp[i][j] = 0;
                    }
                }
                for (int i = 0; i <= this.currRowIn; i++) {
                    for (int j = 0; j <= this.currColumnIn; j++) {
                        temp[i][j] = this.arr[i][j];
                    }
                }
                this.arr = temp;
            }
            this.currColumnIn = this.currColumnIn + 1;
            for (int k = 0; k < newColumn.length; k++) {
                    arr[k][this.currColumnIn] = newColumn[k];
                }
            } /*else if (currColumnIn < arr.length) {
                System.arraycopy(newColumn, 0, arr[currRowIn + 1], 0, newColumn.length);
                this.currRowIn = this.currRowIn + 1;*/
        else{
        System.out.println("Column cannot be appended");
    }

}
    public void ToString() {
        for (int[] ints : arr) {
            for (int j = 0; j < arr[0].length; j++) {
                System.out.print(ints[j] + " ");
            }
            System.out.println();
        }
    }

    }


