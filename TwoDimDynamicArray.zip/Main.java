public class Main {
    public static void main(String[] args) {
        TwoDimDynamicArray Arr = new TwoDimDynamicArray (3, 3);
        Arr.ToString();
       for(int i=0; i<5;i++){
        Arr.appendColumn(new int[]{3,6,9});
        Arr.ToString();
       }
        for(int i=0; i<6;i++){
            Arr.appendRow(new int[]{ 1,9,4,5,6});
            Arr.ToString();
        }
    }
}
