import java.util.Iterator;

public class Administrator extends Products {
    String name;
    String category;
    String price;

    public void addItems (String name,String category, String price){
        a.add(category);
        a.add(name);
        a.add(price);
    }
    public void removeItem(String name, String category, String price){
        Iterator iter = a.iterator();
        while(iter.equals(category))
            if(a.get(a.indexOf(category) + 1)==name){
                a.remove(Integer.parseInt(a.get(a.indexOf(category))));
                a.remove(Integer.parseInt(a.get(a.indexOf(category)+1)));
                a.remove(Integer.parseInt(a.get(a.indexOf(category)+2)));

            }


    }
}
