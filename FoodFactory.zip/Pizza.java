public class Pizza {
    private int size;
    private int noCheese;
    private int noPepperoni;
    private int noHam;
    public Pizza(int size, int noCheese, int noPepperoni, int noHam){
        this.size=size;
        this.noCheese=noCheese;
        this.noPepperoni=noPepperoni;
        this.noHam=noHam;

    }

    public void setSize(int size) {
        this.size = size;
    }

    public void setNoCheese(int noCheese) {
        this.noCheese = noCheese;
    }

    public void setNoPepperoni(int noPepperoni) {
        this.noPepperoni = noPepperoni;
    }

    public void setNoHam(int noHam) {
        this.noHam = noHam;
    }

    public int getSize() {
        return size;
    }

    public int getNoCheese() {
        return noCheese;
    }

    public int getNoPepperoni() {
        return noPepperoni;
    }

    public int getNoHam() {
        return noHam;
    }
    public double calcCost(){
        double cost=0.0;
        double sum= getNoHam()+getNoCheese()+getNoPepperoni();
        if(size==1){
            cost=10+(2*sum);
        }
        else if(size==2){
            cost=12+(2*sum);
        }
        if(size==3){
            cost=14+(2*sum);
        }
        return cost;
    }

    public String getDescription(){
        return "you've ordered a size "+getSize()+ " pizza with "+getNoPepperoni()+" pepperoni, "+getNoCheese()+" cheese and "+getNoHam()+ " ham";
    }
}
