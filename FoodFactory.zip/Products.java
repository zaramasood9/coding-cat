import java.util.ArrayList;
import java.util.Iterator;

public class Products {
    static ArrayList<String> a = new ArrayList<>();
    public  void defaultItems() {
        a.add("washing");
        a.add("powder");
        a.add("10");

        a.add("eating");
        a.add("vegetable");
        a.add("20");

        a.add("wearing");
        a.add("shirt");
        a.add("5");
    }
    public void getDescription(){
        Iterator iter = a.iterator();
        while(iter.hasNext())
            System.out.println(iter.next());

    }
}
