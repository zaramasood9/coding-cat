public class Main {
    public static void main(String[] args) {
        Pizza[] order= new Pizza[3];
        order [0]= new Pizza(1,4,6,7);
        order [1]= new Pizza(2,0,1,0);
        order [2]= new Pizza(3,1,1,2);

        double sum=0;

        for(int i=0;i<order.length;i++){
            System.out.println(order[i].calcCost());
        }
        for(int i=0;i<order.length;i++) {
            System.out.println(order[i].getDescription());
        }
        for(int i=0; i<order.length;i++){
            sum= sum+ order[i].calcCost();
        }
        System.out.println("your total bill is "+ sum);
    }
}
