import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Customers extends Products {
    public static void main(String[] args) {
        int cost=0;
        boolean add=false;

        Scanner input= new Scanner(System.in);
        ArrayList<String> cart = new ArrayList<>();
        Products obj = new Products();

        obj.defaultItems();
        obj.getDescription();
        Iterator iter =a.iterator();
        do {
            add = false;
            System.out.println("Kindly chose category");
            String select = input.next();
            if (a.get(a.indexOf(select)).equals(select)) {
                    cost = cost + Integer.parseInt((a.get(a.indexOf(select) + 2)));
                    System.out.println(cost);
                    //iter.next();
                }

                System.out.println("Continue adding?");
                if (input.next().equals("y")) {
                    add = true;
                }
            System.out.println("total cost is" + cost);


        }
            while (add) ;


        }}



