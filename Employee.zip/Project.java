import java.util.ArrayList;
import java.util.Iterator;

public class Project {
    private int linesOfCode;
    private int linesOfCodeWritten;
    private int linesOfCodeTested;
    private int duration;
    private ArrayList<Employee> list= new ArrayList<>();

    public Project(int linesOfCode, int duration){
        this.linesOfCode=linesOfCode;
        this.duration=duration;
    }
    public void addEmployee(Employee e){
        list.add(e);
    }
    public int doProject(){
        int count=0;
   do{
        Iterator<Employee> iter= list.iterator();
        while(iter.hasNext()) {

            Employee e= iter.next();
            if (e instanceof Programmer) {
                linesOfCodeWritten = e.work();
                System.out.println(linesOfCodeWritten);
            }
            else{
                linesOfCodeTested = e.work();
                System.out.println(linesOfCodeTested);
            }

            count++;
        }
        if(count<duration){
            list.add(new Programmer("rahul", 43, 22, 80));
            list.add(new Tester("meghan", 43, 22));
            list.add(new Programmer("polly", 45, 22, 80));
            list.add(new Tester("sneha", 56, 22));
        }

    } while(count<duration);
        return (count-duration);
}}
