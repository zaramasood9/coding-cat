public class Main {
    public static void main(String[] args) {
        Project project1= new Project(10000,48);
        project1.addEmployee(new Programmer("becky", 007,50, 10));
        project1.addEmployee(new Tester("bobby", 003, 30));
        //project1.addEmployee(new Tester("rob", 002, 20));
        System.out.println("more hours: "+ project1.doProject());
    }
}
