public class Programmer extends Employee  {
    private int linesOfCodePerDay;
    private int rate;
    private int time;
    public Programmer(String name, int id, int rate, int time){
        super(name,id);
        this.rate=rate;
        this.time=time;
    }

    @Override
    public int work() {
        int linesOfCodePerDay= (int) (500+(Math.random()*1501));
        return linesOfCodePerDay;
    }

    @Override
    public int salary() {
        int tamount=rate*time*work();
        return tamount;
    }
}
