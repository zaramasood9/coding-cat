public class Tester extends Employee{
    private int linesOfCodePerDay;
    private int rate;
    public Tester(String name, int id, int rate){
        super(name, id);
        this.rate=rate;
    }
    @Override
    public int work() {
        int linesOfCodePerDay= (int) (150+ (Math.random()*251));
        return linesOfCodePerDay;
    }

    @Override
    public int salary() {
        int tamount=rate*work();
        return tamount ;
    }
}
