import java.util.Random;

public class Weapon {
    private int strength;
    private int agility;
    private int range;

    public Weapon() {
        Random random = new Random();
        int totalPoints = 6;
        this.strength = random.nextInt(totalPoints);
        totalPoints -= this.strength;
        this.agility = random.nextInt(totalPoints);
        this.range = totalPoints - this.agility;
    }

    public int getStrength() {
        return strength;
    }
    public int getAgility() {
        return agility;
    }

    public int getRange() {
        return range;
    }
    public static void main(String[] args) {
        Warrior warrior = new Warrior("John", "Smith", "Dragon");
        System.out.println(warrior);
    }
}

