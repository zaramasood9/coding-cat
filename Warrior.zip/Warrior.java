import java.util.Random;

public class Warrior {
    private int strength;
    private int agility;
    private int range;
    private String name;
    private String fatherName;
    private String nickname;
    private boolean alive;
    private int heart;
    private int blood;
    private Weapon weapon;

    public Warrior(String name, String fatherName, String nickname) {
        this.name = name;
        this.fatherName = fatherName;
        this.nickname = nickname;
        assignAttributes();
        this.heart = 1;
        this.blood = 100;
        this.alive = true;
        this.weapon = new Weapon();
    }
    private void assignAttributes() {
        Random random = new Random();
        int totalPoints = random.nextInt(10) + 1;
        this.strength = random.nextInt(totalPoints);
        totalPoints -= this.strength;
        this.agility = random.nextInt(totalPoints);
        this.range = totalPoints - this.agility;
    }

    private int getTotalStrength() {
        return strength + weapon.getStrength();
    }

    private int getTotalAgility() {
        return agility + weapon.getAgility();
    }

    private int getTotalRange() {
        return range + weapon.getRange();
    }

    public void takeDamage(int damage) {
        blood -= damage;
        if (blood <= 30) {
            heart = 0;
            alive = false;
        }
    }
    @Override
    public String toString() {
        String status = alive ? "Alive" : "Dead";
        return "Warrior Details:\n" +
                "Name: " + name + "\n" +
                "Father's Name: " + fatherName + "\n" +
                "Nickname: " + nickname + "\n" +
                "Strength: " + getTotalStrength() + "\n" +
                "Agility: " + getTotalAgility() + "\n" +
                "Range: " + getTotalRange() + "\n" +
                "Heart: " + heart + "\n" +
                "Blood: " + blood + "\n" +
                "Status: " + status;
    }


}
