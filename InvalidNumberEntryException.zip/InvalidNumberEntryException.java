public class InvalidNumberEntryException extends Exception{

    private String message;
    public InvalidNumberEntryException(String message){
        this.message = message;
    }
    public String toString(){
        return message;
    }
}