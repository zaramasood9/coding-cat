import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input= new Scanner(System.in);
        String n1;
        String n2;


           System.out.println("Enter numbers 1");
        n1=input.next();
        System.out.println("Enter numbers 2");
        n2=input.next();
        Integer m1 = null;
        try{
        Valid(n1,n2);
            multiply(n1,n2);
        }

        catch(Exception e){
            System.out.println(e.toString());
            int count=0;

            if ((n1.charAt(0)>=48) && (n1.charAt(0)<=57)){
                count=(Integer.parseInt(n1));
                for(int i=0;i<count;i++){
                    System.out.println(n2+"");
                }
            }

     else{
                int s2=Integer.parseInt(n2);
                count=s2;

                for (int i = 0; i < count; i++) {
                    System.out.println(n1 + "");
                }
            }
        }}

    public static void Valid(String n1, String n2) throws InvalidNumberEntryException {
        if((n1.charAt(0)>=65) && (n1.charAt(0)<=90)) {
            throw new InvalidNumberEntryException("n1 is a String");
        }
        else if(((n2.charAt(0)>=65) && (n2.charAt(0)<=90)) ) {
            throw new InvalidNumberEntryException("n2 is a String");
        }
    }
    public static void multiply(String n1, String n2){
        int prod=0;
        prod= Integer.parseInt(n1)* Integer.parseInt(n2);
        System.out.println(prod);
    }


}



