

import javax.swing.*;
import java.awt.*;
import java.awt.image.ImageObserver;


public class LayerBar extends Rectangle implements PortionListener {

    private ButtonActive add;
    private ButtonActive remove;
    private ButtonActive up;
    private ButtonActive down;

    private MyLinkedList layersButton;
    private ButtonLayer currentButton;
    private int currentIndex = 1;
    private int i = 1;
    private int layerNum = 1;
    private boolean press = false;


    public LayerBar(int x, int y, int width, int height) {

        super(x, y, width, height);

        add = new ButtonActive(x+8, y+64, 36, 36, false, new ImageIcon("add.png").getImage(), true);
        remove = new ButtonActive(x+16+width/5, y+64, 36, 36, false, new ImageIcon("remove.png").getImage(), true);
        up = new ButtonActive(x+24+(2*width/5), y+64, 36, 36, false, new ImageIcon("up.png").getImage(), true);
        down = new ButtonActive(x+32+(3*width/5), y+64, 36, 36, false, new ImageIcon("down.png").getImage(), true);

        layersButton = new MyLinkedList(8);

        layersButton.add(new ButtonLayer(x+8, y+112, width-16, height/12, false, "Layer- " + layerNum));
        layerNum++;
    }

    public void swap(ButtonLayer b1, ButtonLayer b2){
        int y = b1.getY();
        b1.setY(b2.getY());
        b2.setY(y);
    }


    public void paint(Graphics g, ImageObserver observer){
        super.paint(g);
        g.setColor(Color.GRAY);
        g.fillRect(x, y, width-2, 48);

        g.drawImage(new ImageIcon("layerbar.png").getImage(), x+16, y+4, observer);

        Font font = new Font("Times New Roman", Font.BOLD, 28);
        g.setFont(font);
        g.setColor(Color.BLACK);
        FontMetrics m = g.getFontMetrics();
        int s_wdith = m.stringWidth("Layer Panel");
        int s_height = m.getAscent() - m.getDescent();
        g.drawString("Layer Panel", x + (width-2) / 2 - s_wdith*1/3, y + 48 / 2 + s_height / 2);

        add.paint(g, observer);
        remove.paint(g, observer);
        up.paint(g, observer);
        down.paint(g, observer);

        for (int j = 0; j < i; j++) {
            layersButton.getIndex(j).paint(g, observer);
        }

    }

    public boolean isPressed(int x ,int y){
        if(x > this.x && x < this.x + width && y > this.y && y < this.y + height) {
            return true;
        }
        return false;
    }

    @Override
    public void onClick(int x, int y) {
        for (int j = 0; j < i; j++) {
            if(layersButton.getIndex(j).IsClicked(x, y)) {
                currentIndex = j;
                for (int k = 0; k < i; k++) {
                    layersButton.getIndex(k).setPressed(false);
                    layersButton.getIndex(k).setCurrentUnpressed();
                }
                layersButton.getIndex(j).setPressed(true);
                layersButton.getIndex(j).setCurrentPressed();
                currentButton = layersButton.getIndex(j);
            }

            if(layersButton.getIndex(j).isPressedFirst) currentButton = null;
        }

        if(add.IsClicked(x, y) && !layersButton.isFull()){
            layersButton.add(new ButtonLayer(this.x+8, this.y+112+i*(height/12)-(2*i), width-16, height/12, false, "Layer " + layerNum));
            i++; layerNum++;
        }

        if(remove.IsClicked(x, y) && !layersButton.isEmpty() && i != 1){
            if (currentButton != null) {
                if(layersButton.getNext(currentButton) != null) {
                    for (int j = currentIndex; j < i; j++) {
                        if (layersButton.getNext(layersButton.getIndex(j)) != null)
                            swap(currentButton, layersButton.getNext(layersButton.getIndex(j)));
                    }
                }
                layersButton.remove(currentButton);
                currentButton = null;
                i--;
            }
        }

        if(up.IsClicked(x, y) && currentButton != null){
            ButtonLayer b = layersButton.getPrevious(currentButton);
            if(!layersButton.isFirstElement(currentButton)) swap(currentButton, b);
            layersButton.moveUp(currentButton);
        }

        if(down.IsClicked(x, y) && currentButton != null){
            ButtonLayer b = layersButton.getNext(currentButton);
            if (!layersButton.isLastElement(currentButton)) swap(currentButton, b);
            layersButton.moveDown(currentButton);

        }

    }

    @Override
    public void onPress(int x, int y) {

    }

    @Override
    public void onRelease(int x, int y) {

    }

    @Override
    public void onMove(int x, int y) {

        if(add.isPressed(x, y)) add.setPressed(true);
        else add.setPressed(false);


        if(remove.isPressed(x, y)) remove.setPressed(true);
        else remove.setPressed(false);

        if(up.isPressed(x, y)) up.setPressed(true);
        else up.setPressed(false);

        if(down.isPressed(x, y)) down.setPressed(true);
        else down.setPressed(false);

        for (int j = 0; j < i; j++) {
            if(layersButton.getIndex(j).isPressed(x, y)) layersButton.getIndex(j).setPressed(true);
            else layersButton.getIndex(j).setPressed(false);


        }

    }
}

