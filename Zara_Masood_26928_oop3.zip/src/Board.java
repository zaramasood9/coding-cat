

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.event.MouseInputListener;

public class Board extends JPanel
        implements ActionListener , MouseInputListener{

    private final int B_WIDTH = 1080;
    private final int B_HEIGHT = 680;

    private final int DELAY = 10;
    private Timer timer;
    public static boolean windowOpened = false;

    private MyMenu myMenuBar;
    private ColorBar myColorBar;
    private ShapePanel myShapeBar;
    private LayerBar myLayerBar;
    private DrawingBoard myDrawingBoard;

    private class TAdapter extends KeyAdapter {

        @Override
        public void keyReleased(KeyEvent e) {
            myMenuBar.keyReleased(e);
        }

        @Override
        public void keyPressed(KeyEvent e) {
            myMenuBar.keyPressed(e);
        }
    }

    public Board() {

        initBoard();
    }

    private void InitializeAssets() {


    }

    private void initBoard() {

        addMouseListener( this );
        addMouseMotionListener( this );
        addKeyListener(new TAdapter());
        setBackground(Color.WHITE);
        setPreferredSize(new Dimension(B_WIDTH, B_HEIGHT));
        setFocusable(true);

        InitializeAssets();
        myMenuBar = new MyMenu(0, 0, B_WIDTH, 32);
        myColorBar = new ColorBar(B_WIDTH/5-2, 32, B_WIDTH*3/5, 130);
        myShapeBar = new ShapePanel(0, 32, B_WIDTH/5, 130);
        myLayerBar = new LayerBar(B_WIDTH*4/5-4, 32, B_WIDTH/5 +4, B_HEIGHT-32);
        myDrawingBoard = new DrawingBoard(0, 162, B_WIDTH-B_WIDTH/5 +4, B_HEIGHT-162);

        timer = new Timer(DELAY, this);
        timer.start();
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        myDrawingBoard.paint(g, this);
        myLayerBar.paint(g, this);
        myColorBar.paint(g, this);
        myShapeBar.paint(g, this);
        myMenuBar.paint(g, this);

    }


    @Override
    public void mouseClicked(MouseEvent e) {
        if(!windowOpened) {
            myMenuBar.onClick(e.getX(), e.getY());
            myColorBar.onClick(e.getX(), e.getY());
            myShapeBar.onClick(e.getX(), e.getY());
            myLayerBar.onClick(e.getX(), e.getY());
        }

    }


    // MOUSE LISTENERS
    @Override
    public void mousePressed(MouseEvent e) {
        myMenuBar.onPress(e.getX(), e.getY());
        myColorBar.onPress(e.getX(), e.getY());
        myShapeBar.onPress(e.getX(), e.getY());
        myLayerBar.onPress(e.getX(), e.getY());

    }

    @Override
    public void mouseReleased(MouseEvent e) {
        myMenuBar.onRelease(e.getX(), e.getY());
        myColorBar.onRelease(e.getX(), e.getY());
        myShapeBar.onRelease(e.getX(), e.getY());
        myLayerBar.onRelease(e.getX(), e.getY());
    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mouseDragged(MouseEvent e) {
        myColorBar.onDrag(e.getX(), e.getY());


    }

    @Override
    public void mouseMoved(MouseEvent e) {
        myColorBar.onMove(e.getX(), e.getY());
        myMenuBar.onMove(e.getX(), e.getY());
        myLayerBar.onMove(e.getX(), e.getY());
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Toolkit.getDefaultToolkit().sync();
        repaint();
    }
}
