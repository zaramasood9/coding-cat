import java.awt.*;
import java.awt.image.ImageObserver;


public class Rectangle {

    int x;
    int y;
    int width;
    int height;

    public Rectangle(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public void paint(Graphics g){
        g.setColor(Color.black);

        g.fillRect(x, y, width, height);
        g.setColor(Color.WHITE);
        g.fillRect(x+2, y, width-4, height-2);
    }
}

