import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.image.ImageObserver;
import java.util.ArrayList;




public class MyMenu extends Rectangle implements PortionListener {

    private ButtonActive fileButton;
    private ButtonActive editButton;
    private ArrayList<ButtonActive> fileDropDown = new ArrayList<>();
    private ArrayList<ButtonActive> editDropDown = new ArrayList<>();
    private OpenWindow myOpenWindow;

    private boolean showFileDropdown = false;
    private boolean showEditDropdown = false;
    private boolean filePress = false;
    private boolean filePressed = false;
    private boolean editPress = false;
    private boolean editPressed = false;
    private boolean showOpenWindow = false;
    private boolean showSaveWindow = false;
    private boolean showNewWindow = false;
    private boolean showUndo = false;
    private boolean showRedo = false;

    public MyMenu(int x, int y, int width, int height) {
        super(x, y, width, height);

        fileButton = new ButtonActive(0,0 , 64, 32, false, "File", Color.BLACK, true);
        editButton = new ButtonActive(64,0 , 64, 32, false, "Edit", Color.BLACK, true);

        fileDropDown.add(new ButtonActive(0, 32, 128, 44, false, new ImageIcon("denew.jpg").getImage(), new ImageIcon("new.jpg").getImage()));
        fileDropDown.add(new ButtonActive(0, 76, 128, 44, false, new ImageIcon("deopen.jpg").getImage(), new ImageIcon("open.jpg").getImage()));
        fileDropDown.add(new ButtonActive(0, 120, 128, 44, false, new ImageIcon("unsave.jpg").getImage(), new ImageIcon("save.jpg").getImage()));

        editDropDown.add(new ButtonActive(68, 32, 128, 44, false, new ImageIcon("deundo.png").getImage(), new ImageIcon("undo.png").getImage()));
        editDropDown.add(new ButtonActive(68, 76, 128, 44, false, new ImageIcon("deredo.png").getImage(), new ImageIcon("redo.png").getImage()));

        myOpenWindow = new OpenWindow(340, 170, 400, 340);
        /* 'n' = new
           'o' = open
           's' = save
           'z' = undo
           'r' = redo
         */
    }

    public void paint(Graphics g, ImageObserver observer){
        if(showFileDropdown){
            for (ButtonActive b : fileDropDown){
                b.paint(g, observer);
            }
        }else if(showEditDropdown){
            for (ButtonActive b : editDropDown){
                b.paint(g, observer);
            }
        }
        super.paint(g);

        fileButton.paint(g, observer);
        editButton.paint(g, observer);

        if(showOpenWindow) myOpenWindow.paint(g, observer);
        if(showNewWindow){
            Font font = new Font("Times New Roman", Font.PLAIN, 24);
            g.setFont(font);
            g.setColor(Color.BLACK);
            g.drawString("New File", 8, 650);
        }
        if(showSaveWindow){
            Font font = new Font("Times New Roman", Font.PLAIN, 24);
            g.setFont(font);
            g.setColor(Color.BLACK);
            g.drawString("Saved", 8, 650);
        }
        if(showUndo){
            Font font = new Font("Times New Roman", Font.PLAIN, 24);
            g.setFont(font);
            g.setColor(Color.BLACK);
            g.drawString("Undone", 8, 650);
        }
        if(showRedo){
            Font font = new Font("Times New Roman", Font.PLAIN, 24);
            g.setFont(font);
            g.setColor(Color.BLACK);
            g.drawString("Redone", 8, 650);
        }

    }

    public boolean isPressed(int x ,int y){
        if(x > this.x && x < this.x + width && y > this.y && y < this.y + height) {
            return true;
        }
        return false;
    }

    @Override
    public void onClick(int x, int y) {
        showSaveWindow = false;
        showNewWindow = false;
        showUndo = false;
        showRedo = false;
        if(fileButton.IsClicked(x, y)) {
            filePress = true;
            filePressed = true;
            showEditDropdown = false;
            showFileDropdown = true;
        }else {
            filePress = false;
            showFileDropdown = false;
        }

        if(filePressed) {
            if (fileDropDown.get(0).IsClicked(x, y)) {
                showNewWindow = true;
                filePressed = false;
            }
            if (fileDropDown.get(1).IsClicked(x, y)) {
                showOpenWindow = true;
                filePressed = false;
                myOpenWindow.setOpenButtonPressed(true);
                myOpenWindow.setClosed(false);
            }else showOpenWindow = false;
            if (fileDropDown.get(2).IsClicked(x, y)) {
                showSaveWindow = true;
                filePressed = false;
            }
        }

        myOpenWindow.onClick(x, y);

        if(editButton.IsClicked(x, y)) {
            editPress = true;
            editPressed = true;
            showFileDropdown = false;
            showEditDropdown = true;

        }else {
            editPress = false;
            showEditDropdown = false;
        }

        if(editPressed) {

            if (editDropDown.get(0).IsClicked(x, y)) {
                showUndo = true;
                editPressed = false;
            }
            if (editDropDown.get(1).IsClicked(x, y)) {
                showRedo = true;
                showOpenWindow = false;
                editPressed = false;
            }
        }


    }

    @Override
    public void onPress(int x, int y) {

    }

    @Override
    public void onRelease(int x, int y) {
    }

    @Override
    public void onMove(int x, int y) {
        if(fileButton.isPressed(x, y)) {
            fileButton.setPressed(true);
            editButton.setPressed(false);
            showEditDropdown = false;
        } else{
            if(!filePress) fileButton.setPressed(false);
        }

        if(editButton.isPressed(x, y) && !editPress) {
            editButton.setPressed(true);
            fileButton.setPressed(false);
            showFileDropdown = false;
        } else {
            if(!editPress) editButton.setPressed(false);

        }

        for (ButtonActive b : fileDropDown)b.IsClicked(x, y);
        for (ButtonActive b : editDropDown)b.IsClicked(x, y);

        myOpenWindow.onMove(x, y);
    }

    public void keyReleased(KeyEvent e) {
        if (e.getKeyChar() == 'n') {
            showNewWindow = false;
        }
        if (e.getKeyChar() == 's') {
            showSaveWindow = false;
        }

        if (e.getKeyChar() == 'z') {
            showUndo = false;
        }

        if (e.getKeyChar() == 'r') {
            showRedo = false;
        }
    }

    public void keyPressed(KeyEvent e) {
        if (e.getKeyChar() == 'n') {
            showNewWindow = true;
        }
        if (e.getKeyChar() == 'o') {
            showOpenWindow = true;
            myOpenWindow.setClosed(false);
            myOpenWindow.setOpenButtonPressed(true);
        }
        if (e.getKeyChar() == 's') {
            showSaveWindow = true;
        }
        if (e.getKeyChar() == 'z') {
            showUndo = true;
        }
        if (e.getKeyChar() == 'r') {
            showRedo = true;
        }
    }
}

