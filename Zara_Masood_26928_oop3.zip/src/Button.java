import java.awt.*;
import java.awt.image.ImageObserver;

    public abstract class Button{

        protected int x;
        protected int y;
        protected int width;
        protected int height;

        protected boolean isPressed;

        public Button(int x, int y, int width, int height, boolean isPressed) {
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
            this.isPressed = isPressed;
        }

        public abstract void paint(Graphics graphics, ImageObserver imageObserver);

    }


