import javax.swing.*;
import java.awt.*;
import java.awt.image.ImageObserver;


public class ShapePanel extends Rectangle implements PortionListener {

    private ButtonToggle circle;
    private ButtonToggle rectangle;
    private ButtonToggle rightTriangle;
    private ButtonToggle equTriangle;
    private ButtonToggle pentagon;
    private ButtonToggle hexagon;
    private ButtonToggle pencil;
    private ButtonToggle strokeWidth;

    private int buttonSize = 30;

    public ShapePanel(int x, int y, int width, int height) {
        super(x, y, width, height);


        circle = new ButtonToggle(x+(width*1)/7, y+16, buttonSize, buttonSize, false, new ImageIcon("circle.png").getImage());
        rectangle = new ButtonToggle(x+(width*1)/7 + (1 * buttonSize)+16, y+16, buttonSize, buttonSize, false, new ImageIcon("rectangle.png").getImage());
        rightTriangle = new ButtonToggle(x+(width*1)/7 + (2 * buttonSize)+32, y+16, buttonSize, buttonSize, false, new ImageIcon("regTriangle.png").getImage());
        pencil = new ButtonToggle(x+(width*1)/7 + (3 * buttonSize)+48, y+16, buttonSize, buttonSize, false, new ImageIcon("pencil.png").getImage());
        equTriangle = new ButtonToggle(x+(width*1)/7, y+32+buttonSize, buttonSize, buttonSize, false, new ImageIcon("triangle.png").getImage());
        pentagon = new ButtonToggle(x+(width*1)/7 + (1 * buttonSize)+16, y+32+buttonSize, buttonSize, buttonSize, false, new ImageIcon("pentagon.png").getImage());
        hexagon = new ButtonToggle(x+(width*1)/7 + (2 * buttonSize)+32, y+32+buttonSize, buttonSize, buttonSize, false, new ImageIcon("hexagon.png").getImage());
        strokeWidth = new ButtonToggle(x+(width*1)/7 + (3 * buttonSize)+48, y+32+buttonSize, buttonSize, buttonSize, false, new ImageIcon("lineThick.png").getImage());

    }


    public void paint(Graphics g, ImageObserver observer){
        super.paint(g);

        Font font = new Font("Times New Roman", Font.PLAIN, 16);
        g.setFont(font);
        g.setColor(Color.BLACK);

        g.drawString("Shape Panel", x+(width*1)/6+50, 150);

        circle.paint(g, observer);
        rectangle.paint(g, observer);
        equTriangle.paint(g, observer);
        pencil.paint(g, observer);
        rightTriangle.paint(g, observer);
        hexagon.paint(g, observer);
        pentagon.paint(g, observer);
        strokeWidth.paint(g, observer);


    }

    @Override
    public void onClick(int x, int y) {
        if(circle.IsClicked(x, y)) {
            strokeWidth.setPressed(false);
            pencil.setPressed(false);circle.setPressed(true);
            rectangle.setPressed(false);
            equTriangle.setPressed(false);
            rightTriangle.setPressed(false);
            pentagon.setPressed(false);
            hexagon.setPressed(false);
        }else if(rectangle.IsClicked(x, y)) {
            strokeWidth.setPressed(false);
            pencil.setPressed(false);
            circle.setPressed(false);
            rectangle.setPressed(true);
            equTriangle.setPressed(false);
            rightTriangle.setPressed(false);
            pentagon.setPressed(false);
            hexagon.setPressed(false);
        }else if(equTriangle.IsClicked(x, y)) {
            strokeWidth.setPressed(false);
            pencil.setPressed(false);
            circle.setPressed(false);
            rectangle.setPressed(false);
            equTriangle.setPressed(true);
            rightTriangle.setPressed(false);
            pentagon.setPressed(false);
            hexagon.setPressed(false);
        }else if(rightTriangle.IsClicked(x, y)) {
            strokeWidth.setPressed(false);pencil.setPressed(false);circle.setPressed(false);rectangle.setPressed(false);equTriangle.setPressed(false);rightTriangle.setPressed(true);pentagon.setPressed(false);hexagon.setPressed(false);
        }else if(pentagon.IsClicked(x, y)) {
            strokeWidth.setPressed(false);pencil.setPressed(false);circle.setPressed(false);rectangle.setPressed(false);equTriangle.setPressed(false);rightTriangle.setPressed(false);pentagon.setPressed(true);hexagon.setPressed(false);
        }else if(hexagon.IsClicked(x, y)) {
            strokeWidth.setPressed(false);pencil.setPressed(false);circle.setPressed(false);rectangle.setPressed(false);equTriangle.setPressed(false);rightTriangle.setPressed(false);pentagon.setPressed(false);hexagon.setPressed(true);
        } else if(pencil.IsClicked(x, y)) {
            strokeWidth.setPressed(false);pencil.setPressed(true);circle.setPressed(false);rectangle.setPressed(false);equTriangle.setPressed(false);rightTriangle.setPressed(false);pentagon.setPressed(false);hexagon.setPressed(false);
        }else if(pencil.IsClicked(x, y)) {
            strokeWidth.setPressed(false);pencil.setPressed(true);circle.setPressed(false);rectangle.setPressed(false);equTriangle.setPressed(false);rightTriangle.setPressed(false);pentagon.setPressed(false);hexagon.setPressed(false);
        }else if(strokeWidth.IsClicked(x, y)) {
            strokeWidth.setPressed(true);pencil.setPressed(false);circle.setPressed(false);rectangle.setPressed(false);equTriangle.setPressed(false);rightTriangle.setPressed(false);pentagon.setPressed(false);hexagon.setPressed(false);
        }
    }

    @Override
    public void onPress(int x, int y) {

    }

    @Override
    public void onRelease(int x, int y) {

    }

    @Override
    public void onMove(int x, int y) {

    }
}
