import java.awt.*;
import java.awt.image.ImageObserver;



public class Window{


    public int x, y, width, height;

    public Window(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;


    }

    public void paint(Graphics g, ImageObserver observer){
        g.setColor(Color.GRAY);
        g.fillRect(x, y, width, height);

        g.setColor(Color.LIGHT_GRAY);
        g.fillRect(x, y+height/9 , width, height-height/9);

    }
}

