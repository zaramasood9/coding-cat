import javax.swing.*;
import java.awt.*;
import java.awt.image.ImageObserver;
import java.util.ArrayList;


public class ColorBar extends Rectangle implements PortionListener {

    private ArrayList<ColorButton> colorButtons = new ArrayList<>();
    private ButtonToggleColor color1;
    private ButtonToggleColor color2;
    private ButtonGradient gradient;
    private GradientWindow gradientWindow;
    private Color customColor = Color.WHITE;
    int i = 8;
    public static boolean showGradientWindow = false;
    private int buttonSize = 30;
    private int button1Size = 80;
    public ColorBar(int x, int y, int width, int height) {
        super(x, y, width, height);

        color1 = new ButtonToggleColor(x+32, y+16, button1Size, button1Size, false, Color.BLACK);
        color2 = new ButtonToggleColor(x+64 + button1Size, y+16, button1Size, button1Size, false, Color.GRAY);

        gradient = new ButtonGradient(x+(width*3)/7 + (3 * buttonSize)+94, y+16, button1Size, button1Size, false, new ImageIcon("gradient.jpg").getImage(), new ImageIcon("gradient.jpg").getImage());
        gradientWindow = new GradientWindow(340, 170, 400, 340);

        colorButtons.add(new ColorButton(x+(width*3)/7, y+8, buttonSize, buttonSize, false, Color.BLACK));
        colorButtons.add(new ColorButton(x+(width*3)/7 + (1 * buttonSize)+4, y+8, buttonSize, buttonSize, false, Color.WHITE));
        colorButtons.add(new ColorButton(x+(width*3)/7 + (2 * buttonSize)+8, y+8, buttonSize, buttonSize, false, Color.RED));
        colorButtons.add(new ColorButton(x+(width*3)/7 + (3 * buttonSize)+12, y+8, buttonSize, buttonSize, false, Color.BLUE));
        colorButtons.add(new ColorButton(x+(width*3)/7, y+16+buttonSize, buttonSize, buttonSize, false, Color.CYAN));
        colorButtons.add(new ColorButton(x+(width*3)/7+ (1 * buttonSize)+4, y+16+buttonSize , buttonSize, buttonSize, false, Color.GREEN));
        colorButtons.add(new ColorButton(x+(width*3)/7+ (2 * buttonSize)+8, y+16+buttonSize , buttonSize, buttonSize, false, Color.PINK));
        colorButtons.add(new ColorButton(x+(width*3)/7+ (3 *buttonSize)+12, y+16+buttonSize , buttonSize, buttonSize, false, Color.MAGENTA));
        colorButtons.add(new ColorButton(x+(width*3)/7, y+24+2*buttonSize , buttonSize, buttonSize, false, Color.LIGHT_GRAY));
        colorButtons.add(new ColorButton(x+(width*3)/7+(1 * buttonSize)+4, y+24+2*buttonSize , buttonSize, buttonSize, false, Color.LIGHT_GRAY));
        colorButtons.add(new ColorButton(x+(width*3)/7+(2 * buttonSize)+8, y+24+2*buttonSize , buttonSize, buttonSize, false, Color.LIGHT_GRAY));
        colorButtons.add(new ColorButton(x+(width*3)/7+(3 * buttonSize)+12, y+24+2*buttonSize , buttonSize, buttonSize, false, Color.LIGHT_GRAY));
    }

    public void paint(Graphics graphics, ImageObserver observer){
        super.paint(graphics);

        Font font = new Font("Times New Roman", Font.PLAIN, 16);
        graphics.setFont(font);
        graphics.setColor(Color.BLACK);

        graphics.drawString("Color 1", x+44, 150);
        graphics.drawString("Color 2", x+76 + button1Size, 150);
        graphics.drawString("Color Gradient", x+(width*3)/7 + (3 * buttonSize)+94, 150);

        color1.paint(graphics, observer);
        color2.paint(graphics, observer);

        gradient.paint(graphics, observer);

        for (ColorButton b : colorButtons){
            b.paint(graphics, observer);
        }

        if(showGradientWindow) gradientWindow.paint(graphics, observer);

    }

    public boolean isPressed(int x ,int y){
        if(x > this.x && x < this.x + width && y > this.y && y < this.y + height) {
            return true;
        }
        return false;
    }

    @Override
    public void onClick(int x, int y) {
        if(gradient.IsClicked(x, y)) {
            showGradientWindow = true;
            gradientWindow.setGradientPressed(true);
            gradientWindow.setClosed(false);
        }

        gradientWindow.onClick(x, y);

        if(gradientWindow.gradientSelect.IsClicked(x, y ) && gradientWindow.isGradientPressed()) {
            if (i > colorButtons.size() - 1) i = 8;
            colorButtons.get(i).setBoxColor(gradientWindow.getCurrentColor());
            i++;
            gradientWindow.setGradientPressed(false);
        }


        if(color1.IsClicked(x, y)){
            color1.setPressed(true);
            color2.setPressed(false);
        }else if(color2.IsClicked(x, y)){
            color2.setPressed(true);
            color1.setPressed(false);
        }

        for(ColorButton b : colorButtons){
            if(b.isPressed(x, y)){
                if(color1.getPressed()) color1.setBoxColor(b.getBoxColor());
                else if(color2.getPressed()) color2.setBoxColor(b.getBoxColor());
            }
        }



    }

    @Override
    public void onPress(int x, int y) {

    }

    @Override
    public void onRelease(int x, int y) {

    }

    @Override
    public void onMove(int x, int y) {
        for (ColorButton b : colorButtons){
            b.IsClicked(x, y);
        }

        gradient.IsClicked(x, y);

        gradientWindow.onMove(x, y);
    }

    public void onDrag(int x, int y){
        gradientWindow.onDrag(x, y);
    }
}

