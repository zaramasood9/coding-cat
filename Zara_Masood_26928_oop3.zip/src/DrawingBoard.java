import java.awt.*;
import java.awt.image.ImageObserver;



public class DrawingBoard implements PortionListener {

    private int x, y, width, height;

    public DrawingBoard(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public void paint(Graphics g, ImageObserver observer){
        g.setColor(Color.LIGHT_GRAY);
        g.fillRect(x, y, width, height);
    }

    @Override
    public void onClick(int x, int y) {

    }

    @Override
    public void onPress(int x, int y) {

    }

    @Override
    public void onRelease(int x, int y) {

    }

    @Override
    public void onMove(int x, int y) {

    }
}

