import javax.swing.*;
import java.awt.*;
import java.awt.image.ImageObserver;
import java.io.File;
import java.util.ArrayList;



public class OpenWindow extends Window implements PortionListener{

    private boolean isClosed = false;

    protected ButtonActive close;
    private ButtonActive select;
    private String[] filer;
    private boolean press = false;
    private boolean openPressed = false;

    private ArrayList<ButtonToggle> fileButton;






    public OpenWindow(int x, int y, int width, int height) {
        super(x, y, width, height);
        getFileNames();

        fileButton = new ArrayList<>(filer.length);

        for (int i = 0; i < filer.length; i++) {
            fileButton.add(new ButtonToggle(x+32, y+(height/5)+(i*32)-(2*i), width-64, 32, false, filer[i]));
        }


        close = new ButtonActive(x+width-width/12, y+8, width/12, height/12, false, new ImageIcon("unclose.png").getImage());
        select = new ButtonActive(x+width-width/4, y+height-height/8, width/5, height/10, false, "Open", Color.BLACK, true, true);
    }

    public void paint(Graphics graphics, ImageObserver observer){
        if(!isClosed) {
            super.paint(graphics, observer);

            Font font = new Font("Times New Roman", Font.BOLD, 20);
            graphics.setFont(font);
            graphics.setColor(Color.BLACK);
            graphics.drawString("Open", x+32, y+24);


            close.paint(graphics, observer);
            select.paint(graphics, observer);

            for (ButtonToggle b : fileButton){
                b.paint(graphics, observer);
            }


        }

    }

    public void getFileNames(){

        File folder = new File("C:\\Users\\zaram\\IdeaProjects\\Zara_Masood_26928_oop3\\data");

        File[] files = folder.listFiles();

        filer = new String[files.length];

        for (int i = 0; i < files.length; i++) {
            if (files[i].isFile()) {
                filer[i] = files[i].getName();
            }
        }

    }

    public void setClosed(boolean closed) {
        isClosed = closed;
    }

    public void setOpenButtonPressed(boolean openButtonPressed) {this.openPressed = openButtonPressed;}

    @Override
    public void onClick(int x, int y) {
        if(openPressed) {
            for (ButtonToggle b : fileButton) {
                if (b.IsClicked(x, y)) {
                    for (ButtonToggle b1 : fileButton) {
                        b1.setPressed(false);
                    }
                    b.setPressed(true);
                    press = true;
                }
            }
            if (close.IsClicked(x, y)) {
                isClosed = true;
                openPressed = false;
            }
            if (select.IsClicked(x, y)) {
                if (press) {
                    isClosed = true;
                    openPressed = false;
                    for (ButtonToggle b1 : fileButton) {
                        b1.setPressed(false);
                    }
                    press = false;
                } else isClosed = false;
            }
        }


    }

    @Override
    public void onPress(int x, int y) {

    }

    @Override
    public void onRelease(int x, int y) {

    }

    @Override
    public void onMove(int x, int y) {
        if(openPressed) {
            if (x < this.x || x > this.x + width || y < this.y || y > this.y + height) {
                Board.windowOpened = true;
                return;
            } else Board.windowOpened = false;
        }


        if(select.isPressed(x, y))select.setPressed(true);
        else select.setPressed(false);

        if(close.isPressed(x, y)) close.setPressed(true);
        else close.setPressed(false);

    }
}
