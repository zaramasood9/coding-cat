public abstract class Vehicle {
    String color;
    String model;
    int mileage;
    int price;
    int seat_belt;
    int number_of_wheels;
    Vehicle(String color, int mileage, String model, int price, int number_of_wheels, int seat_belt){
        this.color=color;
        this.model=model;
        this.seat_belt=seat_belt;
        this.number_of_wheels=number_of_wheels;
        this.price=price;
        this.mileage=mileage;
    }
    public abstract void drive();
    public abstract void stop();
    public void self_destruct(){
        System.out.println("Vehicile is destroyed!");
    }

    @Override
    public String toString() {
        return "Vehicile{" +
                "color='" + color + '\'' +
                ", model='" + model + '\'' +
                ", mileage=" + mileage +
                ", price=" + price +
                ", seat_belt=" + seat_belt +
                ", number_of_wheels=" + number_of_wheels +
                '}';
    }
}
