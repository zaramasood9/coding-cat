public class Ford extends Sedan{
    Ford(String color, int mileage, String model, int price, int number_of_wheels, int seat_belt) {
        super(color, mileage, model, price, number_of_wheels, seat_belt);
    }

}
