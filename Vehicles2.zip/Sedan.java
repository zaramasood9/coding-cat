public class Sedan extends Vehicle{

    public Sedan(String color, int mileage, String model, int price,int number_of_wheel, int seatbelt) {
        super(color, mileage, model, price,number_of_wheel,seatbelt);
    }

    @Override
    public void drive() {
        System.out.println("Sedan on a drive");
    }

    @Override
    public void stop() {
        System.out.println("Sedan has been stopped");
    }
}
