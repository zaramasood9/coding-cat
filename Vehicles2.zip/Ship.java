public class Ship extends Vehicle {


    Ship(String color, int mileage, String model, int price, int number_of_wheel, int seatbelt) {
        super(color, mileage, model, price, number_of_wheel, seatbelt);
    }

    @Override
    public void drive() {
        System.out.println("Ship is moving");
    }
    @Override
    public void stop() {
        System.out.println("Ship has stopped");
    }


}