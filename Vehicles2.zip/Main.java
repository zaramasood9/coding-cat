public class Main {
    public static void main(String[] args) {
        Sedan newcar = new Ford("pink",60000,"5SWE@",1232142,4,4);
        Sedan newcar1=new Sedan("black",3000,"QWA23",400000,4,2);
        newcar.drive();
        newcar.stop();
        newcar.self_destruct();
        System.out.println(newcar.toString());
}}

