import java.awt.*;
import java.io.IOException;
import javax.swing.JFrame;


public class DrawingManager {

        public static void main(String[] args) throws IOException {
            DrawingCanvas canvas=new DrawingCanvas();
            JFrame frame=new JFrame();
            frame.add(canvas);
            frame.setSize(800,600);
            //f.setLayout(null);
            frame.setVisible(true);

        }

    }

