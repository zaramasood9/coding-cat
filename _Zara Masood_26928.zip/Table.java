import java.awt.*;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;

public class Table {
    private int rows;
    private int columns;
    private int x;
    private int y;

    private Cell[] cells;
    private TitleBar titleBar;
    Color cellBorder;
    Color cellcol;
    Color text;

    public Table()
    {

    }
    public Table(int x, int y, int rows, int columns)
    {
        titleBar = new TitleBar(x, y, 500);
        this.x = x;
        this.y = y+30;
        this.rows = rows;
        this.columns = columns;

        cells = new Cell[rows * columns];

        for(int i = 0; i < rows; i++)
        {
            for(int j = 0; j < columns; j++)
            {
                if(i == 0)
                    cells[i*columns + j] = new Cell(this.x + 100 * j , this.y + i * 20, 100, 20, new Color(200,200,250), Color.BLUE, 3, "Data", Color.BLACK);
                else
                    cells[i*columns + j] = new Cell(this.x + 100 * j , this.y + i * 20, 100, 20, new Color(200,200,200), Color.BLUE, 3, "default", Color.BLACK);
            }
        }
    }

    public Table(int x, int y, int rows, int maxcols, Color Titleborder, Color Titlefill, Color cellBorder, Color cellcol, Color headercol, Color text,String title,String[] headers, ArrayList<String> arrayList){
        titleBar = new TitleBar(x, y, maxcols*100,Titleborder, Titlefill, title, text);
        this.x = x;
        this.y = y+30;
        this.rows = rows;
        this.columns = maxcols;
        this.cellBorder = cellBorder;
        this.cellcol = cellcol;
        this.text = text;

        cells = new Cell[rows * columns];
        String[][] data = new String[rows][maxcols];
        Iterator<String> itr = arrayList.iterator();
        while(itr.hasNext()){
            for (int i = 1; i < data.length; i++) {
                String s = itr.next();
                String[] jx = s.split(",");
                for (int j = 0; j < data[i].length; j++) {

                    if (j < jx.length) {
                        data[i][j]=jx[j];
                    }
                    else {
                        data[i][j] = " ";
                    }
                }
            }
        }
        for(int i = 0; i < this.rows; i++){
            for(int j = 0; j < columns; j++){
                if(i == 0) {
                    cells[i*columns + j] = new Cell(this.x + 100 * j , this.y + i * 20, (800-200)/columns, (600-200)/(rows+2), headercol, cellBorder, 3, headers[j], text);
                }
                else {
                    cells[i*columns + j] = new Cell(this.x + 100 * j , this.y + i * 20, (800-200)/columns, (600-200)/(rows+2), cellcol, cellBorder, 3, data[i][j], text);
                }
            }
        }
    }

    public void paint(Graphics g)
    {
        titleBar.paint(g);
        for(int i = 0; i < rows * columns; i++) {
            cells[i].paint(g);
        }
    }

    }

