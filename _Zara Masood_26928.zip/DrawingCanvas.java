import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class DrawingCanvas extends Canvas {
    ArrayList<String> arrayList = new ArrayList();
    String headline;
    String textTitle;
    int rows=0;
    int maxcols=0;
    Table table;
    Color prevcol = Color.WHITE;
    Color cellBorder;
    Color cellcol;
    Color Titleborder;
    Color Titlecol;
    Color headercol;
    Color text;

    Scanner input= new Scanner(System.in);
    public DrawingCanvas() throws IOException{
        filing();
        if(arrayList.isEmpty()){
            table = new Table(100,100, 15, 5);
        }
        else {
            String[] headers = headline.split(" ");
            for (int i = 0; i < headers.length; i++) {
                String header = headers[i];
            }

            table = new Table(100, 100, rows, maxcols,Titleborder, Titlecol, cellBorder, cellcol, headercol, text, textTitle, headers, arrayList);
        }
    }

    public void filing() throws IOException {
        File file= new File("C:\\Users\\zaram\\OneDrive\\Documents\\data.txt");
        try{
            Scanner sc= new Scanner(file);
            System.out.print("Enter headline and make sure to leave a space at the end : ");
            headline = input.nextLine();
            System.out.print("enter title : ");
            textTitle = input.nextLine();
            while (sc.hasNext()) {
                rows++;
                String s = (sc.nextLine());
                arrayList.add(s);
                int c = s.split(",").length;
                maxcols = Math.max(maxcols, c);
            }
            rows++;
        }
        catch (FileNotFoundException e){
            System.out.println("error");
            e.printStackTrace();
        }

    }


    @Override
    public void paint(Graphics g) {
        text = JColorChooser.showDialog(this, "pick text color ", prevcol);
        Titleborder = JColorChooser.showDialog(this, "pick title bar border ", prevcol);
        Titlecol = JColorChooser.showDialog(this, "pick title bar color ", prevcol);
        headercol = JColorChooser.showDialog(this, "pick header cell's color ", prevcol);
        cellBorder = JColorChooser.showDialog(this, "pick cell border ", prevcol);
        cellcol = JColorChooser.showDialog(this, "pick cell color ", prevcol);
        //cell.paint(g);
        table.paint(g);
    }
    }


