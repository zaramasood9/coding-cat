import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<Book> book= new ArrayList<>();
        for(int i=0;i<2;i++){
            book.add(new Book());
        }
        System.out.println("input values for some other book 1");
        Books userbook=new Books();
        userbook.ShowAllBooks(book);

        //System.out.println("input values for some other book 2");
        //Books userbook2=new Books();
        userbook.AddBook(book,userbook);

        //System.out.println("input values for some other book 3");
       // Books userbook3=new Books();
        System.out.println(userbook.searchbyAuthor(book,userbook));
        System.out.println(userbook.searchbySerialNo(book,userbook));

        //System.out.println("input values for some other book 4");
        //Books userbook4=new Books();
        userbook.removeBook(book, userbook);
        userbook.ShowAllBooks(book);





    }
}
