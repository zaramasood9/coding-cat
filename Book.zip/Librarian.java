import java.util.ArrayList;

public class Librarian {
    public static void main(String[] args) {
        //library's inventory
        System.out.println("add students");
        ArrayList<User> libuser = new ArrayList<>();
        libuser.add(new User());
        libuser.add(new User());
        System.out.println("no of library users registered are: "+ libuser.size());

        System.out.println("input values for another user");
        User user1= new User();
        user1.addUser(libuser,user1);
        System.out.println("no of library users registered are: "+ libuser.size());
        System.out.println(user1.toString());

        System.out.println("_______________");
        System.out.println("add books");
        ArrayList<Book> book = new ArrayList<>();
        book.add(new Book());
        book.add(new Book());
        System.out.println("no of books registered are: "+ book.size());

        System.out.println("input values for another book");
        Book book1= new Book();
        System.out.println(book1.isAvailable(book, book1));
        System.out.println(book1.searchbyName(book,book1));
        book1.checkOut(book,book1);
        System.out.println("no of books registered are: "+ book.size());




    }

}
