import java.util.ArrayList;
import java.util.Scanner;

public class User {
    private String name;
    private String ID;
    Scanner input=new Scanner(System.in);

    public User(){
        System.out.println("enter name ");
        this.name=input.next();
        System.out.println("enter student id ");
        this.ID=input.next();
    }

    public void addUser(ArrayList<User> libuser, User user){
        for(int i=0; i<libuser.size();i++){
            if (libuser.get(i).ID.equals(user.ID)) {
                System.out.println("user already exists");
            }
            else
            {
                libuser.add(user);
                System.out.printf("user added");
            }
        }
    }
    public void removeUser(ArrayList<User> libuser, User user){
        for(int i=0; i<libuser.size();i++){
            if (libuser.get(i).ID.equals(user.ID)) {
                libuser.remove(user);
            }
            else{
                System.out.println("user does not exist exists");
            }
        }}
    public String toString(){
        return "Student name: "+ name+ " ID: "+ ID;
    }
}
