import java.util.ArrayList;
import java.util.Scanner;

public class Book {
    private String title;
    private String author;
    private String subject;
    private int bookQty;
    Scanner input= new Scanner(System.in);
    public Book(){
        System.out.println("enter title ");
        this.title=input.next();
        System.out.println("input author name ");
        this.author=input.next();
        System.out.println("input subject ");
        this.subject=input.next();
        System.out.println("input qty of book");
        this.bookQty=input.nextInt();

    }

    public String getAuthor() {
        return author;
    }

    public String getSubject() {
        return subject;
    }

    public String getTitle() {
        return title;
    }
    public boolean isAvailable(ArrayList<Book> book, Book userbook){
        boolean flag=false;
        for(int i=0; i< book.size(); i++){
            if(book.get(i).title.equals(userbook.title)){
                if(book.get(i).bookQty>=1){
                    flag=true;
                }
            }
        }
        return flag;
    }


    public String searchbyAuthor(ArrayList<Book> book, Book userbook){
        String s=" ";
        for(int i=0; i< book.size(); i++){
            if(book.get(i).author.equals(userbook.author)){
                s= "book by the same author available";

            }
            else {
                s="not found";}

        }
        return s;
    }

    public String searchbyName(ArrayList<Book> book, Book userbook){
        String s=" ";
        for(int i=0; i< book.size(); i++){
            if(book.get(i).title.equals(userbook.title)){
                s= "book by the same name available";
            }
            else {
                s="not found";}

        }
        return s;
    }
    public String searchbySubject(ArrayList<Book> book, Book userbook){
        String s=" ";
        for(int i=0; i< book.size(); i++){
            if(book.get(i).subject.equals(userbook.subject)){
                s= "book by the same subject available";

            }
            else {
                s="not found";}

        } return s;
    }
    public void checkOut(ArrayList<Book> book, Book userbook) {
        for (int i = 0; i < book.size(); i++) {
            if (book.get(i).title.equals(userbook.title)) {
                if (book.get(i).bookQty == 0) {
                    book.remove(userbook);
                    System.out.println("you have checked out " + book.get(i).getTitle());
                }
                else {
                    book.get(i).bookQty--;
                    System.out.println("you have checked out " + book.get(i).getTitle());
                }}
            else System.out.println("not found");
        }
    }

    public void returnBook(ArrayList<Book> book, Book userbook){
        for (int i = 0; i < book.size(); i++) {
            if(book.get(i).title.equals(userbook.title)){
                book.get(i).bookQty++;
                System.out.println("you have returned "+ book.get(i).getTitle());
            }
            else System.out.println("not found");

        }}

    public String toString(){
        return "book name: "+ getTitle()+ " author: "+ getAuthor()+" subject: "+ getSubject();
    }
}
