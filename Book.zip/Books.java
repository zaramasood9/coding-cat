import java.util.ArrayList;

public class Books extends Book{
     public void ShowAllBooks(ArrayList<Book> book){
          for(int i=0;i<book.size();i++){
               System.out.println(book.get(i).toString());
         }
      }
     public String searchbyAuthor(ArrayList<Book> book, Books userbook){
          String s=" ";
          for(int i=0;i< book.size();i++){
               if(book.get(i).authorName.equals(userbook.authorName)){
                     s = "here is your match " +userbook.toString();
               }
               else s="author name not matched";
          }
          return s;
     }
     public String searchbySerialNo(ArrayList<Book> book, Books userbook){
          String s=" ";
          for(int i=0;i< book.size();i++){
               if(book.get(i).sNo==(userbook.sNo)){
                    s = "here is your match "+ userbook.toString();
               }
               else s= "serial not matched";
          }
          return s;
     }
     public void AddBook(ArrayList<Book> book, Books userbook){
          boolean flag=false;
          for(int i=0;i<book.size();i++){
               if(book.get(i).bookName==userbook.bookName){
                    System.out.println("book already exist");
                    book.get(i).bookQty++;
               }
               else if(book.get(i).bookName==" "){
                    book.add(userbook);
                    System.out.println("the added book is " + book.get(i).toString());
                    System.out.println("book added");
                    flag=true;
               }
          }
          if(!flag){
               System.out.println("book not added");
          }

     }
     public void removeBook(ArrayList<Book> book, Books userbook){
          boolean flag=false;
          for(int i=0; i<book.size();i++){
               if(book.get(i).sNo==userbook.sNo){
                    if(book.get(i).bookQty==1){
                         book.remove(userbook);
                    }
                    book.get(i).bookQty--;
                    System.out.println("book removed");
               }


          }

     }



}
