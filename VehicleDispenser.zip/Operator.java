public interface Operator {
    public abstract void operate();
}
