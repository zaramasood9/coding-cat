public class Driver implements Operator{
    @Override
    public void operate() {
        System.out.println("operator driving");

    }
}
