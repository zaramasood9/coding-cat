import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Vehicle vehicle1= new Car(20);
        System.out.println(vehicle1.stop(100));
        vehicle1.start();

        TransportCompany company= new TransportCompany();
        OperatorCompany oper= new OperatorCompany();
        System.out.println("--------");

        Vehicle vehicle = company.getVehicle(2);
        Operator oper1=oper.getVehicle(vehicle);
        vehicle.start();
        System.out.println(vehicle.stop(20));
        oper1.operate();
        System.out.println("--------");

        Vehicle vehicle2 = company.getVehicle(1);
        Operator oper2=oper.getVehicle(vehicle2);
        vehicle2.start();
        System.out.println(vehicle2.stop(10));
        oper2.operate();
        System.out.println("--------");

        Vehicle vehicle3 = company.getVehicle(6);
        Operator oper3=oper.getVehicle(vehicle3);
        vehicle3.start();
        System.out.println(vehicle3.stop(290));
        oper3.operate();
        System.out.println("--------");





    }
}
