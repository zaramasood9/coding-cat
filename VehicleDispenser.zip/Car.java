public class Car implements Vehicle, Operator{
    private int speed;
    public Car(int speed){
        this.speed=speed;
    }
    @Override
    public void start() {
        System.out.println("car's vrooming");
    }

    @Override
    public boolean stop(int distance) {
        boolean will=true;
        if(distance>speed){
            will=false;
            return will;
        }
        return will;
    }

    @Override
    public void operate() {

    }
}

