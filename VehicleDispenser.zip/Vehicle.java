public interface Vehicle {
    public abstract void start();
    public abstract boolean stop(int distance);

}
