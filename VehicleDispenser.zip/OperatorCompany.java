public class OperatorCompany {
    public Operator getVehicle(Vehicle e){
        if(e==null){
            return null;
        }
        if(e instanceof Car){
            return new Driver();
        }
        else if(e instanceof Bike){
            return new Rider();
        }
        else if(e instanceof Helicopter){
            Flyer fly= new Pilot();
            fly.flies();
            return new Pilot();
        }
        return null;
    }
}
