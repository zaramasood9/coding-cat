public class Helicopter implements Vehicle{
    private int rotations;
    public Helicopter(int rotations){
        this.rotations=rotations;
    }
    @Override
    public boolean stop(int distance) {
        boolean will=true;
        if(distance>rotations){
            will=false;
            return will;
        }
        return will;
    }

    @Override
    public void start() {
        System.out.println("helicopter's whirring");
    }
}
