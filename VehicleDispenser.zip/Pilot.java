public class Pilot implements Operator, Flyer{
    @Override
    public void operate() {
        System.out.println("pilot operates");
    }

    @Override
    public void flies() {
        System.out.println("flying the vehicle");

    }
}
