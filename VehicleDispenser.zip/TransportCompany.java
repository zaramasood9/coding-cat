public class TransportCompany {
    public Vehicle getVehicle(int noOfpassengers){
        if(noOfpassengers==0){
            return null;
        }
        if(noOfpassengers==1){
            return new Bike(4);
        }
        else if((noOfpassengers==2)||(noOfpassengers==4)){
            return new Car(30);
        }
        else if(noOfpassengers>4){
            return new Helicopter(50);
        }
        return null;
    }
}
