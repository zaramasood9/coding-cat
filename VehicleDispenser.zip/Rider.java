public class Rider implements Operator{
    @Override
    public void operate() {
        System.out.println("rider operating");
    }
}
