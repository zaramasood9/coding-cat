public class Bike implements Vehicle{
    private int gear;
    public Bike(int gear){
        this.gear=gear;
    }

    @Override
    public void start() {
        System.out.println("bike's gliding");
    }

    @Override
    public boolean stop(int distance) {
        boolean will=true;
        if(distance>gear){
            will=false;
            return will;
        }
        return will;
    }

}

