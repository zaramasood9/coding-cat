public interface Flyer {
    public abstract void flies();
}
