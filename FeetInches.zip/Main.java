public class Main {
    public static void main(String[] args) {
        FeetInches feetinches1= new FeetInches(3,14);
        FeetInches feetinches2= new FeetInches(new FeetInches(2,10));
        System.out.println(feetinches2.add(new FeetInches(1,14)));
        System.out.println(feetinches2.equals(new FeetInches(3,10)));
        feetinches1.simplify();
    }
}
