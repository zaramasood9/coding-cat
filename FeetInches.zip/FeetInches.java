public class FeetInches {
    private int feet;
    private int inches;
    private FeetInches feetinches;

    public FeetInches(){
        this.feet=0;
        this.inches=0;
        simplify();
    }
    public FeetInches(int feet, int inches){
        this.feet=feet;
        this.inches=inches;

    }
    public FeetInches(FeetInches feetinches){
        this.feetinches=feetinches;
    }
    public void simplify(){
        if(inches>11){
            int n=14-11;
            feet=feet+(n-2);
            inches=(n-1);
            System.out.println("feet: "+ feet+ " inches: "+ inches);
        }
    }
    public void setFeet(int feet) {
        this.feet = feet;
    }

    public void setInches(int inches) {
        this.inches = inches;
        simplify();
    }

    public int getFeet() {
        return feet;
    }

    public int getInches() {
        return inches;
    }

    @Override
    public String toString() {
        return "FeetInches{" +
                "feet=" + feet +
                ", inches=" + inches +
                '}';
    }
    public int add(FeetInches feetinches1){
        return feetinches.feet +feetinches.inches+ feetinches1.feet+feetinches1.inches;

    }
    public boolean equals(FeetInches feetinches1){
        boolean choice=false;
        if((feetinches.feet==feetinches1.feet) && (feetinches.inches==feetinches1.inches)){
            choice=true;
            return choice;
        }
         return choice;
    }
}
