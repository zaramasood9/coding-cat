public class SingleShapeFactory {
    private static SingleShapeFactory instance = new SingleShapeFactory();
    private SingleShapeFactory(){}
    public static Shape getInstance(String shapeType){
        if(shapeType == null){
            return null;
        }
        if(shapeType.equalsIgnoreCase("CIRCLE")){
            return new Circle();

        } else if(shapeType.equalsIgnoreCase("TRIANGLE")){
            return new Triangle();

        } else if(shapeType.equalsIgnoreCase("SQUARE")){
            return new Square();
        }

        return null;
    }
    public void showMessage(){
        System.out.println("Hello World!");
    }

}

