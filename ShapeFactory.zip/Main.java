public class Main {
    public static void main(String[] args) {
        SingleShapeFactory object;

      Shape shape1 = SingleShapeFactory.getInstance("triangle");

      shape1.draw();

      /*Shape shape2 = SingleShapeFactory.getInstance("RECTANGLE");

      shape2.draw();

      Shape shape3 = SingleShapeFactory.getInstance("SQUARE");

      shape3.draw();*/
   }
}


