public class SinglyLinkedList<T> {
    Node head;
// temp variable here stands for current
    public SinglyLinkedList(){
        this.head=null;
    }
    public void insert(T n){
        Node N= new Node(n);
        Node temp = null;
        if(head==null){
            head=N;
        }
        else{
            temp= head;
            while(temp.next!= null){
                temp=temp.next;
            }
            temp.next=N;
        }
    }
    public String toString() {
        if(head==null){
            return "List is empty";
        }
        Node temp = head;
        String s="{";
        while (temp!= null) {
            s = s+ temp.data + ",";
            temp = temp.next;
        }
        s= s+ "}";
        return s;
    }
    public void delete(T d){
        Node temp=head;
        Node prev=null;
        if(temp!=null){
        if(temp.data==d){ //head contains the search value and list is not empty
            head=temp.next;
            return;
        }}
        while(temp!=null && temp.data!=d){
            prev=temp;
            temp=temp.next;
        }
        if(temp==null){ //end of the list reached
            System.out.println("Item not found");
        }
        prev.next=temp.next;
    }

    public Node find(T d) {

            if(head==null){ //head contains the search value and list is not empty
                return null;
            }
            Node temp=head;
        while(temp!=null){
            if(temp.data==d){
                return temp;
            }
            temp=temp.next;
        }
        return null;
    }
    public void clear(){
        if(head==null){
            System.out.println("List was already empty");
        }
        else{
            head=null;
            System.out.println("List has been cleared");
        }
    }
    public void insertBefore(Node n, T d){
        Node temp;
        if(head==null){
            System.out.println("List is empty");
            return;
        }
        if(head==n){
            Node N= new Node(d);//given node is the head node
            N.next= head;
            head=N;
            return;
        }
            temp = head;
            while (temp.next != null && temp.next != n) {
                temp = temp.next;
            }
            if (temp.next == n) {
                Node N = new Node(d);
                N.next = n;
                temp.next = N;
            } else {
                System.out.println("Given node does not exist in the list");
            }
        }
    public boolean findIndex(T d) {

        if(head==null){ //head contains the search value and list is not empty
            return false;
        }
        Node temp=head;
        while(temp!=null){
            if(temp.data==d){
                return true;
            }
            temp=temp.next;
        }
        return false;
    }

    }





