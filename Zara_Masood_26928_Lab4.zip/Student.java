public class Student {
    String name;
    int age;
    double cgpa;

    public Student(String name, int age, double cgpa){
        this.name= name;
        this.age=age;
        this.cgpa=cgpa;
    }

    public String toString(){
        return name + " "+ age+ " "+ cgpa;
    }

}

