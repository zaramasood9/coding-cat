public class Main {
    public static void main(String[] args) {
        SinglyLinkedList<Student> list =new SinglyLinkedList<Student>();
        Student s1= new Student("Bob", 23, 2.4);
        Student s2 = new Student("Sarrah", 25, 3.0);
        Student s3=new Student("Heather", 18, 4.0);
        Student s4=null;
        list.insert(s1);
        list.insert(s2);
        list.insert(s3);
        System.out.println(list);
        list.insertBefore(list.find(s3),new Student("kelly", 45, 3.2));
        System.out.println(list);
        list.delete(s1);
        System.out.println(list);
        System.out.println(list.findIndex(s1));
        list.clear();
        System.out.println(list);


    }
}
