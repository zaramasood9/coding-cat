public class DoublyLinkedList<T extends Comparable<T>> {
    Node head;
    Node tail;


   // public DoublyLinkedList() {
      ///  this.head = null;
       // this.tail=null;
   /// }

    public void addSorted(T value) {
        Node N = new Node(value);
        if (head == null) { //empty list
            head = N;
            tail = N;
            return;
        }
        if (((T) head.data).compareTo(value) == 1) { //head.data> value (add before the head)
            N.next = head;
            N.next.prev = N;
            head = N;
            return;
        }
        Node curr = head;
        while ((curr != null) && ((T) curr.data).compareTo(value) == -1) {  // curr.data < value (correct order)
            curr = curr.next;
        }
        if (curr== null) { // reached end of the list, add at the end
            N.prev = tail;
            N.prev.next = N;
            tail = N;
        } else {   //insert in middle
            N.prev=curr.prev;
            N.next=curr;
            curr.prev.next = N;
            curr.prev = curr;
        }
    }
    public void addAsHead(T i){
        Node N=new Node(i);
        if(head==null){
            head=N;
            tail=N;
        }
        else{
            N.next=head;
            N.next.prev=N;
            head=N;
        }
    }
    public void addAsTail(int i){
        Node N=new Node(i);
        if (head == null) {
            head=N;
            tail=N;
        }
        else {
            N.prev = tail;
            N.prev.next = N;
            tail = N;
        }
    }

    public Node Find(T value) {
        if (head == null) { //head contains the search value and list is not empty
            System.out.println("List is empty");
            return null;
        }
        Node temp = head;
        while (temp != null) {
            if (temp.data == value) {
                return temp;
            }
            temp = temp.next;
        }
        return null;
    }
    public Integer popHead(){
        int data;
        if(head==null){
            return null;
        }
        else{
            data= (int) head.data;
            head.next.prev = null;
            head = head.next;
        }
        return data;
    }
    public void  removeFirst(T value) {
        Node temp = Find(value);
        if (temp != null) {
            if (temp == head) {//&& (temp.next!=null)) { // remove head element, list has remaining elements
                head.next.prev = null;
                head = head.next;
            }
           /* else if ((temp==head) && (temp.next == null)) {  //remove head, list only has a single element which was head
              head = null;
                System.out.println("list is now empty");
                return 1;
            }*/
            else if (temp == tail) {   // deletes the last element
                temp.prev.next = null;
                tail = tail.prev;
                System.out.println("tail deleted");
            } else {    //deletes a middle element
                temp.prev.next = temp.next; //element exists in the middle
                temp.next.prev = temp.prev;

            }
        } else System.out.println("element not present in the list");
    }

    public void removeAll(T i){
        Node index = Find(i); // shows the last index
        if (index == null) {
            System.out.println("Element does not exist");
        } else {
            while (index != null) {
                removeFirst(i);
                index = Find(i);
            }
        }
    }
    public void addAll(DoublyLinkedList l){
        if(l.isEmpty()){
            return;
        }
        else if(head==null){
            head= l.head;
            tail=l.tail;
        }
        else{ //head remains the same
            tail.next=l.head;
            l.head.prev=tail;
            tail=l.tail;
        }

    }

    public String toString() {
        if (head == null) {
            return "List is empty";
        }
        Node temp = head;
        String s = "{";
        while (temp != null) {
            s = s + temp.data + ",";
            temp = temp.next;
        }
        s = s + "}";
        return s;
    }

    public boolean isEmpty() {
        if (head == null) {
            return true;
        }
        return false;
    }

    public int Length() {
        int count = 0;
        Node current = head;
        while (current != null) {
            current = current.next;
            count++;
        }
        return count;
    }

    public void Reverselist() {
       Node current = head;
        Node temp = null;
        while (current != null) {
            temp = current.prev;     //assigns a temporary variable to current.prev
            current.prev = current.next; // }  swaps the prev of current with the next of current
            current.next = temp;         // }
            current = current.prev;
        }
        // After the loop, you can swap head and tail
         temp=head;
        head=tail;
        tail=temp;
        }

}






