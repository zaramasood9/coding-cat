public class Main {
    public static void main(String[] args) {
        DoublyLinkedList<Integer> list = new DoublyLinkedList<Integer>();
        list.addAsHead(4);
        list.addAsHead(7);
        System.out.println(list);
        list.addAsTail(8);
        list.addAsTail(10);
        System.out.println(list);
        System.out.println("-----------REVERSING-----------");
        list.Reverselist();
        System.out.println(list);
        list.addSorted(6);
        list.addSorted(1);
        list.addSorted(5);
        list.addSorted(2);
        System.out.println(list);
        System.out.println("element found: " + list.Find(11));
        System.out.println(list.popHead());
        System.out.println(list);
        list.removeFirst(10);
        System.out.println(list);
        list.removeAll(4);
        System.out.println(list);
        DoublyLinkedList<Integer> list2 = new DoublyLinkedList<>();
        list2.addSorted(4);
        list2.addAsHead(10);
        System.out.println(list.isEmpty());
        System.out.println(list.Length());
         list.addAll(list2);
        System.out.println(list);
    }
}
