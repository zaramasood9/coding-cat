import java.util.ArrayList;

public class Manager extends Employee{
    ArrayList<Faculty> staff;

    public Manager(String name, String id,ArrayList<Faculty> staff ) {
        super(name, id);
        this.staff=staff;
    }
    public Manager(String name, String id){
        super(name, id);
    }

    public void Manages(){
        System.out.println(super.getName()+" manages "+ staff);

    }
    public String toString(){
        return super.toString();

    }
    @Override
    public float getSalary() {
        return 20000;
    }
}

