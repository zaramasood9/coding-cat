import java.util.ArrayList;

public class School {
    ArrayList<Department> departmentList;
    public School(ArrayList<Department> departmentList){
        this.departmentList= departmentList;

    }

    @Override
    public String toString() {
        return "{" +
                "departmentList=" + departmentList +
                '}';
    }
}
