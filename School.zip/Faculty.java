import java.util.ArrayList;

public interface Faculty {
    ArrayList<Course> courses=new ArrayList<>();
    public void teaches(ArrayList<Course> courses);

}
