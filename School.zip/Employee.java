public abstract class Employee {
    private String id;
    private String name;
    private float salary;

    public Employee(String name, String id){
        this.name=name;
        this.id=id;
    }

    public String getName() {
        return name;
    }
    public abstract float getSalary() ;


    public String getId() {
        return id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setSalary(float salary) {
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "{id='" + id + '\'' +
                ", name='" + name + '\'' + "}" ;
    }
}
