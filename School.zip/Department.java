import java.util.ArrayList;

public class Department {
    private ArrayList<Course> courses;
   private ArrayList<Faculty> faculty;
    public Department(ArrayList<Course> courses, ArrayList<Faculty> faculty){
        this.courses= courses;
        this.faculty= new ArrayList<>();
    }

    @Override
    public String toString() {
        return "{" +
                "courses=" + courses +
                ", faculty=" + faculty +
                '}';
    }
}
