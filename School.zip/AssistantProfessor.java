import java.util.ArrayList;

public class AssistantProfessor implements Faculty{
    @Override
    public void teaches(ArrayList<Course> courses) {
        System.out.println( "professor teaches "+ courses);
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
