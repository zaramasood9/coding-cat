import java.util.ArrayList;

public class President extends Manager{
    public President(String name, String id, ArrayList<Faculty> faculty) {
        super(name, id, faculty);
    }

    @Override
    public float getSalary() {
        return super.getSalary();
    }

    @Override
    public void Manages() {
        super.Manages();
    }
}
