import java.util.ArrayList;

public class Course {
    private ArrayList<Faculty> instructors;
       private ArrayList<Student> students;
       public Course(ArrayList<Student> students,ArrayList<Faculty> instructors ){
       this.students= students;
       this.instructors=instructors;
       }

   @Override
   public String toString() {
      return "{" +
              "instructors=" + instructors +
              ", students=" + students +
              '}';
   }
}
