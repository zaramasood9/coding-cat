import java.util.ArrayList;

public class Professor extends AssistantProfessor{
    @Override
    public void teaches(ArrayList<Course> courses) {
        super.teaches(courses);
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
