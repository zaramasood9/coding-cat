import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<Department> dept= new ArrayList<>();
        ArrayList<Course> courses= new ArrayList<>();
        ArrayList<Faculty> faculty= new ArrayList<>();
        ArrayList<Student> students= new ArrayList<>();


        faculty.add(new Dean("Dean Hico", "111"));
        faculty.add(new Director("Director Bellum", "221"));
        faculty.add(new AssistantProfessor());
        faculty.add(new AssociateProfessor());
        faculty.add(new Professor());

        students.add(new Student("Meghan", "3002"));
        students.add(new Student("Rudy", "3003"));

        courses.add(new Course(students, faculty));

        dept.add(new Department(courses, faculty));

        Manager president= new President("Bob", "1000", faculty);
        president.Manages();
        System.out.println(president.getSalary());

        Manager manager= new Manager("Bill", "001", faculty);
        manager.Manages();
        System.out.println(manager.getSalary());

        Dean dean= new Dean("Dean Hico", "111");
        AssistantProfessor atp= new AssistantProfessor();
        AssociateProfessor ap=new AssociateProfessor();
        Professor prof= new Professor();

        dean.teaches(courses);
        atp.teaches(courses);
        ap.teaches(courses);
        prof.teaches(courses);


        School school= new School(dept);
        System.out.println(school.toString());






    }
}
