import java.util.ArrayList;

public class Director extends Manager implements Faculty{
    public Director(String name, String id) {
        super(name, id);
    }

    @Override
    public void teaches(ArrayList<Course> courses) {
        System.out.println("director teaches"+ courses);
    }

    @Override
    public float getSalary() {
        return 22000;
    }

    @Override
    public void Manages() {
        super.Manages();
    }

}
