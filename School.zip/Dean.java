import java.util.ArrayList;

public class Dean extends Manager implements Faculty{
    public Dean(String name, String id) {
        super(name, id);
    }

    @Override
    public float getSalary() {
        return 200000;
    }

    @Override
    public void teaches(ArrayList<Course> courses) {
        System.out.println( super.getName()+" teaches "+ courses);
    }

    @Override
    public String toString() {
        return super.toString();
    }

    @Override
    public void Manages() {
        super.Manages();
    }
}
