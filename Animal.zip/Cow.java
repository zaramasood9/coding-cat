public class Cow extends Herbivores{
    public Cow(){
        super();
    }

    @Override
    public String Eat(Herbivores animal1) {
        return super.Eat(animal1);
    }
    public String toString(){
        return getCow();
    }

    @Override
    public String Sleep() {
        return "Cow " + super.Sleep();
    }

    @Override
    public String Dies() {
        return "Cow " + super.Dies();
    }

}
