public class Main {
    public static void main(String[] args) {


        Lion lion = new Lion();
        Cow cow = new Cow();
        Wolf wolf=new Wolf();
        Goat goat =new Goat();
        Carnivore animal1= new Carnivore(lion, wolf);
        Herbivores animal2= new Herbivores(goat, cow);


        System.out.println(lion.Eat(lion,cow).toString());
        System.out.println(wolf.Eat(wolf,goat).toString());
        System.out.println(lion.Sleep());
        System.out.println(cow.Sleep());
        System.out.println(cow.Dies());
        System.out.println(cow.Eat(cow));

    }


}
