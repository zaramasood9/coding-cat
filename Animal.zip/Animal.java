public abstract class Animal {
    private String name;

    private String age;

    public String plants = "grass";
    public Animal(){

    }
    public abstract String Eat(Carnivore animal1, Herbivores animal2);
    public abstract String Eat(Herbivores animal1);

    public String Sleep() {
        return "is sleeping";

    }
    public String Dies() {
        return   "Dies";
    }

}

