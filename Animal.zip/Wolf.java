public class Wolf extends Carnivore{
    public Wolf(){
        super();
    }
    public String toString(){
        return getWolf()+ " eats ";
    }

    @Override
    public String Eat(Carnivore animal1, Herbivores animal2) {
        return super.Eat(animal1, animal2);
    }

    @Override
    public String Sleep() {
        return "Wolf " + super.Sleep();
    }


    @Override
    public String Dies() {
        return "Wolf " +super.Dies();
    }
}
