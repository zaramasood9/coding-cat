public class Goat extends Herbivores{
    public Goat(){
        super();
    }

    @Override
    public String Eat(Herbivores animal1) {
        return super.Eat(animal1);
    }
    public String toString(){
        return getGoat();
    }

    @Override
    public String Sleep() {
        return "Goat " +super.Sleep();
    }

    @Override
    public String Dies() {
        return "Goat " +super.Dies();
    }
}
