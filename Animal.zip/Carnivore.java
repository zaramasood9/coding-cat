public class Carnivore extends Animal{
    private Lion lion;
    private Wolf wolf;
    public Carnivore(){

    }
    public Carnivore(Lion lion, Wolf wolf){
        super();
        this.lion=lion;
        this.wolf=wolf;
    }
    public String getLion(){
        return "lion";
    }
    public String getWolf(){
        return "wolf";
    }

    @Override
    public String Eat(Carnivore animal1, Herbivores animal2) {
        return ""+ animal1  + animal2;
    }

    @Override
    public String Eat(Herbivores animal1) {
        return null ;
    }

    @Override
    public String Sleep() {
        return super.Sleep();
    }

    @Override
    public String Dies() {
        return super.Dies();
    }
    }

