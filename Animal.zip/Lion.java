public class Lion extends Carnivore{
    public Lion(){
        super();
    }

    @Override
    public String Eat(Carnivore animal1, Herbivores animal2) {
        return super.Eat(animal1, animal2);
    }
    public String toString(){
        return getLion()+ " eats ";
    }

    @Override
    public String Sleep() {
        return "Lion " +super.Sleep();
    }

    @Override
    public String Dies() {
        return "Lion " + super.Dies();
    }

}
