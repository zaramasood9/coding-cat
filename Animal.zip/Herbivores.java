public class Herbivores extends Animal {
    private Goat goat;
    private Cow cow;
    public Herbivores(){

    }
    public Herbivores(Goat goat, Cow cow){
        super();
        this.goat=goat;
        this.cow=cow;
    }
    public String getGoat(){
        return "goat";
    }
    public String getCow(){
        return "cow";
    }

    @Override
    public String Eat(Carnivore animal1, Herbivores animal2) {
        return null;
    }

    @Override
    public String Eat(Herbivores animal1) {
        return "" + animal1+ " eats grass";
    }

    @Override
    public String Sleep() {
        return super.Sleep();
    }

    @Override
    public String Dies() {
        return super.Dies();
    }
}
