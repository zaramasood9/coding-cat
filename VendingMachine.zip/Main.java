import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
    Scanner input =new Scanner(System.in);
        System.out.println("display menu ");
        String[][] menu= new String[6][2];
        for(int i=0; i<menu.length;i++){
            for(int j=0; j<menu[0].length;j++){
                if(j%2==0){
                    menu[i][j]=input.next();
                }
                else{
                    menu[i][j]=input.next();
                }
            }
        }
        for(int i=0; i<menu.length;i++){
            for(int j=0; j<menu[0].length;j++){
                System.out.print(menu[i][j]+ " ");
            }
            }
        System.out.println();

        int reply=0;
        System.out.println("Do you wish to buy anything?, enter 1 to continue ");
        reply=input.nextInt();
        while(reply==1){
        System.out.println("enter product ");
        String product= input.next();
        System.out.println("enter amount ");
        int amount= input.nextInt();
        System.out.println("enter 1 to continue with your purchase? ");
            reply= input.nextInt();
            if(reply==1){
               VendingMachine prod= new VendingMachine();
               prod.setProduct(product);
               prod.setAmount(amount);
                prod.selectProd(menu);
                int change=prod.Change(menu);
                System.out.println(change);

            }
        }

    }


}
