public class VendingMachine {
    String product;
    int amount;
    public VendingMachine(){
        this.product="";
        this.amount=0;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public int getAmount() {
        return amount;
    }

    public String getProduct() {
        return product;
    }

    public void selectProd(String[][] menu){
        for(int i=0; i<menu.length;i++){
            for(int j=0; j<menu[0].length;j++){
                if(j%2==0){
                   if(menu[i][j].equals(product)){
                       System.out.println(getProduct());
               }
              }
            }
        }
    }
    public int Change(String[][] menu){
        int change=0;
        for(int i=0; i<menu.length;i++){
            for(int j=0; j<menu[0].length;j++){
                if(j%2==0){
                    if(menu[i][j].equals(product)){
                       change= amount-(Integer.valueOf(menu[i][j+1]));
                       return change;
                    }
                }
            }
        }
        return change;
    }
}
