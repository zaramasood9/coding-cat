/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication78;

/**
 *
 * @author zehraahmed
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GUInterface {
    JLabel questionLabel;
    JTextField answerField;
    String userAnswer;
    Diagnosis D;

    public GUInterface( Diagnosis D ) {
        this. D = D;
    }

    void initBoard() {

        JFrame frame = new JFrame(" Diagnose Me ");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel = new JPanel(new GridLayout(3, 1));
        frame.getContentPane().add(panel);
        frame.setSize(400, 170);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        questionLabel = new JLabel(" ");
        questionLabel.setText(" ");
        answerField = new JTextField();
        panel.add(questionLabel);
        panel.add(answerField);

        JButton submitButton = new JButton("Submit");

        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                userAnswer = answerField.getText().trim().toLowerCase();
                setUserAnswer(userAnswer);
                if ( userAnswer.equalsIgnoreCase("yes")) {
                    D.setCurrentNode(D.getCurrentNode().yes);
                    processUserAnswer(userAnswer);

                }
                else  if ( userAnswer.equalsIgnoreCase("no")){
                    D.setCurrentNode(D.getCurrentNode().no);
                    processUserAnswer(userAnswer);

                }
                else{
                    JOptionPane.showMessageDialog(null," Please enter yes or no "," Error "  , JOptionPane.ERROR_MESSAGE);

                }
                processUserAnswer(userAnswer);

                if (D.getCurrentNode().yes == null && D.getCurrentNode().no == null) {
                    frame.dispose();
                    Show_Diagnosis(D.getCurrentNode());
                }


            }
        });
        panel.add(submitButton);


    }

    public JLabel getQuestionLabel() {
        return questionLabel;
    }

    public void setQuestionLabel(JLabel questionLabel) {
        this.questionLabel = questionLabel;
    }

    private void processUserAnswer(String userAnswer) {

        myNode currentNode = D.getCurrentNode();
        //System.out.println("User Answer: " + userAnswer);

        updateQuestionLabel(currentNode);
    }


    private void updateQuestionLabel(myNode currentNode) {
        // Update the question label with the new question
        if (currentNode != null) {
            questionLabel.setText(currentNode.Question);
            answerField.setText("");

        } else {
            questionLabel.setText("No diagnosis available");

        }
        //System.out.println(D.getCurrentNode().Question  + "" + questionLabel.getText());
    }

    public void Show_Diagnosis( myNode currentNode ) {


        JOptionPane.showMessageDialog(null," You have been diagnosed with " + currentNode.Question, " Success ", JOptionPane.INFORMATION_MESSAGE);
   /*     JFrame MyFrame = new JFrame();
        MyFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        MyFrame.setSize(400, 200);
        MyFrame.setVisible(true);
        TextField T = new TextField(" You have been diagnosed with " + currentNode.Question);
        MyFrame.add(T);

    */
    }

    public String getUserAnswer() {
        return userAnswer;
    }

    public void setUserAnswer(String userAnswer) {
        this.userAnswer = userAnswer;
    }
}

