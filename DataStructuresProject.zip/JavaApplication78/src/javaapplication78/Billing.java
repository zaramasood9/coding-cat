/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication78;

/**
 *
 * @author zehraahmed
 */
//package projectttt.ds;
import java.awt.*;
import java.awt.event.*;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import javax.swing.*;



public class Billing extends JFrame implements ActionListener {
    BillingNode head;
    public BillingLinkedList billingList;

    JLabel lmain, lpname, lpno, ldad, lddis, lrt, lrd, ltamt, temp, ldays;
    JTextField tfname, tfno, tfdateadd, tfrtype, tfrd, tftamt, tfdays;
    JButton bsub, bclr, bback, bsave, bdisplay, bdelete;

    Billing() {
        super("Billing Information");
        
        billingList = new BillingLinkedList();
        
        setSize(800, 640);
        //getContentPane().setBackground(Color.WHITE);
        setLocationRelativeTo(null);
        setLayout(null);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        JLabel label = new JLabel(); //JLabel Creation
        label.setIcon(new ImageIcon("/Users/zehraahmed/NetBeansProjects/JavaApplication78/src/javaapplication78/logosmall.jpg")); //Sets the image to be displayed as an icon
        Dimension size = label.getPreferredSize(); //Gets the size of the image
        label.setBounds(0, 0, size.width, size.height); //Sets the location of the image
        add(label);
        

        lmain = new JLabel("Billing Information");
        lmain.setFont(new Font("Arial", Font.BOLD, 40));
        lmain.setForeground(new Color(8,95,225));
        lmain.setBounds(215, 0, 640, 40);
        add(lmain);

        lpname = new JLabel("Patient Name :");
        lpname.setFont(new Font("Arial", Font.PLAIN, 15));
        lpname.setBounds(95, 97, 100, 35);
        add(lpname);

        tfname = new JTextField(30);
        if (billingList.getHead()!= null)
        tfname.setText(billingList.head.data.getPatientName());
        tfname.setBounds(210, 105, 225, 20);
        add(tfname);

        lpno = new JLabel("Patient No. :");
        lpno.setFont(new Font("Arial", Font.PLAIN, 15));
        lpno.setBounds(560, 97, 100, 35);
        add(lpno);

        tfno = new JTextField(50);
        if (billingList.getHead()!= null)
        tfname.setText("" + billingList.head.data.getPatientId());
        tfno.setBounds(663, 105, 100, 20);
        add(tfno);

        ldad = new JLabel("Date of Admission :");
        ldad.setFont(new Font("Arial", Font.PLAIN, 15));
        ldad.setBounds(95, 175, 200, 25);
        add(ldad);

        tfdateadd = new JTextField(20);
        if (billingList.getHead()!= null)
        tfname.setText(billingList.head.data.getDateOfAdmission());
        tfdateadd.setBounds(230, 178, 120, 20);
        add(tfdateadd);

        lddis = new JLabel("Date of Discharge :");
        lddis.setFont(new Font("Arial", Font.PLAIN, 15));
        lddis.setBounds(560, 175, 130, 25);
        add(lddis);

        lrt = new JLabel("Room Type :");
        lrt.setFont(new Font("Arial", Font.PLAIN, 15));
        lrt.setBounds(95, 242, 100, 25);
        add(lrt);

        tfrtype = new JTextField(20);
        tfrtype.setBounds(230, 246, 120, 20);
        add(tfrtype);

        lrd = new JLabel("Cash/Card :");
        lrd.setFont(new Font("Arial", Font.PLAIN, 15));
        lrd.setBounds(95, 300, 130, 25);
        add(lrd);

        tfrd = new JTextField(20);
        tfrd.setBounds(230, 305, 120, 20);
        add(tfrd);

        ltamt = new JLabel("Total Amount :");
        ltamt.setFont(new Font("Arial", Font.PLAIN, 15));
        ltamt.setBounds(95, 380, 100, 25);
        add(ltamt);

        tftamt = new JTextField(20);
        tftamt.setBounds(230, 380, 120, 20);
        add(tftamt);

        bsub = new JButton("CALCULATE");
        bsub.setBounds(85, 443, 110, 30);
        add(bsub);

        bclr = new JButton("CLEAR");
        bclr.setBounds(543, 443, 100, 30);
        add(bclr);

        bback = new JButton("BACK");
        bback.setBounds(650, 443, 100, 30);
        add(bback);
         
       // bdelete = new JButton("DELETE");
        //bdelete.setBounds(350, 443, 100, 30);
        //add(bdelete);
        
        bdisplay = new JButton("DISPLAY");
        bdisplay.setBounds(200, 443, 100, 30);
        add(bdisplay);
        bdisplay.addActionListener(e -> displayBillingInformation());


        bclr.addActionListener(new clear());
        bsub.addActionListener(new submit());
        bback.addActionListener(new back());
//        bdelete.addActionListener(new delete());

        try {
            Calendar cal = Calendar.getInstance();
            SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
            df.setLenient(false);
            //System.out.println(df.format(cal.getTime()));
            String dd1 = df.format(cal.getTime());

            temp = new JLabel(dd1);
            temp.setBounds(694, 178, 80, 20);
            add(temp);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(new JFrame(), "Please Enter All The Fields", "ERROR!",
                    JOptionPane.ERROR_MESSAGE);
        }

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
    }
    
    public void insertNode(BillingInformation data) {
        billingList.insertNode(data);
    }

    public void clearBillingList() {
        billingList.clear();
    }
    
   public void deleteBillingInformation() {
    // Collect user input from GUI fields
    int patientId;
    try {
        patientId = Integer.parseInt(tfno.getText());
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(Billing.this, "Invalid input for Patient ID", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    String patientName = tfname.getText();

    boolean deleteSuccessful = billingList.deleteNode(patientId, patientName);

    if (deleteSuccessful) {
        JOptionPane.showMessageDialog(Billing.this, "Information deleted successfully", "Success",
                JOptionPane.INFORMATION_MESSAGE);
    } else {
        JOptionPane.showMessageDialog(Billing.this, "Information not found or could not be deleted", "Error",
                JOptionPane.ERROR_MESSAGE);
    }
}



    
     //displays billing information in message dialogue using linked list
    public void displayBillingInformation() {
    // Collect user input from GUI fields
    String patientName = tfname.getText();
    String dateOfAdmission = tfdateadd.getText();
    String CashorCard = tfrd.getText();
    
    try {
        int patientId = Integer.parseInt(tfno.getText());
        String roomType = tfrtype.getText();
        double totalAmount = calculateBill(roomType);
        String CardorCash = tfrd.getText();

        // Create BillingInformation object
        BillingInformation billingInfo = new BillingInformation(patientId, patientName, dateOfAdmission, roomType, totalAmount, CardorCash);

        //insertNode(billingInfo);

        // Display all billing information in a message dialog
        String billingMessage = " ";

        // Traverse the linked list and append each billing information to the message
        BillingNode temp = billingList.getHead();;
        while (temp != null) {
            BillingInformation info = temp.data;
            billingMessage += "Patient Name: " + info.getPatientName() + "\n";
            billingMessage += "Patient ID: " + info.getPatientId() + "\n";
            billingMessage += "Date of Admission: " + info.getDateOfAdmission() + "\n";
            billingMessage += "Room Type: " + info.getRoomType() + "\n";
            billingMessage += "Cash/Card: " + info.getCardorCash() + "\n";
            billingMessage += "Total Amount: $" + info.getTotalAmount() + "\n\n";


            temp = temp.next;
        }
         if (tfname.getText().isEmpty() || tfno.getText().isEmpty() || tfdateadd.getText().isEmpty()
                || tfrtype.getText().isEmpty() || tfrd.getText().isEmpty()) {
            JOptionPane.showMessageDialog(Billing.this, "Please fill in all the required fields.", "Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
            
        }
         else{
         //Display the billing information in a message dialog
        JOptionPane.showMessageDialog(this, billingMessage, "Billing Information", JOptionPane.INFORMATION_MESSAGE);
         }
    } catch (NumberFormatException e) {
        
        // Handle the case where the user entered invalid numeric input
        JOptionPane.showMessageDialog(this, "Invalid input for Patient ID", "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    
}
    // Create a Delete class to handle deletions
    /*public class Delete {
    public static boolean deleteBillingInformation(BillingLinkedList billingList, int patientId, String patientName) {
        return billingList.deleteNode(patientId, patientName);
    }
}


   class delete implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent ae) {
        // Collect user input from GUI fields
        int patientId;
        try {
            patientId = Integer.parseInt(tfno.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(Billing.this, "Invalid input for Patient ID", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String patientName = tfname.getText();

        boolean deleteSuccessful = Delete.deleteBillingInformation(billingList, patientId, patientName);

        if (deleteSuccessful) {
            JOptionPane.showMessageDialog(Billing.this, "Information deleted successfully", "Success",
                    JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(Billing.this, "Information not found or could not be deleted", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}*/


    
    class clear implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent ae) {
        tfname.setText("");
        tfno.setText("");
        tfdateadd.setText("");
        tfrtype.setText("");
        tftamt.setText("");
        
            clearBillingList();
            
            JOptionPane.showMessageDialog(Billing.this, "Billing information cleared.", "Success",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }

    class back implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent ae) {
            setVisible(false);
            Reporttds report = new Reporttds();
            report.setVisible(true);
            report.setLocationRelativeTo(null);
        }
    }

    class submit extends Frame implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent ae) {
        //To Check if any of the required fields is empty
        if (tfname.getText().isEmpty() || tfno.getText().isEmpty() || tfdateadd.getText().isEmpty()
                || tfrtype.getText().isEmpty() || tfrd.getText().isEmpty()) {
            JOptionPane.showMessageDialog(Billing.this, "Please fill in all the required fields.", "Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            double bill = calculateBill(tfrtype.getText());
            String finalBill = String.valueOf(bill);
            tftamt.setText(finalBill);

            if (!isValidRoomType(tfrtype.getText())) {
                JOptionPane.showMessageDialog(Billing.this, "Invalid room type entered. Please enter a valid room type.",
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int patientNo = Integer.parseInt(tfno.getText());
            BillingInformation billingInfo = new BillingInformation(patientNo, tfname.getText(), tfdateadd.getText(),
            tfrtype.getText(), bill, tfrd.getText());
            insertNode(billingInfo);

        } catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(Billing.this, "Please enter a valid patient number.", "Error",
                    JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(Billing.this, "An error occurred: " + e.getMessage(), "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    }

    class save implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent ae) {
            try {
                // Saving the linked list to a file
                ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("billing_info.ser"));
                // oos.writeObject(insertNode);
                oos.close();

                JOptionPane.showMessageDialog(Billing.this, "Billing information saved successfully!", "Success",
                        JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(Billing.this, "Failed to save billing information", "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }


    private boolean isValidRoomType(String roomType) {
        return roomType.equals("Deluxe") || roomType.equals("Private") || roomType.equals("Semi-Private") || roomType.equals("General");
    }

    
    private double calculateBill(String roomType) {
        int days = 5;
        double rate = 0;

        switch (roomType) {
            case "Deluxe":
                rate = 2000;
                break;
            case "Private":
                rate = 800;
                break;
            case "Semi-Private":
                rate = 600;
                break;
            case "General":
                rate = 400;
                break;
        }

        return days * rate;
    }

    
}

    

