/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication78;

/**
 *
 * @author zehraahmed
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Main {
    static Hospital hospital;
    static JFrame frame;  // Declare frame as a class-level variable


            public static void main(String[] args) {
                JFrame frame = new JFrame("Hospital Management System");
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setLocationRelativeTo(null);
                frame.setSize(800, 700);

                JPanel panel = new JPanel();
                panel.setLayout(null);
                frame.add(panel);
                hospital = new Hospital("patient_records.txt", "doctor_records.txt"); // Create the hospital instance
                createAndShowUserTypeSelection();
    }

    private static void createAndShowUserTypeSelection() {
        frame = new JFrame("Hospital Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        JPanel panel = new JPanel();
        frame.getContentPane().add(panel);
        placeUserTypeSelectionComponents(panel);

        frame.setSize(600, 530);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                try {
                    hospital.clearFiles(); // Add a method in the Hospital class to clear files
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });
    }

    private static void placeUserTypeSelectionComponents(JPanel panel) {
        panel.setLayout(null);
        panel.setBackground(Color.white);
        
        JLabel label = new JLabel(); //JLabel Creation
        label.setIcon(new ImageIcon("/Users/zehraahmed/NetBeansProjects/JavaApplication78/src/javaapplication78/Screenshot 2023-12-01 at 10.44.05 PM-6.jpg")); //Sets the image to be displayed as an icon
        Dimension size = label.getPreferredSize(); //Gets the size of the image
        label.setBounds(0, 0, size.width, size.height); //Sets the location of the image
        panel.add(label);
       
        JLabel label2 = new JLabel(); //JLabel Creation
        label2.setIcon(new ImageIcon("/Users/zehraahmed/NetBeansProjects/JavaApplication78/src/javaapplication78/doctor.jpg")); //Sets the image to be displayed as an icon
        Dimension size2 = label2.getPreferredSize(); //Gets the size of the image
        label2.setBounds(65, size.height, size2.width, size2.height); //Sets the location of the image
        panel.add(label2);
        
        JLabel label3 = new JLabel(); //JLabel Creation
        label3.setIcon(new ImageIcon("/Users/zehraahmed/NetBeansProjects/JavaApplication78/src/javaapplication78/patient.jpg")); //Sets the image to be displayed as an icon
        Dimension size3 = label3.getPreferredSize(); //Gets the size of the image
        label3.setBounds(size2.width+115, size.height, size3.width, size3.height); //Sets the location of the image
        panel.add(label3);
        
        JLabel label4 = new JLabel(); //JLabel Creation
        label4.setIcon(new ImageIcon("/Users/zehraahmed/NetBeansProjects/JavaApplication78/src/javaapplication78/er.jpg")); //Sets the image to be displayed as an icon
        Dimension size4 = label4.getPreferredSize(); //Gets the size of the image
        label4.setBounds(size3.width+295, size.height, size4.width, size4.height); //Sets the location of the image
        panel.add(label4);
       
        JButton patientButton = new JButton("PATIENT");
        patientButton.setBounds(220, 380, 150, 25);
        panel.add(patientButton);

        JButton doctorButton = new JButton("DOCTOR");
        doctorButton.setBounds(50, 380, 150, 25);
        panel.add(doctorButton);
        
        JButton erButton = new JButton("EMERGENCY ROOM");
        erButton.setBounds(410, 380, 150, 25);
        panel.add(erButton);

        JButton toggleButton = new JButton("TOGGLE WINDOW");
        toggleButton.setBounds(225, 440, 150, 25);
        panel.add(toggleButton);

        toggleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (frame.getTitle().equals("Patient Info")) {
                    frame.dispose(); // Close the current window
                    createAndShowDoctorGUI(); // Open the Doctor window
                } else {
                    frame.dispose(); // Close the current window
                    createAndShowGUI(); // Open the Patient window
                }
            }
        });

        patientButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                hospital = new Hospital("patient_records.txt", "doctor_records.txt", true);
                createAndShowGUI();
            }
        });

        doctorButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                hospital = new Hospital("patient_records.txt", "doctor_records.txt", false);
                createAndShowDoctorGUI();
            }
        });
        erButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ER er = new ER();
                er.setVisible(true);
                er.setLocationRelativeTo(null);
            }
        });
    }

    private static void createAndShowGUI() {
        JFrame frame = new JFrame("Patient Info");
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        frame.getContentPane().add(panel);
        placePatientComponents(panel);
        
        

        frame.setSize(600, 450);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
    }

    private static void createAndShowDoctorGUI() {
        JFrame frame = new JFrame("Doctor Info");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        frame.getContentPane().add(panel);
        placeDoctorComponents(panel);

        frame.setSize(600, 400);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
    }

    private static void placePatientComponents(JPanel panel) {
        panel.setLayout(null);
        
        JLabel label = new JLabel(); //JLabel Creation
        label.setIcon(new ImageIcon("/Users/zehraahmed/NetBeansProjects/JavaApplication78/src/javaapplication78/logosmall.jpg")); //Sets the image to be displayed as an icon
        Dimension size = label.getPreferredSize(); //Gets the size of the image
        label.setBounds(0, 0, size.width, size.height); //Sets the location of the image
        panel.add(label);
        
        
        JLabel TitleLabel = new JLabel("PATIENT INFORMATION");
        TitleLabel.setFont(new Font("Helvetica Nue", Font.BOLD, 24));
        TitleLabel.setForeground(new Color(8,95,225));
        TitleLabel.setBounds(size.width+20, 3, 400, size.height);
        panel.add(TitleLabel);
        
        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setBounds(10, size.height+20, 80, 25);
        panel.add(nameLabel);
        
        
        JTextField nameText = new JTextField(20);
        nameText.setBounds(120, size.height+20, 165, 25);
        panel.add(nameText);

        JLabel idLabel = new JLabel("Patient ID:");
        idLabel.setBounds(10, size.height+50, 80, 25);
        panel.add(idLabel);
        JTextField idText = new JTextField(20);
        idText.setBounds(120, size.height+50, 165, 25);
        panel.add(idText);

        JLabel timeLabel = new JLabel("Time of Entry: ");
        timeLabel.setBounds(10, size.height+80, 140, 25);
        panel.add(timeLabel);
        JTextField timeText = new JTextField(20);
        timeText.setBounds(120, size.height+80, 165, 25);
        panel.add(timeText);

        JLabel docLabel = new JLabel("Name of Doctor: ");
        docLabel.setBounds(10, size.height+110, 210, 25);
        panel.add(docLabel);
        JTextField docText = new JTextField(20);
        docText.setBounds(120, size.height+110, 165, 25);
        panel.add(docText);

        JButton registerButton = new JButton("Register");
        registerButton.setBounds(85, size.height+ 160, 150, 25);
        panel.add(registerButton);
        
        JTextPane patientPane = new JTextPane();
        patientPane.setBounds(300, size.height+20, 275, 335);
        patientPane.setEditable(false);
        panel.add(patientPane);

        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String name = nameText.getText();
                    int patientID = Integer.parseInt(idText.getText());
                    double time = Double.parseDouble(timeText.getText());
                    String doctorName = docText.getText();

                    // Find the doctor by name
                    Doctor treatingDoctor = hospital.getDoctors().findName(doctorName);

                    if (treatingDoctor != null) {
                        Patient newPatient = new Patient(name, patientID, time, treatingDoctor);
                        hospital.addPatient(newPatient);
                        treatingDoctor.getPatients().insert(newPatient);

                        // Reset the fields for a new patient
                        nameText.setText("");
                        idText.setText("");
                        timeText.setText("");
                        docText.setText("");

                        // Display a success message or perform any other action if needed
                        JOptionPane.showMessageDialog(null, "Patient registered successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                        patientPane.setText(hospital.toStringP());
                    } else {
                        JOptionPane.showMessageDialog(null, "Doctor not found", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Please enter valid data", "Error", JOptionPane.ERROR_MESSAGE);
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        JButton displayInfoButton = new JButton("Display Information");
        displayInfoButton.setBounds(85, size.height+190, 150, 25);
        panel.add(displayInfoButton);
        displayInfoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                hospital.displayPatientInfo();
            }
        });

        JButton searchButton = new JButton("Search Patient");
        searchButton.setBounds(85, size.height+220, 150, 25);
        panel.add(searchButton);
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int patientID = Integer.parseInt(idText.getText());
                    hospital.searchPatient(patientID);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Please enter a valid Patient ID", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        JButton reportButton = new JButton("Diagnosis");
        reportButton.setBounds(85, size.height+250, 150, 25);
        panel.add(reportButton);
        reportButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int patientID = Integer.parseInt(idText.getText());
                    Patient p = hospital.searchPatient2(patientID);
                    Doctor d = p.getTreatingDoctor();
                    Diagnosis D = new Diagnosis(p, d, new File("/Users/zehraahmed/NetBeansProjects/JavaApplication78/src/javaapplication78/DecisionTree.txt"));
                } catch (FileNotFoundException Ex) {
                    throw new RuntimeException(Ex);
                }
            }
        });


        JButton removeButton = new JButton("Discharge Patient");
        removeButton.setBounds(85, size.height+280, 150, 25);
        panel.add(removeButton);
        removeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int patientID = Integer.parseInt(idText.getText());
                    hospital.removePatient(patientID);
                    JOptionPane.showMessageDialog(null, "Patient deleted successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                    //patientPane.setText(hospital.toStringP());
                    Billing bill = new Billing();
                    bill.setVisible(true);
                    bill.setLocationRelativeTo(null);
                    patientPane.setText(hospital.toStringP());
                } catch (NumberFormatException | IOException ex) {
                    JOptionPane.showMessageDialog(null, "Please enter a valid Patient ID", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        JButton closeButton = new JButton("Close");
        closeButton.setBounds(85, size.height+340, 150, 25);
        panel.add(closeButton);
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0); // Close the program
            }
        });
    }

    private static void placeDoctorComponents(JPanel panel) {
        panel.setLayout(null);
        
        JLabel label = new JLabel(); //JLabel Creation
        label.setIcon(new ImageIcon("/Users/zehraahmed/NetBeansProjects/JavaApplication78/src/javaapplication78/logosmall.jpg")); //Sets the image to be displayed as an icon
        Dimension size = label.getPreferredSize(); //Gets the size of the image
        label.setBounds(0, 0, size.width, size.height); //Sets the location of the image
        panel.add(label);
        
        JLabel TitleLabel = new JLabel("DOCTOR INFORMATION");
        TitleLabel.setFont(new Font("Helvetica Nue", Font.BOLD, 24));
        TitleLabel.setForeground(new Color(8,95,225));
        TitleLabel.setBounds(size.width+20, 3, 400, size.height);
        panel.add(TitleLabel);

        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setBounds(10, size.height+20, 80, 25);
        panel.add(nameLabel);
        JTextField nameText = new JTextField(20);
        nameText.setBounds(100, size.height+20, 165, 25);
        panel.add(nameText);

        JLabel idLabel = new JLabel("Doctor ID:");
        idLabel.setBounds(10, size.height+50, 80, 25);
        panel.add(idLabel);
        JTextField idText = new JTextField(20);
        idText.setBounds(100, size.height+50, 165, 25);
        panel.add(idText);

        JLabel specializationLabel = new JLabel("Specialization:");
        specializationLabel.setBounds(10, size.height+80, 150, 25);
        panel.add(specializationLabel);
        JTextField specializationText = new JTextField(20);
        specializationText.setBounds(100, size.height+80, 165, 25);
        panel.add(specializationText);

        JTextPane docPane = new JTextPane();
        docPane.setBounds(288, size.height+20, 295, 300);
        docPane.setEditable(false);
        panel.add(docPane);
        
        JButton addDoctorButton = new JButton("Add Doctor");
        addDoctorButton.setBounds(85, size.height+125, 150, 25);
        panel.add(addDoctorButton);
        
        addDoctorButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String name = nameText.getText();
                    int doctorID = Integer.parseInt(idText.getText());
                    String specialization = specializationText.getText();
                    hospital.addDoctor(new Doctor(name, doctorID, specialization, new PSinglyLinkedList<>()));
                    docPane.setText(hospital.toStringD());
                    // Reset the fields for a new doctor
                    nameText.setText("");
                    idText.setText("");
                    specializationText.setText("");

                    // Display a success message or perform any other action if needed
                    JOptionPane.showMessageDialog(null, "Doctor added successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Please enter valid data", "Error", JOptionPane.ERROR_MESSAGE);
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        JButton deleteDoctorButton = new JButton("Delete Doctor");
        deleteDoctorButton.setBounds(85, size.height+155, 150, 25);
        panel.add(deleteDoctorButton);

        deleteDoctorButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int doctorID = Integer.parseInt(idText.getText());
                    hospital.removeDoctor(doctorID);
                    
                    
                    // Reset the fields after deleting a doctor
                    nameText.setText("");
                    idText.setText("");
                    specializationText.setText("");

                    // Display a success message or perform any other action if needed
                    JOptionPane.showMessageDialog(null, "Doctor deleted successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                    docPane.setText(hospital.toStringD());
                } catch (NumberFormatException | IOException ex) {
                    JOptionPane.showMessageDialog(null, "Please enter a valid Doctor ID", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        JButton searchDoctorButton = new JButton("Search Doctor");
        searchDoctorButton.setBounds(85, size.height+185, 150, 25);
        panel.add(searchDoctorButton);

        searchDoctorButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int doctorID = Integer.parseInt(idText.getText());
                    hospital.searchDoctor(doctorID);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Please enter a valid Doctor ID", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        JButton displayPatientsButton = new JButton("Display Patients");
        displayPatientsButton.setBounds(85, size.height+215, 150, 25);
        panel.add(displayPatientsButton);

        displayPatientsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int doctorID = Integer.parseInt(idText.getText());
                    Doctor doctor = hospital.getDoctors().find(doctorID);
                    if (doctor != null) {
                        //System.out.println("Patients of Doctor " + doctor.getDoctorName() + ":");
                        String text = "Patients of Doctor " + doctor.getDoctorName() + ":" + "\n" +doctor.getPatients().toString();
                        JOptionPane.showMessageDialog(null, text);
                        //System.out.println(doctor.getPatients().toString());
                    } else {
                        //System.out.println("Doctor not found");
                        JOptionPane.showMessageDialog(null, "Doctor not found!");
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Please enter a valid Doctor ID", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        JButton displayInfoButton = new JButton("Display Doctor Info");
        displayInfoButton.setBounds(85, size.height+245, 150, 25);
        panel.add(displayInfoButton);
        displayInfoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                hospital.displayDoctorInfo();
            }
        });

        JButton closeButton = new JButton("Close");
        closeButton.setBounds(85, size.height+285, 150, 25);
        closeButton.setBackground(Color.RED);
        panel.add(closeButton);
        

        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0); // Close the program
            }
        });
    }
    }
