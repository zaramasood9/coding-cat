//ZEHRA AHMED - 26965

package javaapplication78;


import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author zehraahmed
 */
public class ArrayBasedHeap {
    ERpatient [] heap;
    int size;
    
    public ArrayBasedHeap(){
        heap = new ERpatient[25];
        size = 0;
    }
    
    public ERpatient getMax(){
        return heap[0];
    }
    
    public int size(){
       return size; 
    }
    
    public void insert(ERpatient p){
        if (size == heap.length){
            JOptionPane.showMessageDialog(null, "Cannot admit any new patients as resource limit is met!");
        }
        else{
            heap[size] = p;
            size++;
            siftUp(size-1);
        }
    }
    
    public void siftUp(int index){
        int parent = (int)((index-1)/2);
        if (index != 0 || parent != 0){
             if (heap[index].prioirty_index>(heap[parent].prioirty_index)){
            ERpatient temp = heap[parent];
            heap[parent] = heap[index];
            heap[index] = temp;
            siftUp(parent);
        }
        }
        
    }
    
    public String display(){
        String str = "";
        for (int i = 0; i < size; i++) {
            str +=(heap[i].toString() + "\n");
        }
        return str;
    }
    
    public Boolean isEmpty(){
        return (heap[0]==null);
    }
    
    public void siftdown(int position){
        int childL = 2*position +1;
        int childR = 2*position +2;
        
        if ((childL>=position && heap[childL]!=null) &&
                (childR<size&& heap[childR]!=null)){
            if (heap[position].prioirty_index<heap[childL].prioirty_index ||
                    heap[position].prioirty_index<heap[childR].prioirty_index){
                if(heap[childR].prioirty_index>heap[childL].prioirty_index ){
                    ERpatient temp = heap[position];
                    heap[position] = heap[childR];
                    heap[childR] = temp;
                    siftdown(childR);
                }
                else if (heap[childL].prioirty_index>heap[childR].prioirty_index ){
                    ERpatient temp = heap[position];
                    heap[position] = heap[childL];
                    heap[childL] = temp;
                    siftdown(childL);
                }
            }
        }
        else if(heap.length==1){
            if (heap[childL]!=null && heap[childR]==null){
            if(heap[position].prioirty_index<heap[childL].prioirty_index){
                ERpatient temp = heap[position];
                heap[position] = heap[childL];
                heap[childL] = temp;
            }
        }
        }
    }
    
    public ERpatient extractMax(){
        size--;
        ERpatient temp = heap[0];
        heap[0] = heap[size];
        heap[size] = null;
        siftdown(0);
        return temp;
    } 
    
    public int find(int data){
        for (int i = 0; i < size; i++) {
            if (heap[i].patientID==data){
                return i;
            }
        }
        
        return -1;
    } 
    public ERpatient find2(int data){
        for (int i = 0; i < size; i++) {
            if (heap[i].patientID==data){
                return heap[i];
            }
        }
        return null;
    } 
    
    public ERpatient remove(int value){
        int index = find(value);
        if (index != -1){
            size--;
            ERpatient temp = heap[index];
            heap[index] = heap[size];
            heap[size] = temp;
            siftdown(index);
            return temp;
        }
        else{
            return null;
        }
    }
    
    public void update(int i, int d, int v){
        int index = find(i);
            heap[index].prioirty_index = v;
            //at position i, changing value of d with value of v
        if (d>v){
            //if the old value is greater than new value, that is prioirty index is decreasing
            //call sift down
            siftdown(index);
        }
        else if (d<v){
            //call sift up
            siftUp(index);
        }
    }
}
