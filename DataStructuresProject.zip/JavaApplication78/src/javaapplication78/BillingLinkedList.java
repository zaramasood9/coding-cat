/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication78;

/**
 *
 * @author zehraahmed
 */
public class BillingLinkedList {
    public BillingNode head;

    public void insertNode(BillingInformation data) {
        BillingNode newNode = new BillingNode(data);
       /* if (head == null) {
            head = newNode;
        } else {
            BillingNode temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
        }*/
       if (head==null){
           head = newNode;
       }
       else{
           newNode.next = head;
           head = newNode;
       }
    }
    
    public boolean deleteNode(int patientId, String patientName) {
    
    if (head == null) {
        return false; 
    }

    BillingNode current = head;
    BillingNode previous = null;

    
    while (current != null && (current.data.getPatientId() != patientId || !current.data.getPatientName().equals(patientName))) {
        previous = current;
        current = current.next;
    }

    if (current == null) {
        return false; 
    }
    if (previous == null) {
        head = current.next;
    } else {
        previous.next = current.next;
    }

    return true; 
}



    public BillingNode getHead() {
        return head;
    }

    public void clear() {
        head = null;
    }
    
    public String toString(){
        if (head==null){
            return "List is empty!";
        }
        else{
            BillingNode temp = head;
            String s = "";
            while(temp!=null){
                s += temp.data + "\n\n";
                temp = temp.next;
            }
            return s;
        }
    }
}

