/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication78;

/**
 *
 * @author zehraahmed
 */
public class DSinglyLinkedList<T>{
    NodeD head;

    public DSinglyLinkedList(){
        this.head=null;
    }
    public void insert(Doctor n){
        NodeD N= new NodeD(n);
        NodeD temp = null;
        if(head==null){
            head=N;
        }
        else{
            temp= head;
            while(temp.next!= null){
                temp=temp.next;
            }
            temp.next=N;
        }
    }
    public String toString() {
        if(head==null){
            return "List is empty";
        }
        NodeD temp = head;
        String s="";
        while (temp!= null) {
            s = s+ temp.data + "\n\n";
            temp = temp.next;
        }
        return s;
    }
    public void delete(int id){
        if (head == null) {
            return; // List is empty, nothing to delete.
        }

        if (((Doctor) head.data).getDocId() == id) {
            head = head.next; // Special case: Deleting the head node.
            return;
        }

        NodeD temp = head;
        while (temp.next != null && ((Doctor) temp.next.data).getDocId() != id) {
            temp = temp.next;
        }

        if (temp.next != null) {
            temp.next = temp.next.next;
        }
    
    }


    public Doctor find(int id) {

        if(head==null){ //head contains the search value and list is not empty
            return null;
        }
        NodeD temp = head;
        Doctor d;
        while(temp!=null){
            d= (Doctor) temp.data;
            if(d.getDocId()==id){
                return d;
            }
            temp=temp.next;
        }
        return null;
    }
    public Doctor findName(String name) {

        if(head==null){ //head contains the search value and list is not empty
            return null;
        }
        NodeD temp = head;
        Doctor d;
        while(temp!=null){
            d= (Doctor) temp.data;
            if(d.getDoctorName().equals(name)){
                return d;
            }
            temp=temp.next;
        }
        return null;
    }
}

