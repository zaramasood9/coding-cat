/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication78;

/**
 *
 * @author zehraahmed
 */
public class BillingNode {
    BillingInformation data;
    BillingNode next;

    BillingNode(BillingInformation data) {
        this.data = data;
        this.next = null;
    }
}
