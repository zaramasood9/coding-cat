/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication78;

/**
 *
 * @author zehraahmed
 */
public class myNode{

    String Question;
    myNode yes;
    myNode no;
    String name;
    myNode(String name, String ques){
        this. name = name;
        Question = ques;
        yes = no = null;
    }
}






