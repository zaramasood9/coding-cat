/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication78;

/**
 *
 * @author zehraahmed
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;

import java.util.Scanner;

public class Diagnosis extends JFrame {

    Patient P;
    Doctor D;
    DecisionTrees DT;
    String Diagnosis;
    private myNode currentNode;
    File F;
    GUInterface GUI;


    public Diagnosis(Patient P, Doctor D, File F) throws FileNotFoundException {

        this.P = P;
        this.D = D;
        GUI = new GUInterface(this);
        GUI.initBoard();
        this. F = F;
        this.DT = MakeTree(F);
        currentNode = DT.Root;
        GUI.questionLabel.setText(currentNode.Question);



    }

    public void setDiagnosis(String diagnosis) {
        Diagnosis = diagnosis;
    }

    public DecisionTrees MakeTree( File F ) throws FileNotFoundException {

        Scanner Sc = new Scanner(F);
        myNode prev = null;
        String relationship = null;
        DT = new DecisionTrees();

        LinkedList LL = new LinkedList();
        LinkedList Existing = new LinkedList();
        String L= Sc.nextLine();


        while (!L.isBlank()) {

            String[] arr = L.split(":");
            myNode N = new myNode(arr[0], arr[1]);
            LL.insert(N);
            //System.out.println(N.Question);
            L= Sc.nextLine();

        }
        System.out.println(LL.toString());

        while (Sc.hasNextLine()){
            String S= Sc.nextLine();
            if(!S.isBlank())
                DT=InsertRule(S,LL,Existing);

        }


        //System.out.println(DT.Root);

        return DT;
    }


    public myNode getCurrentNode( ) {
        return currentNode;
    }

    public void setCurrentNode(myNode currentNode) {
        this.currentNode = currentNode;
    }

    public String DiagnoseMe (DecisionTrees DT) {


        Scanner Sc = new Scanner(System.in);
        myNode temp = DT.Root;
        currentNode = temp;

        while (temp != null) {

            //System.out.println(temp.Question);
            GUI.questionLabel.setText(temp.Question);

            if(temp.Question.equalsIgnoreCase("Please enter your main symptom again")) break;

            if ( temp.yes == null && temp.no == null )
                break;

            String ans= GUI.getUserAnswer();

            if ( ans.equalsIgnoreCase("yes")) {
                temp = temp.yes;
                //System.out.println(temp + " is my temp ");
            } else {
                temp = temp.no;
            }

        }
        Sc.close();

        return temp.Question;

    }
    public DecisionTrees InsertRule (String S,LinkedList LL, LinkedList Existing) {

        String prevQ=null;

        String [] Array= S.split(",");
        String Qn;
        String relationship=null;

        for ( int i = 0 ; i < Array.length ; i++ ) {

            String [] Ar2= Array[i].split(":");// the rules

            if ( i==0 ) {
                Qn= (Ar2[1].trim());
                relationship = Ar2[2].trim();
            }
            else  if ( i == Array.length-1 ) { //diagnosis

                DT.insert(Ar2[0],Ar2[1],prevQ,relationship);
                return DT;
            }

            else {
                Qn = (Ar2[0].trim());
            }

            System.out.println(i);

            if (Existing.getnode(Qn)) {
                prevQ = Existing.getQuestionNodeById(Qn).Question;
                if ( i==0 )
                    relationship = Ar2[2].trim();
                else relationship = Ar2[1].trim();
                continue;} // node already exists in the tree


            myNode m = LL.getQuestionNodeById(Qn);
            Existing.insert(m);
            String Ques= m.Question;

            if ( i == 0 ) {
                DT.insert(Qn, Ques, prevQ, null);
                prevQ = Ques;
                relationship = Ar2[2].trim();

            }
            else {
                DT.insert(Qn, Ques, prevQ, relationship);
                prevQ = Ques;
                relationship = Ar2[1].trim();

            }
        }
        return DT;
    }

}

