/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication78;

/**
 *
 * @author zehraahmed
 */
import java.io.Serializable;

public class BillingInformation implements Serializable {
    private int patientId;
    private String patientName;
    private String dateOfAdmission;
    private String roomType;
    private double totalAmount;
    private String CardorCash;

    public BillingInformation(int patientId, String patientName, String dateOfAdmission, String roomType, double totalAmount, String CardorCash) {
        this.patientId = patientId;
        this.patientName = patientName;
        this.dateOfAdmission = dateOfAdmission;
        this.roomType = roomType;
        this.totalAmount = totalAmount;
        this.CardorCash = CardorCash;
    }
    public BillingInformation(ERpatient i){
        this.patientId = i.patientID;
        this.patientName = i.name;
        this.dateOfAdmission = i.TimeOfArrival.toString();
        this.CardorCash="";
        this.roomType = "";
        this.totalAmount = 0;
    }
  
        
    
    public String getCardorCash(){
        return CardorCash;
    }
    
    public int getPatientId() {
        return patientId;
    }

    public String getPatientName() {
        return patientName;
    }

    public String getDateOfAdmission() {
        return dateOfAdmission;
    }

    public String getRoomType() {
        return roomType;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Billing Information\n");
        sb.append("patient Id=").append(patientId);
        sb.append(", patient Name=").append(patientName);
        sb.append(", date Of Admission=").append(dateOfAdmission);
        sb.append(", room Type=").append(roomType);
        sb.append(", total Amount=").append(totalAmount);
        sb.append(", Card or Cash=").append(CardorCash);
        return sb.toString();
    }
    
}


