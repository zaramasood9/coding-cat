/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication78;

/**
 *
 * @author zehraahmed
 */
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.JOptionPane;

public class Hospital {
    private PSinglyLinkedList<Patient> patients;
    private DSinglyLinkedList<Doctor> doctors;
    private String patientFileName;
    private String doctorFileName;

    public Hospital(String patientFileName, String doctorFileName, boolean isPatient) {
        this.patientFileName = patientFileName;
        this.doctorFileName = doctorFileName;

        patients = new PSinglyLinkedList<>();
        doctors = new DSinglyLinkedList<>();

        if (isPatient) {
            loadPatients();
        } else {
            loadDoctors();
        }
    }
    public Hospital(String patientFileName, String doctorFileName){
        this.patientFileName = patientFileName;
        this.doctorFileName = doctorFileName;
    }

    private void loadPatients() {
    }

    private void loadDoctors() {

    }
    public String toStringP(){
        return patients.toString();
    }
    public String toStringD(){
        return doctors.toString();
    }

    private void saveFile(String fileName, Node<?> head) throws IOException {
        FileWriter writer = new FileWriter(fileName, true);
        Node<?> temp = head;
        while (temp != null) {
            writer.write(temp.data.toString() + "\n");
            temp = temp.next;
        }
        writer.close();
    }
    private void saveDocFile(String fileName, NodeD<Doctor> head) throws IOException {
        FileWriter writer = new FileWriter(fileName, true);
        NodeD<Doctor> temp = head;
        while (temp != null) {
            writer.write(temp.data.toString() + "\n");
            temp = temp.next;
        }
        writer.close();
    }

    public PSinglyLinkedList<Patient> savePatientFile() throws IOException {
        saveFile(patientFileName, patients.head);
        return patients;
    }

    public DSinglyLinkedList<Doctor> saveDoctorFile() throws IOException {
        saveDocFile(doctorFileName, doctors.head);
        return doctors;
    }
    public void clearFiles() throws IOException {
        clearPatientsFile();
        clearDoctorsFile();
    }

    private void clearPatientsFile() throws IOException {
        try (PrintWriter writer = new PrintWriter(new FileWriter("patient_records.txt"))) {
            // Write an empty string to the patient file
            writer.print("");
        }
    }

    private void clearDoctorsFile() throws IOException {
        try (PrintWriter writer = new PrintWriter(new FileWriter("doctor_records.txt"))) {
            // Write an empty string to the doctor file
            writer.print("");
        }
    }



    public void addPatient(Patient patient) throws IOException {
        Node N = new Node(patient);
        Node temp = null;
        if (patients.head == null) {
            patients.head = N;
        } else {
            temp = patients.head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = N;
        }
        savePatientFile();
    }

    public void removePatient(int id) throws IOException {
        NodeD temp = Main.hospital.getDoctors().head;

        while (temp != null) {
            Doctor doctor = (Doctor) temp.data;
            if (doctor.getPatients().find(id) != null) {
                doctor.getPatients().delete(id);
            }
            temp = temp.next;
        }
        patients.delete(id);  //overall patients list
        savePatientFile();

    }

    public void displayPatientInfo() {
        //System.out.println("------Patients Information------");
        //System.out.println(patients.toString());
        JOptionPane.showMessageDialog(null,"------Patient Information------\n"+ patients.toString() );
    }

    public void searchPatient(int id) {
        Patient patientSearch = patients.find(id);
        if (patientSearch != null) {
            System.out.println("Patient " + patientSearch.toString() + " found!");
            JOptionPane.showMessageDialog(null, "Patient Found! \n"+patientSearch.toString());
        } else {
            JOptionPane.showMessageDialog(null, "Patient not found!");
        }
    }

    public String report(int id) {
        Patient patientSearch = patients.find(id);
        if (patientSearch != null) {
            return "Report of: " + patientSearch.toString();
        } else {
            return "Patient Not found";
        }
    }

    public void addDoctor(Doctor doctor) throws IOException {
            doctors.insert(doctor);
            saveDoctorFile(); // Save updated doctor list to file
        }


    public void removeDoctor(int id) throws IOException {
        doctors.delete(id);
        saveDoctorFile();
    }

    public void displayDoctorInfo() {
        //System.out.println("------Doctor Information------");
        //System.out.println(doctors.toString());
        JOptionPane.showMessageDialog(null,"------Doctor Information------\n"+ doctors.toString() );
    }

    public void searchDoctor(int id) {
        Doctor doctorSearch = doctors.find(id);
        if (doctorSearch != null) {
            //System.out.println("Doctor " + doctorSearch.toString() + " found!");
            JOptionPane.showMessageDialog(null, "Doctor Found! \n"+doctorSearch.toString());
        } else {
            JOptionPane.showMessageDialog(null, "Doctor not found!");
        }
    }
    public Patient searchPatient2(int id) {
        Patient patientSearch = patients.find(id);
        if (patientSearch != null) {
           return patientSearch;
        } else {
           return null;
        }
    }

    public DSinglyLinkedList<Doctor > getDoctors() {
        return doctors;
    }
}
