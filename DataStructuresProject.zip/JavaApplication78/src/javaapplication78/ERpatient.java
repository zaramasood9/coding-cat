package javaapplication78;

import java.time.LocalDateTime;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author zehraahmed
 */
public class ERpatient {
    
    String name;
    int age;
    int patientID;
    String disease;
    java.time.LocalDateTime TimeOfArrival;
    
    int respiRate;
    int pulseRate;
    int pulseOximeter;
    int heartRate;
    int Sbp; // blood pressure
    int Dbp; // blood pressure
    String LOC; //level of conciousness
    float bodyTemp;
    
    int prioirty_level;
    int prioirty_index;

    public ERpatient() {
    }

    public ERpatient(String name, int prioirty_level, int prioirty_index) {
        this.name = name;
        this.prioirty_level = prioirty_level;
        this.prioirty_index = prioirty_index;
    }
    
    
    
    

    public ERpatient(String name, int age, int patientID, String disease, LocalDateTime TimeOfArrival, int respiRate, int pulseRate, int pulseOximeter, int heartRate, int Sbp, int Dbp, String LOC, float bodyTemp, int prioirty_level, int prioirty_index) {
        this.name = name;
        this.age = age;
        this.patientID = patientID;
        this.disease = disease;
        this.TimeOfArrival = TimeOfArrival;
        this.respiRate = respiRate;
        this.pulseRate = pulseRate;
        this.pulseOximeter = pulseOximeter;
        this.heartRate = heartRate;
        this.Sbp = Sbp;
        this.Dbp = Dbp;
        this.LOC = LOC;
        this.bodyTemp = bodyTemp;
        this.prioirty_level = prioirty_level;
        this.prioirty_index = prioirty_index;
    }

    

    
    

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getDisease() {
        return disease;
    }

    public void setDisease(String disease) {
        this.disease = disease;
    }

    public int getRespiRate() {
        return respiRate;
    }

    public void setRespiRate(int respiRate) {
        this.respiRate = respiRate;
    }

    public int getPulseRate() {
        return pulseRate;
    }

    public void setPulseRate(int pulseRate) {
        this.pulseRate = pulseRate;
    }

    public int getPulseOximeter() {
        return pulseOximeter;
    }

    public void setPulseOximeter(int pulseOximeter) {
        this.pulseOximeter = pulseOximeter;
    }

    public int getHeartRate() {
        return heartRate;
    }

    public void setHeartRate(int heartRate) {
        this.heartRate = heartRate;
    }

    public int getSbp() {
        return Sbp;
    }

    public void setSbp(int Sbp) {
        this.Sbp = Sbp;
    }

    public int getDbp() {
        return Dbp;
    }

    public void setDbp(int Dbp) {
        this.Dbp = Dbp;
    }

    public String getLOC() {
        return LOC;
    }

    public void setLOC(String LOC) {
        this.LOC = LOC;
    }

    public float getBodyTemp() {
        return bodyTemp;
    }

    public void setBodyTemp(float bodyTemp) {
        this.bodyTemp = bodyTemp;
    }

    public int getPrioirty_level() {
        return prioirty_level;
    }

    public void setPrioirty_level(int prioirty_level) {
        this.prioirty_level = prioirty_level;
    }

    public int getPrioirty_index() {
        return prioirty_index;
    }

    public void setPrioirty_index(int prioirty_index) {
        this.prioirty_index = prioirty_index;
    }

    public int getPatientID() {
        return patientID;
    }

    public void setPatientID(int patientID) {
        this.patientID = patientID;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        //sb.append("ER Patient:");
        sb.append("patientID: ").append(patientID);
            sb.append(" || name: ").append(name);
        if (age!=0)
            sb.append(" || age: ").append(age);
        sb.append(" || prioirty_level: ").append(prioirty_level);
        sb.append(" || prioirty_index: ").append(prioirty_index);
        sb.append(" || disease: ").append(disease);
        sb.append(" || [Vitals:");
        if (respiRate!=0)
            sb.append(" - respiRate: ").append(respiRate);
        if (pulseRate!=0)
            sb.append(" - pulseRate: ").append(pulseRate);
        if (pulseOximeter!=0)
            sb.append(" - pulseOximeter: ").append(pulseOximeter);
        if (heartRate!=0)
            sb.append(" - heartRate: ").append(heartRate);
        if (Sbp!=0)
            sb.append(" - Sbp: ").append(Sbp);
        if (Dbp!=0)
            sb.append(" - Dbp: ").append(Dbp);
        if (LOC.equals("select an option")){
            
        }
        else{
            sb.append(" - LOC: ").append(LOC);
            
        }
        if (bodyTemp!=0)
            sb.append(" - bodyTemp: ").append(bodyTemp);
        sb.append(']');
        sb.append("\n");
        return sb.toString();
    }

    
    
    
}
