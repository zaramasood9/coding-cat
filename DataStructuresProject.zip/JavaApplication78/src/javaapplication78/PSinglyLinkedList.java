/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication78;

/**
 *
 * @author zehraahmed
 */
    public class PSinglyLinkedList<T> {
        Node head;
        public PSinglyLinkedList(){
            this.head=null;
        }
        public void insert(Patient n){
            Node N= new Node(n);
            Node temp = null;
            if(head==null){
                head=N;
            }
            else{
                temp= head;
                while(temp.next!= null){
                    temp=temp.next;
                }
                temp.next=N;
            }
        }
        public String toString() {
            if(head==null){
                return "List is empty";
            }
            Node temp = head;
            String s="";
            while (temp!= null) {
                s = s+ temp.data + "\n\n";
                temp = temp.next;
            }
            return s;
        }
        public void delete(int id){
            Patient p =null;
            if (head == null) {
                return; // List is empty, nothing to delete.
            }
            p = (Patient) head.data;
            if (p.getId() == id) {
                head = head.next; // Special case: Deleting the head node.
                return;
            }
            Node temp=head;
            p=(Patient) temp.data;
            while (temp.next != null) {
                if (p.getId()==id) {
                    temp.next = temp.next.next;
                    return;
                }
                temp = temp.next;
            }
        }


        public Patient find(int id) {

            if(head==null){ //head contains the search value and list is not empty
                return null;
            }
            Node temp = head;
            Patient p;
            while(temp!=null){
                p= (Patient) temp.data;
                if(p.getId()==id){
                    return p;
                }
                temp=temp.next;
            }
            return null;
        }
    }
