package javaapplication78;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author zehraahmed
 */
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

class NodeR {
    ERpatient data;
    NodeR next;

    public NodeR(ERpatient data) {
        this.data = data;
        this.next = null;
    }
}

public class Reporttds extends JFrame implements ActionListener {

    private NodeR head;
    
    JLabel reportLabel;
    JButton generateReportButton, close;
    
    
    public Reporttds() {
        super("REPORT");
        this.head = null;
        setSize(400, 400);
        getContentPane().setBackground(Color.WHITE);
        setLocationRelativeTo(null);
        setLayout(null);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        JLabel label = new JLabel(); //JLabel Creation
        label.setIcon(new ImageIcon("/Users/zehraahmed/NetBeansProjects/JavaApplication78/src/javaapplication78/logosmall.jpg")); //Sets the image to be displayed as an icon
        Dimension size = label.getPreferredSize(); //Gets the size of the image
        label.setBounds(0, 0, size.width, size.height); //Sets the location of the image
        add(label);
        
        
        JLabel TitleLabel = new JLabel("REPORT");
        TitleLabel.setFont(new Font("Helvetica Nue", Font.BOLD, 24));
        TitleLabel.setForeground(new Color(8,95,225));
        TitleLabel.setBounds(size.width-40, 100, 400, size.height);
        add(TitleLabel);

        generateReportButton = new JButton("GENERATE REPORT");
        generateReportButton.setBounds(45, size.height+140, 310, 50);
        generateReportButton.addActionListener(this);
        add(generateReportButton);
        
        close = new JButton("CLOSE");
        close.setBounds(45, size.height+200, 310, 50);
        close.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false); 
            }
        });
        add(close);
        
        setVisible(true);
        
    }
    
     public void actionPerformed(ActionEvent e) {
                
                String patientNameToDisplay = JOptionPane.showInputDialog("Enter patient name:");
                if (patientNameToDisplay != null && !patientNameToDisplay.isEmpty()) {

                    try{
                    int patientID = Integer.parseInt(JOptionPane.showInputDialog("Enter patient ID:"));

                    
                    ERpatient patient = new ERpatient(patientNameToDisplay, 0, 5);

                    
                    patient.setPatientID(patientID);
                    patient.setAge(25);
                    patient.setDisease("Fever");
                    patient.setRespiRate(18);
                    patient.setPulseRate(80);
                    patient.setPulseOximeter(98);
                    patient.setHeartRate(75);
                    patient.setSbp(120);
                    patient.setDbp(80);
                    patient.setLOC("Conscious");
                    patient.setBodyTemp(98.6f);

                    
                    addPatient(patient);
                        System.out.println("Patient information:");
                        System.out.println(formatPatientInfo(patient));
                        
                        generateReport(patientNameToDisplay);
                    }catch(NumberFormatException ex){
                        JOptionPane.showMessageDialog(null, "Invalid input for patient ID!", "Error", JOptionPane.ERROR_MESSAGE);
            } 
          }
                
        setVisible(true);
     }
    

    public void addPatient(ERpatient patient) {
        NodeR newNode = new NodeR(patient);
        newNode.next = head;
        head = newNode;
    }

    public void generateReport(String patientName) {
        ERpatient foundPatient = findPatient(patientName);
        if (foundPatient != null) {
            String report = "Patient Report:\n" + formatPatientInfo(foundPatient);
           
            JOptionPane.showMessageDialog(null, report, "Patient Report", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Patient not found!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void clearReport() {
        head = null; // Clear the entire linked list
    }

    private ERpatient findPatient(String patientName) {
        NodeR current = head;
        while (current != null) {
            if (current.data.getName().equalsIgnoreCase(patientName)) {
                return current.data;
            }
            current = current.next;
        }
        return null;
    }

    private String formatPatientInfo(ERpatient patient) {
        StringBuilder sb = new StringBuilder();
        
        sb.append("Name: ").append(patient.getName()).append("\n");
        sb.append("Patient ID: ").append(patient.getPatientID()).append("\n");
        sb.append("Age: ").append(patient.getAge()).append("\n");
        sb.append("Disease: ").append(patient.getDisease()).append("\n");
        sb.append("Vitals:\n");
        sb.append(" - Respi Rate: ").append(patient.getRespiRate()).append("\n");
        sb.append(" - Pulse Rate: ").append(patient.getPulseRate()).append("\n");
        sb.append(" - Pulse Oximeter: ").append(patient.getPulseOximeter()).append("\n");
        sb.append(" - Heart Rate: ").append(patient.getHeartRate()).append("\n");
        sb.append(" - Sbp: ").append(patient.getSbp()).append("\n");
        sb.append(" - Dbp: ").append(patient.getDbp()).append("\n");
        sb.append(" - LOC: ").append(patient.getLOC()).append("\n");
        sb.append(" - Body Temp: ").append(patient.getBodyTemp()).append("\n");
        sb.append("Priority Level: ").append(patient.getPrioirty_level()).append("\n");
        sb.append("Priority Index: ").append(patient.getPrioirty_index()).append("\n");

        return sb.toString();
    }


   
}
    

