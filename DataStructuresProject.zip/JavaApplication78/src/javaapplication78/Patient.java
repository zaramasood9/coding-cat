/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication78;

/**
 *
 * @author zehraahmed
 */
public class Patient {
    private String patientName;
    private int id;
    private double timeOfAdmission;
    private Doctor treatingDoctor;

    public Patient(String patientName, int id, double timeOfAdmission, Doctor treatingDoctor) {
        this.patientName = patientName;
        this.id = id;
        this.timeOfAdmission = timeOfAdmission;
        this.treatingDoctor = treatingDoctor;
    }

    public Doctor getTreatingDoctor() {
        return treatingDoctor;
    }

    public String getPatientName() {
        return patientName;
    }

    public int getId() {
        return id;
    }

    public double getTimeOfAdmission() {
        return timeOfAdmission;
    }



    @Override
    public String toString() {
        return "Patient{" +
                "patientName='" + patientName + '\'' +
                ", id=" + id +
                ", timeOfAdmission=" + timeOfAdmission +
                ", doctorName='" + treatingDoctor.getDoctorName() + '\'' +
                '}';
    }
}
