/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication78;

/**
 *
 * @author zehraahmed
 */
public class LinkedList {
    nodeN head;
    public LinkedList() {
        head = null;
    }

    public void insert(myNode N) {
        nodeN newNode =  new nodeN(N);
        if (head == null) {
            head = newNode;
        } else {
            nodeN current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    public String toString() {
        String s= "";
        nodeN temp = head;
        while (temp != null) {
            s=s+ "\n"+ (temp.N);
            temp = temp.next;
        }
        return s;
    }
    public myNode getQuestionNodeById(String id) {
        nodeN current = head;
        while (current != null && current.N!=null) {
            System.out.println(id);
            System.out.println(current.N.name);
            if ((current.N.name.equals(id))) {
                return current.N;
            }
            current = current.next;
        }
        return null;
    }

   /* public Boolean find(node d) {

        nodeN temp = head;
        while (temp != null) {
            if (temp.N == d) return true;
            else
                temp = temp.next;

        }
        return false;

    */


    // code } // find a node with value d
 /*   public Node findNode(T d) {

        Node temp = head;
        while (temp != null) {
            if (temp.data == d) return temp;
            else
                temp = temp.next;

        }
        return null;

    }
    public void delete(node d) {

        if (head == null) //list is empty
            return;

        if (head.N == d) //first is to be deleted
            head = head.next;

        else {

            nodeN prev = null;
            nodeN temp = head;

            while (temp != null && temp.data != d) {
                prev = temp;
                temp = temp.next;
            }

            if (temp == null) { //whole list traversed
                System.out.println(" Value to delete not found");
                return;
            }

            // will only reach this statement when  (temp.data == d) so if condition is not needed
            prev.next = temp.next;

        }
    }

    public void insertBefore(Node MyNode, T d) {

        Node newn = new Node(d);
        Node curr = head;
//        Node MyNode= findNode((T) n.data);
        if ( MyNode==head ) { //insert before head // if (n==head) doesnt work?
            newn.next = head;
            head=newn; //or head==newn?
            return;
        }
        while (curr.next != null && curr.next != MyNode)
            curr= curr.next;

        if (curr.next==MyNode){
            newn.next=MyNode;
            curr.next=newn;
        }

    }


    public void clear(){
        head=null;
        System.out.println("List has been cleared");
    }// code } // make list empty

  */

    public boolean getnode( String name) {
        nodeN current = head;
        while (current != null) {
            if (current.N.name.equals(name)) {
                return true;
            }
            current = current.next;
        }
        return false;
    }








}


