/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication78;

/**
 *
 * @author zehraahmed
 */
public class DecisionTrees {

    myNode Root;

    public void insert(String name, String question, String parentQuestion, String relationship) {
        myNode newNode = new myNode(name,question);

        if (Root == null) {
            // The tree is empty, so the new node becomes the root.
            Root = newNode;
        } else {
            insertRecursive(Root, newNode, parentQuestion, relationship);
        }
    }

    private boolean insertRecursive(myNode node, myNode newNode, String parentQuestion, String relationship) {
        if (node == null) {
            return false;
        }

        if (parentQuestion != null && parentQuestion.equalsIgnoreCase(node.Question)) {
            if (relationship.equalsIgnoreCase("yes")) {
                node.yes = newNode;
            } else {
                node.no = newNode;
            }
            return true;
        }

        boolean foundInYesBranch = insertRecursive(node.yes, newNode, parentQuestion, relationship);
        boolean foundInNoBranch = insertRecursive(node.no, newNode, parentQuestion, relationship);

        return foundInYesBranch || foundInNoBranch;
    }
}



