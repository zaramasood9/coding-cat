/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication78;

/**
 *
 * @author zehraahmed
 */
public class Doctor {
    private String doctorName;
    private int docId;
    private String specialization;
    private PSinglyLinkedList<Patient> patients;

    public Doctor(String doctorName, int docId, String specialization, PSinglyLinkedList<Patient> patients) {
        this.doctorName = doctorName;
        this.docId = docId;
        this.specialization = specialization;
        this.patients = patients;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public String getSpecialization() {
        return specialization;
    }

    public int getDocId() {
        return docId;
    }

    public PSinglyLinkedList<Patient> getPatients() {
        return patients;
    }

    @Override
    public String toString() {
        return "Doctor{" +
                "doctorName='" + doctorName + '\'' +
                ", docId=" + docId +
                ", specialization='" + specialization + '\'' +
                ", patients=" + patients +
                '}';
    }
}


