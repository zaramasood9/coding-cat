import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        TowerOfHanoi t1= new TowerOfHanoi();
        TowerOfHanoi t2= new TowerOfHanoi();
        TowerOfHanoi t3= new TowerOfHanoi();


        t1.Hanoi(4, 'A', 'C', 'B');  // A, B and C are names of rods
        System.out.println("Total recursive calls made for 4 disks : "+ t1.recur);
        System.out.println("/////////////////////////////////////");
        t2.Hanoi(22, 'A', 'C', 'B');  // A, B and C are names of rods
        System.out.println("Total recursive calls made for 22 disks : "+ t2.recur);
        System.out.println("/////////////////////////////////////");
        t3.Hanoi(5, 'A', 'C', 'B');  // A, B and C are names of rods
        System.out.println("Total recursive calls made for 5 disks : "+ t3.recur);
        System.out.println("/////////////////////////////////////");

    }
    }


